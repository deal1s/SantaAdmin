# 🎅 Santa Admin Bot - Телеграм Адміністративний Бот

## 📋 Опис

**Santa Admin Bot** - це комплексний Telegram адміністративний бот з ролями, модерацією, нотатками, напоминаннями про дні народження та багатьма іншими функціями для управління групою.

### ✨ Основні функції

#### 👥 Система ролей
- **Owner** - власник (максимум прав)
- **Head Admin** - старший адміністратор
- **Gnomes** - модератори
- **Users** - звичайні користувачі

#### 🎂 День народження
- Автоматичні привітання в **08:00 за Київським часом**
- Налаштування GIF та тексту привітання
- База всіх днів народження

#### 🛡️ Модерація
- `/ban_s` - тихий бан (без сповіщення)
- `/ban_t` - публічний бан
- `/mute_s` - тихий мут
- `/mute_t` - публічний мут
- `/nah` - чорний список (тільки для власника)
- `/unban` та `/unmute` - розблокування

#### 💬 Система повідомлень
- `/say` - відправити текст в чат користувача як reply
- `/says` - переспрямувати повідомлення з посиланнями (https://t.me/c/CHAT_ID/MESSAGE_ID)
- Двосторонній форвардинг

#### 📝 Нотатки та напоминання
- `/note` - додати особисту нотатку
- `/notes` - переглянути нотатки
- `/delnote` - видалити нотатку
- `/remind` та `/remindsomeone` - встановити напоминання
- Список всіх активних напоминань

#### 👤 Профіль користувача
- `/myprofile` - переглянути профіль
- `/setname` - встановити кастомне імя
- `/setpic` - встановити профіль-фото/GIF
- `/setdesc` - встановити опис
- `/setpos` - встановити посаду
- `/delname`, `/delpic`, `/deldesc`, `/delpos` - видалення

#### 🔧 Адміністративні команди
- `/setrole` - встановити роль
- `/deltimer` - налаштувати таймер видалення (1-60 сек)
- `/sayblock` - блокувати /say команду користувачу
- `/sayunblock` - розблокувати

#### 📊 Перегляд
- `/allroles` - переглянути всіх користувачів з ролями
- `/online` - активні режими(/sayon, /sayson)
- `/stat` - статистика
- `/allbirthdays` - календар днів народження

---

## 🚀 Встановлення на GitHub Pages / Heroku

### Крок 1: Встанови Python та залежності

```bash
git clone https://github.com/ТВІЙ_ЮЗЕР/santa-admin-bot.git
cd santa-admin-bot
pip install -r requirements.txt
```

### Крок 2: Отримай BOT_TOKEN від @BotFather

1. Напиши @BotFather в Telegram
2. Створи нового бота командою `/newbot`
3. Скопіюй token

### Крок 3: Налаштуй оточення

**На локалі:**
```bash
cp .env.example .env
# Редагуй .env, вставь BOT_TOKEN
```

**На Heroku:**
```bash
heroku login
heroku create ТИ-НАЗВА-БОТУ
heroku config:set BOT_TOKEN="ТВІЙ_ТОКЕН"
```

### Крок 4: Налаштуй config.json

**config.json** - основний файл налаштувань:

```json
{
  "OWNER_ID": 7247114478,
  "USER_CHAT_ID": -1001234567890,
  "LOG_CHANNEL_ID": -1001234567890,
  "NOTES_CHANNEL_ID": -1001234567890,
  "MESSAGE_DELETE_TIMER": 60,
  "BIRTHDAY_HOUR": 8,
  "BIRTHDAY_MINUTE": 0
}
```

**Де взяти ID чатів:**
- Напиши @userinfobot - отримаєш свій ID
- Додай бота в групу/канал, напиши `/start` - побачиш ID чату

### Крок 5: Запусти бота

**На локалі:**
```bash
python bot.py
```

**На Heroku:**
```bash
git push heroku main
heroku logs --tail
```

**На GitHub Actions (автоматично):**
Готово! GitHub буде запускати бота автоматично при кожному пуші

---

## 📁 Структура файлів

```
santa-admin-bot/
├── bot.py              # Основний код бота (3400+ рядків)
├── database.py         # SQLite база даних
├── config.json         # Налаштування
├── requirements.txt    # Python залежності
├── .env.example        # Шаблон для змінних
├── README.md           # Документація
└── bot_database.db     # Крім при першому запуску
```

---

## 🛠️ Функції в коді

### bot.py - Головні команди:

| Функція | Опис |
|---------|------|
| `async def ban_s_command` | Тихий бан |
| `async def ban_t_command` | Публічний бан |
| `async def mute_s_command` | Тихий мут |
| `async def mute_t_command` | Публічний мут |
| `async def note_command` | Додати нотатку |
| `async def notes_command` | Показати нотатки |
| `async def say_command` | Відправити повідомлення |
| `async def says_command` | Переспрямувати повідомлення |
| `async def profile_command` | Переглянути профіль |
| `async def remind_command` | Встановити напоминання |

### database.py - Таблиці:

- `roles` - ролі користувачів
- `bans` - заблоковані користувачі
- `mutes` - замучені користувачі
- `blacklist` - чорний список
- `notes` - нотатки
- `reminders` - напоминання
- `birthdays` - дні народження
- `custom_names` - кастомні імена
- `profile_pictures` - фото профілю
- `profile_descriptions` - описи профілю
- `custom_positions` - посади

---

## 🔧 Налаштування параметрів

### config.json параметри:

```json
{
  "OWNER_ID": 12345678,           // ID власника
  "USER_CHAT_ID": -1001234567890, // ID основної групи
  "LOG_CHANNEL_ID": -1001234567890, // Канал логування
  "NOTES_CHANNEL_ID": -1001234567890, // Канал нотаток
  "MESSAGE_DELETE_TIMER": 60,     // Таймер видалення (сек)
  "BIRTHDAY_HOUR": 8,             // Час привіту (0-23)
  "BIRTHDAY_MINUTE": 0            // Хвилина привіту (0-59)
}
```

### Встановити BOT_TOKEN:

**На локалі (в .env):**
```
BOT_TOKEN=123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11
```

**На Heroku:**
```bash
heroku config:set BOT_TOKEN="ТВІЙ_ТОКЕН"
```

---

## 🐛 Розв'язування проблем

### Бот не запускається
```bash
# Перевір логи
tail -f bot.log

# Переінстали залежності
pip install --upgrade -r requirements.txt
```

### Помилка SQLite
```bash
# Видали старе БД та перезапусти
rm bot_database.db
python bot.py
```

### Бот не реагує на команди
- Переконайся, що BOT_TOKEN правильний
- Перевір USER_CHAT_ID в config.json
- Переінстали pip зависимості

---

## 📞 Підтримка

Для питань та пропозицій створи **Issue** або **Pull Request** на GitHub.

---

## ⚖️ Ліцензія

MIT License - вільне використання та модифікація.

**Версія:** 1.0.0  
**Остання оновлення:** 24.11.2025

---

## 🎉 Готово!

Твій бот готовий до запуску! 🚀

Запусти його та користуйся всіма адміністративними функціями!
