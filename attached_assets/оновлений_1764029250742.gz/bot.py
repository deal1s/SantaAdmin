import logging
import json
import os
import re
import time as time_module
import asyncio
from datetime import datetime, timedelta, time
from typing import Optional
import pytz
from telegram import Update, ChatPermissions, ChatMember
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes, ChatMemberHandler
from telegram.ext import JobQueue
from database import Database
from openai import OpenAI

# Глобальний флаг для перезапуску
RESTART_BOT = False

# Кешування timezone для швидшого завантаження
KYIV_TZ = pytz.timezone('Europe/Kyiv')

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.DEBUG
)
logger = logging.getLogger(__name__)

with open('config.json', 'r', encoding='utf-8') as f:
    config = json.load(f)

BOT_TOKEN = os.getenv('BOT_TOKEN', config.get('TOKEN', ''))
ADMIN_CHAT_ID = config.get('ADMIN_CHAT_ID')
USER_CHAT_ID = config.get('USER_CHAT_ID')
LOG_CHANNEL_ID = config.get('LOG_CHANNEL_ID')
NOTES_CHANNEL_ID = config.get('NOTES_CHANNEL_ID')
TEST_CHANNEL_ID = config.get('TEST_CHANNEL_ID')
OWNER_IDS = config.get('OWNER_IDS', [])
MESSAGE_DELETE_TIMER = config.get('MESSAGE_DELETE_TIMER', 5)
GPT_API_KEY = os.getenv('GPT_API_KEY', '')  # OpenAI API ключ

db = Database()

def format_kyiv_time(iso_string: str) -> str:
    """Форматує ISO дату в формат: 2025-10-24 о 13:24 (Київ)"""
    try:
        dt = datetime.fromisoformat(iso_string)
        if dt.tzinfo is None:
            dt = pytz.UTC.localize(dt)
        tz = pytz.timezone('Europe/Kyiv')
        dt_kyiv = dt.astimezone(tz)
        return dt_kyiv.strftime('%Y-%m-%d о %H:%M')
    except:
        return iso_string

def save_config():
    with open('config.json', 'w', encoding='utf-8') as f:
        json.dump({
            "ADMIN_CHAT_ID": ADMIN_CHAT_ID,
            "USER_CHAT_ID": USER_CHAT_ID,
            "LOG_CHANNEL_ID": LOG_CHANNEL_ID,
            "NOTES_CHANNEL_ID": NOTES_CHANNEL_ID,
            "TEST_CHANNEL_ID": TEST_CHANNEL_ID,
            "OWNER_IDS": OWNER_IDS,
            "MESSAGE_DELETE_TIMER": MESSAGE_DELETE_TIMER
        }, f, indent=2, ensure_ascii=False)

def is_owner(user_id: int) -> bool:
    return user_id in OWNER_IDS

def is_head_admin(user_id: int) -> bool:
    return db.get_role(user_id) == "head_admin"

def is_gnome(user_id: int) -> bool:
    return db.get_role(user_id) == "gnome"

def can_use_bot(user_id: int) -> bool:
    return is_owner(user_id) or is_head_admin(user_id) or is_gnome(user_id)

def parse_telegram_link(link: str):
    """Парсить посилання на Telegram повідомлення: https://t.me/c/2646171857/770828"""
    match = re.search(r't\.me/c/(\d+)/(\d+)', link)
    if match:
        # Для приватних каналів Telegram: chat_id = -1000000000000 - ID
        channel_id = int(match.group(1))
        chat_id = -1000000000000 - channel_id
        message_id = int(match.group(2))
        logger.info(f"📎 Парсено посилання: channel_id={channel_id}, chat_id={chat_id}, message_id={message_id}")
        return chat_id, message_id
    return None, None

def can_manage_gnomes(user_id: int) -> bool:
    return is_owner(user_id) or is_head_admin(user_id)

def can_ban_mute(user_id: int) -> bool:
    return is_owner(user_id) or is_head_admin(user_id)

def get_display_name(user_id: int, default_name: str = "Невідомий") -> str:
    """Отримати кастомне імʼя користувача або стандартне"""
    custom_name = db.get_custom_name(user_id)
    if custom_name:
        return custom_name
    return default_name or "Невідомий"

def safe_send_message(text: str) -> str:
    if not text:
        return ""
    text = str(text)
    text = re.sub(r'[<>&]', '', text)
    text = re.sub(r'[@#]', '', text)
    text = re.sub(r'[\[\]]', '', text)
    return text.strip()

async def delete_message_after_delay(message, delay: Optional[int] = 5):
    """Видаляє повідомлення через delay секунд"""
    try:
        if delay is None:
            delay = 5
        await asyncio.sleep(delay)
        await message.delete()
    except Exception as e:
        pass  # Не вдалось видалити повідомлення

async def reply_and_delete(update: Update, text: str, delay: Optional[int] = None):
    """Надсилає відповідь та видаляє її через delay секунд"""
    global MESSAGE_DELETE_TIMER
    try:
        if update.message is None:
            return None
        msg = await update.message.reply_text(text)
        if delay is None:
            delay = MESSAGE_DELETE_TIMER
        asyncio.create_task(delete_message_after_delay(msg, delay))
        return msg
    except Exception as e:
        logger.error(f"Помилка при надсиланні повідомлення: {e}")
        return None

async def log_to_channel(context: ContextTypes.DEFAULT_TYPE, message: str):
    if LOG_CHANNEL_ID:
        try:
            await context.bot.send_message(
                chat_id=LOG_CHANNEL_ID,
                text=message,
                parse_mode=None
            )
        except Exception as e:
            logger.error(f"Помилка логування в канал: {e}")

async def get_user_info(update: Update, context: ContextTypes.DEFAULT_TYPE, identifier: str) -> Optional[dict]:
    try:
        if identifier.startswith('@'):
            # Видаляємо @ і пробуємо знайти через обидва способи
            username = identifier.lstrip('@')
            
            # Спроба 1: Пошук в базі даних (ПЕРШИЙ ВАРІАНТ)
            logger.info(f"🔍 Спроба 1: Пошук в БД за username '@{username}'")
            user_data = db.get_user_by_username(username)
            if user_data:
                logger.info(f"✅ ЗНАЙДЕНО в БД! user_id={user_data['user_id']}, username={user_data.get('username')}, full_name={user_data.get('full_name')}")
                return {
                    "user_id": user_data["user_id"],
                    "username": user_data.get("username", ""),
                    "full_name": user_data.get("full_name", "")
                }
            logger.info(f"⚠️ Не знайдено в БД по запиту '{username}'")
            
            # Спроба 2: Використовуємо get_chat з username (API Telegram)
            try:
                chat = await context.bot.get_chat(username)
                return {
                    "user_id": chat.id,
                    "username": chat.username or username,
                    "full_name": chat.full_name or chat.first_name or ""
                }
            except Exception as e:
                pass  # API Telegram не знайшов
            
            # Спроба 3: Пошук через get_chat_member в обох чатах
            all_user_ids = db.get_all_users()
            for user_id in all_user_ids:
                try:
                    chat_member = await context.bot.get_chat_member(USER_CHAT_ID, user_id)
                    if chat_member.user.username and chat_member.user.username.lower() == username.lower():
                        return {
                            "user_id": user_id,
                            "username": chat_member.user.username,
                            "full_name": chat_member.user.full_name or ""
                        }
                except:
                    pass
            
            logger.warning(f"❌ Користувача @{username} не знайдено")
            # Покращена помилка для користувача
            logger.info(f"⚠️ Можливі причини:")
            logger.info(f"   1. Користувач @{username} ніколи не писав повідомлення у бот/групу")
            logger.info(f"   2. Акаунт приватний або був видалений")
            logger.info(f"   3. Невірно введене ім'я користувача")
            return None
        else:
            # Пошук по ID
            user_id = int(identifier)
            try:
                chat_member = await context.bot.get_chat_member(USER_CHAT_ID, user_id)
                user = chat_member.user
            except:
                try:
                    if ADMIN_CHAT_ID:
                        chat_member = await context.bot.get_chat_member(ADMIN_CHAT_ID, user_id)
                        user = chat_member.user
                    else:
                        logger.error(f"Не вдалося знайти користувача з ID {user_id}")
                        return None
                except Exception as e:
                    logger.error(f"Не вдалося знайти користувача з ID {user_id}: {e}")
                    return None
            
            return {
                "user_id": user.id,
                "username": user.username or "",
                "full_name": user.full_name or ""
            }
    except Exception as e:
        logger.error(f"Помилка отримання інформації про користувача {identifier}: {e}")
        return None


def save_user_from_update(update: Update):
    """Сохранить пользователя в БД з інформацією з Update"""
    if not update.effective_user:
        return
    
    user_id = update.effective_user.id
    username = update.effective_user.username or ""
    full_name = update.effective_user.full_name or ""
    
    db.add_or_update_user(user_id, username=username, full_name=full_name)

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.message:
        return
    
    # Сохраняем пользователя в БД
    save_user_from_update(update)
    
    help_text = """🎄 SANTA ADMIN BOT

Ласкаво просимо! 👋

/help - показати команди для користувачів"""
    
    await reply_and_delete(update, help_text, delay=60)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Команди для звичайних користувачів"""
    if not update.message:
        return
    
    help_text = """📚 КОМАНДИ ДЛЯ КОРИСТУВАЧІВ

👤 ПЕРСОНАЛЬНІ НАЛАШТУВАННЯ:
/myname - встановити кастомне імʼя (видиме скрізь)
/mym - встановити профіль-гіфку/фото (reply на медіа)
/mymt - встановити опис профілю (до 300 символів)
/hto - переглянути свій профіль (без аргумента)

📝 НОТАТКИ ТА НАГАДУВАННЯ:
/note - зберегти нотатку (для всіх!)
/notes - показати свої нотатки (для всіх!)
/delnote - видалити нотатку за номером (для всіх!)
/reminder - створити нагадування для себе
/reminde - створити нагадування для іншого користувача

🎂 ДНИ НАРОДЖЕННЯ:
/birthdays - показати список днів народження
/addb - додати день народження користувачу

👥 ІНФОРМАЦІЯ:
/alarm - виклик адміністрації
/hto - інформація про користувача
/online_list - показати список адмінів онлайн
/help - показати цю справку
/helpg - команди для гномів (якщо у вас є права)"""
    
    await reply_and_delete(update, help_text, delay=60)

async def help_g_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команди для гномів"""
    save_user_from_update(update)
    if not update.message or not update.effective_user:
        return
    
    user_id = update.effective_user.id
    
    if not is_gnome(user_id) and not is_head_admin(user_id) and not is_owner(user_id):
        await reply_and_delete(update, "❌ Ця команда доступна тільки для гномів, головних адмінів і власника!")
        return
    
    help_text = """🧙 КОМАНДИ ДЛЯ ГНОМІВ

👤 ПЕРСОНАЛЬНІ НАЛАШТУВАННЯ:
/myname - встановити кастомне імʼя (видиме скрізь)
/mym - встановити профіль-гіфку/фото (reply на медіа)
/mymt - встановити опис профілю (до 300 символів)
/hto - переглянути свій профіль (без аргумента)

🗣️ ВІДПРАВЛЕННЯ ПОВІДОМЛЕНЬ:
/say - надіслати повідомлення з підписом
/says - надіслати анонімне повідомлення
/sayon - увімкнути режим авто-відповіді з підписом
/sayson - увімкнути режим анонімних авто-відповідей
/sayoff - вимкнути режим авто-відповіді
/saypin - надіслати і закріпити повідомлення
/save_s - зберегти повідомлення в адмін-чат
/sayb - заблокувати можливість використання /say користувачу
/sayu - розблокувати можливість використання /say користувачу

📢 РОЗСИЛКА:
/broadcast - розсилка повідомлення всім

📝 НОТАТКИ ТА НАГАДУВАННЯ (доступно ДЛЯ ВСІХ):
/note - зберегти нотатку
/notes - показати свої нотатки
/delnote - видалити нотатку за номером
/reminder - створити нагадування для себе
/reminde - створити нагадування для іншого користувача

🎂 ДНИ НАРОДЖЕННЯ:
/birthdays - показати список днів народження
/addb - додати день народження користувачу

👥 ІНФОРМАЦІЯ:
/alarm - виклик адміністрації
/hto - інформація про користувача
/online_list - показати список адмінів онлайн
/help - команди для звичайних користувачів
/helpg - показати цю справку
/helpm - команди для головних адмінів (якщо у вас є права)
/allcmd - команди для власника (якщо у вас є права)"""
    
    await reply_and_delete(update, help_text, delay=60)

async def help_m_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    if not update.effective_user:
        return
    user_id = update.effective_user.id
    
    if not is_head_admin(user_id) and not is_owner(user_id):
        await reply_and_delete(update, "❌ Ця команда доступна тільки для головних адмінів і власника!")
        return
    
    help_text = """👑 КОМАНДИ ДЛЯ ГОЛОВНИХ АДМІНІВ

🔑 УПРАВЛІННЯ АДМІНІСТРАТОРАМИ:
/giveperm - надати ВСІ права адміністратора (reply або /giveperm)
/giveperm_simple - надати звичайні права адміністратора
/removeperm - забрати всі права адміністратора
"Давай права" - текстова команда для надання ВСІ прав
"Дати адмінку звичайну" - текстова команда для звичайних прав

🔧 УПРАВЛІННЯ ГНОМАМИ:
/add_gnome - додати гнома
/remove_gnome - видалити гнома

🚫 МОДЕРАЦІЯ:
/ban_s - тихий бан користувача
/ban_t - публічний бан користувача
/unban_s - тихе розблокування користувача
/unban_t - публічне розблокування користувача
/mute_s - тихий мут користувача
/mute_t - публічний мут користувача
/unmute_s - тихе розмут користувача
/unmute_t - публічне розмут користувача
/kick - вигнати учасника з чату
/nah - додати користувача в чорний список
/del - видалити повідомлення по посиланню або reply

🗣️ ВІДПРАВЛЕННЯ ПОВІДОМЛЕНЬ:
/say - надіслати повідомлення з підписом
/says - надіслати анонімне повідомлення
/sayon - увімкнути режим авто-відповіді з підписом
/sayson - увімкнути режим анонімних авто-відповідей
/sayoff - вимкнути режим авто-відповіді
/sayoffall - вимкнути режим для ВСІХ користувачів
/saypin - надіслати і закріпити повідомлення
/save_s - зберегти повідомлення в адмін-чат
/sayb - заблокувати можливість використання /say користувачу
/sayu - розблокувати можливість використання /say користувачу

📢 РОЗСИЛКА:
/broadcast - розсилка повідомлення всім

🤖 GPT:
/askgpt - запитання до GPT-3.5-turbo

👤 ПЕРСОНАЛЬНІ НАЛАШТУВАННЯ:
/myname - встановити кастомне імʼя (видиме скрізь)

📝 НОТАТКИ ТА НАГАДУВАННЯ (доступно ДЛЯ ВСІХ):
/note - зберегти нотатку
/notes - показати свої нотатки
/delnote - видалити нотатку за номером
/reminder - створити нагадування для себе
/reminde - створити нагадування для іншого користувача

🎂 ДНИ НАРОДЖЕННЯ:
/birthdays - показати список днів народження
/addb - додати день народження користувачу

👥 ІНФОРМАЦІЯ:
/alarm - виклик адміністрації
/hto - інформація про користувача
/online_list - показати список адмінів онлайн
/help - команди для звичайних користувачів
/helpg - команди для гномів
/helpm - показати цю справку
/allcmd - команди для власника (якщо у вас є права)"""
    
    await reply_and_delete(update, help_text, delay=60)

async def allcmd_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Всі команди для власника"""
    if not update.message or not update.effective_user:
        return
    
    help_text = """🌟 ВСІ ДОСТУПНІ КОМАНДИ ВЛАСНИКА

🔑 УПРАВЛІННЯ АДМІНАМИ:
/add_main_admin - додати головного адміна
/remove_main_admin - видалити головного адміна
/giveperm - надати ВСІ права адміністратора (reply або /giveperm)
/giveperm_simple - надати звичайні права адміністратора
/removeperm - забрати всі права адміністратора
/custom_main - встановити кастомне ім'я для головного адміна
"Давай права" - текстова команда для надання ВСІ прав
"Дати адмінку звичайну" - текстова команда для звичайних прав

🔧 УПРАВЛІННЯ ГНОМАМИ:
/add_gnome - додати гнома
/remove_gnome - видалити гнома

🚫 МОДЕРАЦІЯ:
/ban_s - тихий бан користувача
/ban_t - публічний бан користувача
/unban_s - тихе розблокування користувача
/unban_t - публічне розблокування користувача
/mute_s - тихий мут користувача
/mute_t - публічний мут користувача
/unmute_s - тихе розмут користувача
/unmute_t - публічне розмут користувача
/kick - вигнати учасника з чату
/nah - додати користувача в чорний список
/del - видалити повідомлення по посиланню або reply

🗣️ ВІДПРАВЛЕННЯ ПОВІДОМЛЕНЬ:
/say - надіслати повідомлення з підписом
/says - надіслати анонімне повідомлення
/sayon - увімкнути режим авто-відповіді з підписом
/sayson - увімкнути режим анонімних авто-відповідей
/sayoff - вимкнути режим авто-відповіді
/sayoffall - вимкнути режим для ВСІХ користувачів
/saypin - надіслати і закріпити повідомлення
/save_s - зберегти повідомлення в адмін-чат
/sayb - заблокувати можливість використання /say користувачу
/sayu - розблокувати можливість використання /say користувачу
/santas - тихо зберегти повідомлення в канал Санти

📢 РОЗСИЛКА:
/broadcast - розсилка повідомлення всім

🤖 GPT:
/askgpt - запитання до GPT-3.5-turbo

👤 ПЕРСОНАЛЬНІ НАЛАШТУВАННЯ (доступно ДЛЯ ВСІХ):
/myname - встановити кастомне імʼя (видиме скрізь)
/mym - встановити профіль-гіфку/фото (reply на медіа)
/mymt - встановити опис профілю (до 300 символів)
/hto - переглянути свій профіль (без аргумента)
/htop - призначити кастомну посаду користувачу (reply на mensaje)

📝 НОТАТКИ ТА НАГАДУВАННЯ (доступно ДЛЯ ВСІХ):
/note - зберегти нотатку
/notes - показати свої нотатки (можете переглядати чужі за ID)
/delnote - видалити нотатку за номером
/reminder - створити нагадування для себе
/reminde - створити нагадування для іншого користувача

🎂 ДНИ НАРОДЖЕННЯ:
/birthdays - показати список днів народження
/addb - додати день народження користувачу
/setbgif - встановити GIF для привітань днів народження
/setbtext - встановити текст привітань днів народження
/previewb - показати попередній перегляд привітань (текст і GIF)

⚙️ НАЛАШТУВАННЯ:
/adminchat - змінити ID адмін-чату
/userchat - змінити ID чату користувачів
/logchannel - змінити ID каналу логування
/testchannel - змінити ID тестового каналу
/deltimer - встановити таймер видалення відповідей (1-60 сек)
/restart - перезапустити бота

👥 ІНФОРМАЦІЯ:
/alarm - виклик адміністрації
/hto - інформація про користувача
/online_list - показати список адмінів онлайн
/help - команди для звичайних користувачів
/helpg - команди для гномів
/helpm - команди для головних адмінів
/allcmd - показати ВСІ команди (ця справка)"""
    
    await reply_and_delete(update, help_text, delay=60)

async def add_gnome_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_manage_gnomes(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    db.add_role(target_user["user_id"], "gnome", user_id, target_user["full_name"], target_user["username"])
    
    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
    target_name = safe_send_message(target_user["full_name"])
    target_username = f"(@{target_user['username']})" if target_user["username"] else ""
    
    role_text = "Власник" if is_owner(user_id) else "Головний адмін"
    
    message = f"""{role_text}
{admin_name} {admin_username} [{user_id}]
➕ Призначив гномом
{target_name} {target_username} [{target_user['user_id']}]"""
    
    await reply_and_delete(update, f"✅ {target_name} призначений гномом!", delay=60)
    
    await log_to_channel(context, message + "\n#add_gnome")
    db.log_action("add_gnome", user_id, target_user["user_id"], message)

async def remove_gnome_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_manage_gnomes(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    db.remove_role(target_user["user_id"])
    
    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
    target_name = safe_send_message(target_user["full_name"])
    target_username = f"(@{target_user['username']})" if target_user["username"] else ""
    
    role_text = "Власник" if is_owner(user_id) else "Головний адмін"
    
    message = f"""{role_text}
{admin_name} {admin_username} [{user_id}]
➖ Видалив гнома
{target_name} {target_username} [{target_user['user_id']}]"""
    
    await reply_and_delete(update, f"✅ {target_name} видалений з гномів!", delay=60)
    
    await log_to_channel(context, message + "\n#remove_gnome")
    db.log_action("remove_gnome", user_id, target_user["user_id"], message)

async def add_main_admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Тільки власник може додавати головних адмінів!")
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    db.add_role(target_user["user_id"], "head_admin", user_id, target_user["full_name"], target_user["username"])
    
    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
    target_name = safe_send_message(target_user["full_name"])
    target_username = f"(@{target_user['username']})" if target_user["username"] else ""
    
    message = f"""Власник
{admin_name} {admin_username} [{user_id}]
➕ Призначив Головним адміном
{target_name} {target_username} [{target_user['user_id']}]"""
    
    await reply_and_delete(update, f"✅ {target_name} призначений головним адміном!", delay=60)
    
    await log_to_channel(context, message + "\n#add_main_admin")
    db.log_action("add_main_admin", user_id, target_user["user_id"], message)

async def remove_main_admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Тільки власник може видаляти головних адмінів!")
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    db.remove_role(target_user["user_id"])
    
    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
    target_name = safe_send_message(target_user["full_name"])
    target_username = f"(@{target_user['username']})" if target_user["username"] else ""
    
    message = f"""Власник
{admin_name} {admin_username} [{user_id}]
➖ Видалив Головного адміна
{target_name} {target_username} [{target_user['user_id']}]"""
    
    await reply_and_delete(update, f"✅ {target_name} видалений з головних адмінів!", delay=60)
    
    await log_to_channel(context, message + "\n#remove_main_admin")
    db.log_action("remove_main_admin", user_id, target_user["user_id"], message)


async def ban_s_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        logger.info(f"🔍 /ban_s: Пошук користувача за '{identifier}'")
        target_user = await get_user_info(update, context, identifier)
        if not target_user:
            if identifier.isdigit():
                target_user = {"user_id": int(identifier), "username": "", "full_name": ""}
                logger.info(f"✅ /ban_s: Використовую ID {identifier}")
            elif identifier.startswith('@'):
                username = identifier.lstrip('@')
                try:
                    chat = await context.bot.get_chat(username)
                    target_user = {"user_id": chat.id, "username": username, "full_name": chat.full_name or chat.first_name or ""}
                    logger.info(f"✅ /ban_s: Отримано ID для @{username}")
                except Exception as e:
                    logger.warning(f"❌ /ban_s: Помилка з @{username}: {e}")
                    await reply_and_delete(update, f"❌ Не вдалось знайти @{username}. Передайте ID користувача.", delay=60)
                    return
            else:
                logger.warning(f"❌ /ban_s: Користувач '{identifier}' не знайдено")
                await reply_and_delete(update, f"❌ Не вдалося знайти користувача. Спробуйте передати ID замість username!", delay=60)
                return
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    try:
        await context.bot.ban_chat_member(USER_CHAT_ID, target_user["user_id"])
        db.add_ban(target_user["user_id"], user_id, "Тихий бан")
        
        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        admin_username = update.effective_user.username or ""
        target_name = safe_send_message(target_user["full_name"])
        
        log_message = f"""🚷 #BAN
• Хто: {admin_name} (@{admin_username}) [{user_id}]
• Кому: {target_name} [{target_user['user_id']}]
• Група: {USER_CHAT_ID}
#id{target_user['user_id']}"""
        
        await log_to_channel(context, log_message)
        db.log_action("ban_s", user_id, target_user["user_id"], log_message)
    except Exception as e:
        logger.error(f"Помилка бану: {e}")
        await reply_and_delete(update, f"❌ Боту потрібні права або помилка: {e}", delay=60)

async def ban_t_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    reason = "Порушення правил"
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
        reason = " ".join(context.args) if context.args else "Порушення правил"
    elif context.args:
        identifier = context.args[0]
        logger.info(f"🔍 /ban_t: Пошук користувача за '{identifier}'")
        target_user = await get_user_info(update, context, identifier)
        if not target_user:
            if identifier.isdigit():
                target_user = {"user_id": int(identifier), "username": "", "full_name": ""}
                logger.info(f"✅ /ban_t: Використовую ID {identifier}")
            elif identifier.startswith('@'):
                username = identifier.lstrip('@')
                try:
                    chat = await context.bot.get_chat(username)
                    target_user = {"user_id": chat.id, "username": username, "full_name": chat.full_name or chat.first_name or ""}
                    logger.info(f"✅ /ban_t: Отримано ID для @{username}")
                except Exception as e:
                    logger.warning(f"❌ /ban_t: Помилка з @{username}: {e}")
                    await reply_and_delete(update, f"❌ Не вдалось знайти @{username}. Передайте ID користувача.", delay=60)
                    return
            else:
                logger.warning(f"❌ /ban_t: Користувач '{identifier}' не знайдено")
                await reply_and_delete(update, f"❌ Не вдалося знайти користувача. Спробуйте передати ID замість username!", delay=60)
                return
        reason = " ".join(context.args[1:]) if len(context.args) > 1 else "Порушення правил"
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    try:
        # Видаляємо команду
        try:
            await update.message.delete()
        except:
            pass
        
        await context.bot.ban_chat_member(USER_CHAT_ID, target_user["user_id"])
        db.add_ban(target_user["user_id"], user_id, reason)
        
        username_str = f"(@{target_user['username']})" if target_user['username'] else "(видалений аккаунт)"
        admin_str = f"(@{update.effective_user.username})" if update.effective_user.username else ""
        
        msg = await context.bot.send_message(
            chat_id=USER_CHAT_ID,
            text=f"""🚫 Користувач "{target_user['full_name']}" {username_str} заблокований.
ID: {target_user['user_id']}
Ким: {update.effective_user.full_name} {admin_str}
Причина: {reason}""",
            parse_mode=None
        )
        asyncio.create_task(delete_message_after_delay(msg, 60))
        
        try:
            await context.bot.send_message(
                chat_id=target_user["user_id"],
                text=f"Ви були заблоковані. Причина: {reason}",
                parse_mode=None
            )
        except:
            pass
        
        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        admin_username = update.effective_user.username or ""
        target_name = safe_send_message(target_user["full_name"])
        
        log_message = f"""🚷 #BAN
• Хто: {admin_name} (@{admin_username}) [{user_id}]
• Кому: {target_name} [{target_user['user_id']}]
• Причина: {reason}
• Група: {USER_CHAT_ID}
#id{target_user['user_id']}"""
        
        await log_to_channel(context, log_message)
        db.log_action("ban_t", user_id, target_user["user_id"], log_message)
    except Exception as e:
        logger.error(f"Помилка бану: {e}")
        await reply_and_delete(update, f"❌ Боту потрібні права або помилка: {e}", delay=60)

async def unban_s_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
        if not target_user:
            if identifier.isdigit():
                target_user = {"user_id": int(identifier), "username": "", "full_name": ""}
                logger.info(f"✅ /unban_s: Використовую ID {identifier}")
            elif identifier.startswith('@'):
                username = identifier.lstrip('@')
                try:
                    chat = await context.bot.get_chat(username)
                    target_user = {"user_id": chat.id, "username": username, "full_name": chat.full_name or chat.first_name or ""}
                    logger.info(f"✅ /unban_s: Отримано ID для @{username}")
                except Exception as e:
                    logger.warning(f"❌ /unban_s: Помилка з @{username}: {e}")
                    await reply_and_delete(update, f"❌ Не вдалось знайти @{username}. Передайте ID користувача.", delay=60)
                    return
            else:
                logger.warning(f"❌ /unban_s: Користувач '{identifier}' не знайдено")
                await reply_and_delete(update, f"❌ Не вдалося знайти користувача. Спробуйте передати ID замість username!", delay=60)
                return
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    try:
        await context.bot.unban_chat_member(USER_CHAT_ID, target_user["user_id"])
        db.remove_ban(target_user["user_id"])
        
        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        admin_username = update.effective_user.username or ""
        target_name = safe_send_message(target_user["full_name"])
        
        log_message = f"""✅ #UNBAN
• Хто: {admin_name} (@{admin_username}) [{user_id}]
• Кому: {target_name} [{target_user['user_id']}]
• Група: {USER_CHAT_ID}
#id{target_user['user_id']}"""
        
        await log_to_channel(context, log_message)
        db.log_action("unban_s", user_id, target_user["user_id"], log_message)
    except Exception as e:
        logger.error(f"Помилка команди: {e}")
        try:
            await reply_and_delete(update, f"❌ Помилка: {e}", delay=60)
        except:
            pass

async def unban_t_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        logger.info(f"🔍 /unban_t: Пошук користувача за '{identifier}'")
        target_user = await get_user_info(update, context, identifier)
        if target_user:
            logger.info(f"✅ /unban_t: Знайдено користувача: {target_user}")
        else:
            logger.warning(f"❌ /unban_t: Користувач '{identifier}' не знайдено")
            if identifier.isdigit():
                target_user = {
                    "user_id": int(identifier),
                    "username": "",
                    "full_name": ""
                }
                logger.info(f"✅ /unban_t: Використовую ID {identifier}")
            elif identifier.startswith('@'):
                username = identifier.lstrip('@')
                try:
                    chat = await context.bot.get_chat(username)
                    target_user = {
                        "user_id": chat.id,
                        "username": username,
                        "full_name": chat.full_name or chat.first_name or ""
                    }
                    logger.info(f"✅ /unban_t: Отримано ID для @{username}")
                except Exception as e:
                    logger.warning(f"❌ /unban_t: Помилка з @{username}: {e}")
                    await reply_and_delete(update, f"❌ Не вдалось знайти @{username}. Передайте ID користувача.", delay=60)
                    return
            else:
                await reply_and_delete(update, f"❌ Не вдалося знайти користувача. Спробуйте передати ID замість username!", delay=60)
                return
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    try:
        # Видаляємо команду
        try:
            await update.message.delete()
        except:
            pass
        
        await context.bot.unban_chat_member(USER_CHAT_ID, target_user["user_id"])
        db.remove_ban(target_user["user_id"])
        
        username_str = f"(@{target_user['username']})" if target_user['username'] else "(видалений аккаунт)"
        admin_str = f"(@{update.effective_user.username})" if update.effective_user.username else ""
        
        msg = await context.bot.send_message(
            chat_id=USER_CHAT_ID,
            text=f"""✅ Користувач "{target_user['full_name']}" {username_str} розблокований.
ID: {target_user['user_id']}
Ким: {update.effective_user.full_name} {admin_str}""",
            parse_mode=None
        )
        asyncio.create_task(delete_message_after_delay(msg, 60))
        
        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        admin_username = update.effective_user.username or ""
        target_name = safe_send_message(target_user["full_name"])
        
        log_message = f"""✅ #UNBAN
• Хто: {admin_name} (@{admin_username}) [{user_id}]
• Кому: {target_name} [{target_user['user_id']}]
• Група: {USER_CHAT_ID}
#id{target_user['user_id']}"""
        
        await log_to_channel(context, log_message)
        db.log_action("unban_t", user_id, target_user["user_id"], log_message)
    except Exception as e:
        logger.error(f"Помилка команди: {e}")
        try:
            await reply_and_delete(update, f"❌ Помилка: {e}", delay=60)
        except:
            pass

async def mute_s_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        logger.info(f"🔍 /mute_s: Пошук користувача за '{identifier}'")
        target_user = await get_user_info(update, context, identifier)
        if not target_user:
            if identifier.isdigit():
                target_user = {"user_id": int(identifier), "username": "", "full_name": ""}
                logger.info(f"✅ /mute_s: Використовую ID {identifier}")
            elif identifier.startswith('@'):
                username = identifier.lstrip('@')
                try:
                    chat = await context.bot.get_chat(username)
                    target_user = {"user_id": chat.id, "username": username, "full_name": chat.full_name or chat.first_name or ""}
                    logger.info(f"✅ /mute_s: Отримано ID для @{username}")
                except Exception as e:
                    logger.warning(f"❌ /mute_s: Помилка з @{username}: {e}")
                    await reply_and_delete(update, f"❌ Не вдалось знайти @{username}. Передайте ID користувача.", delay=60)
                    return
            else:
                logger.warning(f"❌ /mute_s: Користувач '{identifier}' не знайдено")
                await reply_and_delete(update, f"❌ Не вдалося знайти користувача. Спробуйте передати ID замість username!", delay=60)
                return
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    try:
        permissions = ChatPermissions(can_send_messages=False)
        await context.bot.restrict_chat_member(USER_CHAT_ID, target_user["user_id"], permissions)
        db.add_mute(target_user["user_id"], user_id, "Тихий мут")
        
        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        admin_username = update.effective_user.username or ""
        target_name = safe_send_message(target_user["full_name"])
        
        log_message = f"""🔇 #MUTE
• Хто: {admin_name} (@{admin_username}) [{user_id}]
• Кому: {target_name} [{target_user['user_id']}]
• Група: {USER_CHAT_ID}
#id{target_user['user_id']}"""
        
        await log_to_channel(context, log_message)
        db.log_action("mute_s", user_id, target_user["user_id"], log_message)
    except Exception as e:
        await reply_and_delete(update, f"❌ Боту потрібні права або помилка: {e}", delay=60)

async def mute_t_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    reason = "Порушення правил"
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
        reason = " ".join(context.args) if context.args else "Порушення правил"
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
        if not target_user:
            if identifier.isdigit():
                target_user = {"user_id": int(identifier), "username": "", "full_name": ""}
                logger.info(f"✅ /mute_t: Використовую ID {identifier}")
            elif identifier.startswith('@'):
                username = identifier.lstrip('@')
                try:
                    chat = await context.bot.get_chat(username)
                    target_user = {"user_id": chat.id, "username": username, "full_name": chat.full_name or chat.first_name or ""}
                    logger.info(f"✅ /mute_t: Отримано ID для @{username}")
                except Exception as e:
                    logger.warning(f"❌ /mute_t: Помилка з @{username}: {e}")
                    await reply_and_delete(update, f"❌ Не вдалось знайти @{username}. Передайте ID користувача.", delay=60)
                    return
            else:
                logger.warning(f"❌ /mute_t: Користувач '{identifier}' не знайдено")
                await reply_and_delete(update, f"❌ Не вдалося знайти користувача. Спробуйте передати ID замість username!", delay=60)
                return
        reason = " ".join(context.args[1:]) if len(context.args) > 1 else "Порушення правил"
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    try:
        # Видаляємо команду
        try:
            await update.message.delete()
        except:
            pass
        
        permissions = ChatPermissions(can_send_messages=False)
        await context.bot.restrict_chat_member(USER_CHAT_ID, target_user["user_id"], permissions)
        db.add_mute(target_user["user_id"], user_id, reason)
        
        username_str = f"(@{target_user['username']})" if target_user['username'] else "(видалений аккаунт)"
        admin_str = f"(@{update.effective_user.username})" if update.effective_user.username else ""
        
        msg = await context.bot.send_message(
            chat_id=USER_CHAT_ID,
            text=f"""🔇 Користувач "{target_user['full_name']}" {username_str} замучений.
ID: {target_user['user_id']}
Ким: {update.effective_user.full_name} {admin_str}
Причина: {reason}""",
            parse_mode=None
        )
        asyncio.create_task(delete_message_after_delay(msg, 60))
        
        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        admin_username = update.effective_user.username or ""
        target_name = safe_send_message(target_user["full_name"])
        
        log_message = f"""🔇 #MUTE
• Хто: {admin_name} (@{admin_username}) [{user_id}]
• Кому: {target_name} [{target_user['user_id']}]
• Причина: {reason}
• Група: {USER_CHAT_ID}
#id{target_user['user_id']}"""
        
        await log_to_channel(context, log_message)
        db.log_action("mute_t", user_id, target_user["user_id"], log_message)
    except Exception as e:
        await reply_and_delete(update, f"❌ Боту потрібні права або помилка: {e}", delay=60)

async def unmute_s_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        logger.info(f"🔍 /unmute_s: Пошук користувача за '{identifier}'")
        target_user = await get_user_info(update, context, identifier)
        if not target_user:
            if identifier.isdigit():
                target_user = {"user_id": int(identifier), "username": "", "full_name": ""}
                logger.info(f"✅ /unmute_s: Використовую ID {identifier}")
            elif identifier.startswith('@'):
                username = identifier.lstrip('@')
                try:
                    chat = await context.bot.get_chat(username)
                    target_user = {"user_id": chat.id, "username": username, "full_name": chat.full_name or chat.first_name or ""}
                    logger.info(f"✅ /unmute_s: Отримано ID для @{username}")
                except Exception as e:
                    logger.warning(f"❌ /unmute_s: Помилка з @{username}: {e}")
                    await reply_and_delete(update, f"❌ Не вдалось знайти @{username}. Передайте ID користувача.", delay=60)
                    return
            else:
                logger.warning(f"❌ /unmute_s: Користувач '{identifier}' не знайдено")
                await reply_and_delete(update, f"❌ Не вдалося знайти користувача. Спробуйте передати ID замість username!", delay=60)
                return
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    try:
        permissions = ChatPermissions(
            can_send_messages=True,
            can_send_polls=True,
            can_send_other_messages=True,
            can_add_web_page_previews=True
        )
        await context.bot.restrict_chat_member(USER_CHAT_ID, target_user["user_id"], permissions)
        db.remove_mute(target_user["user_id"])
        
        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        admin_username = update.effective_user.username or ""
        target_name = safe_send_message(target_user["full_name"])
        
        log_message = f"""🔊 #UNMUTE
• Хто: {admin_name} (@{admin_username}) [{user_id}]
• Кому: {target_name} [{target_user['user_id']}]
• Група: {USER_CHAT_ID}
#id{target_user['user_id']}"""
        
        await log_to_channel(context, log_message)
        db.log_action("unmute_s", user_id, target_user["user_id"], log_message)
    except Exception as e:
        logger.error(f"Помилка команди: {e}")
        try:
            await reply_and_delete(update, f"❌ Помилка: {e}", delay=60)
        except:
            pass

async def unmute_t_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        logger.info(f"🔍 /unmute_t: Пошук користувача за '{identifier}'")
        target_user = await get_user_info(update, context, identifier)
        if not target_user:
            if identifier.isdigit():
                target_user = {"user_id": int(identifier), "username": "", "full_name": ""}
                logger.info(f"✅ /unmute_t: Використовую ID {identifier}")
            elif identifier.startswith('@'):
                username = identifier.lstrip('@')
                try:
                    chat = await context.bot.get_chat(username)
                    target_user = {"user_id": chat.id, "username": username, "full_name": chat.full_name or chat.first_name or ""}
                    logger.info(f"✅ /unmute_t: Отримано ID для @{username}")
                except Exception as e:
                    logger.warning(f"❌ /unmute_t: Помилка з @{username}: {e}")
                    await reply_and_delete(update, f"❌ Не вдалось знайти @{username}. Передайте ID користувача.", delay=60)
                    return
            else:
                logger.warning(f"❌ /unmute_t: Користувач '{identifier}' не знайдено")
                await reply_and_delete(update, f"❌ Не вдалося знайти користувача. Спробуйте передати ID замість username!", delay=60)
                return
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    try:
        # Видаляємо команду
        try:
            await update.message.delete()
        except:
            pass
        
        permissions = ChatPermissions(
            can_send_messages=True,
            can_send_polls=True,
            can_send_other_messages=True,
            can_add_web_page_previews=True
        )
        await context.bot.restrict_chat_member(USER_CHAT_ID, target_user["user_id"], permissions)
        db.remove_mute(target_user["user_id"])
        
        username_str = f"(@{target_user['username']})" if target_user['username'] else "(видалений аккаунт)"
        admin_str = f"(@{update.effective_user.username})" if update.effective_user.username else ""
        
        msg = await context.bot.send_message(
            chat_id=USER_CHAT_ID,
            text=f"""🔊 Користувач "{target_user['full_name']}" {username_str} розмучений.
ID: {target_user['user_id']}
Ким: {update.effective_user.full_name} {admin_str}""",
            parse_mode=None
        )
        asyncio.create_task(delete_message_after_delay(msg, 60))
        
        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        admin_username = update.effective_user.username or ""
        target_name = safe_send_message(target_user["full_name"])
        
        log_message = f"""🔊 #UNMUTE
• Хто: {admin_name} (@{admin_username}) [{user_id}]
• Кому: {target_name} [{target_user['user_id']}]
• Група: {USER_CHAT_ID}
#id{target_user['user_id']}"""
        
        await log_to_channel(context, log_message)
        db.log_action("unmute_t", user_id, target_user["user_id"], log_message)
    except Exception as e:
        logger.error(f"Помилка команди: {e}")
        try:
            await reply_and_delete(update, f"❌ Помилка: {e}", delay=60)
        except:
            pass

async def kick_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    try:
        await context.bot.ban_chat_member(USER_CHAT_ID, target_user["user_id"])
        await context.bot.unban_chat_member(USER_CHAT_ID, target_user["user_id"])
        
        username_str = f"(@{target_user['username']})" if target_user['username'] else "(видалений аккаунт)"
        admin_str = f"(@{update.effective_user.username})" if update.effective_user.username else ""
        
        msg = await context.bot.send_message(
            chat_id=USER_CHAT_ID,
            text=f"""⚠️ Користувач "{target_user['full_name']}" {username_str} виганений з чату.
ID: {target_user['user_id']}
Ким: {update.effective_user.full_name} {admin_str}""",
            parse_mode=None
        )
        asyncio.create_task(delete_message_after_delay(msg, 60))
        
        await reply_and_delete(update, "✅ Користувача вигнано з чату", delay=0)
        db.log_action("kick", user_id, target_user["user_id"])
    except Exception as e:
        await reply_and_delete(update, f"❌ Боту потрібні права або помилка: {e}", delay=60)

async def nah_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Тільки власник може додавати в чорний список!")
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!")
        return
    
    db.add_to_blacklist(target_user["user_id"], user_id, "Чорний список")
    
    try:
        await context.bot.ban_chat_member(USER_CHAT_ID, target_user["user_id"])
    except:
        pass
    
    await reply_and_delete(update, f"✅ {target_user['full_name']} додано в чорний список!", delay=0)
    
    # Логування в канал
    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    admin_username = update.effective_user.username or ""
    target_name = safe_send_message(target_user["full_name"])
    
    log_message = f"""🚫 #BLACKLIST
• Хто: {admin_name} (@{admin_username}) [{user_id}]
• Кому: {target_name} [{target_user['user_id']}]
• Група: {USER_CHAT_ID}
#id{target_user['user_id']}"""
    
    await log_to_channel(context, log_message)
    db.log_action("blacklist", user_id, target_user["user_id"], log_message)


async def say_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message or not update.effective_chat:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    if db.is_say_blocked(user_id):
        await reply_and_delete(update, "❌ Вашу можливість використання /say заблоковано!")
        return
    
    if not USER_CHAT_ID:
        await reply_and_delete(update, "❌ Не налаштовано чат користувачів!")
        return
    
    author_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    username = f"@{safe_send_message(update.effective_user.username)}" if update.effective_user.username else ""
    signature = f"— {author_name} {username}"
    
    try:
        if update.message.reply_to_message:
            replied_message = update.message.reply_to_message
            
            # Якщо вказаний текст після /say - відправити як reply в USER_CHAT_ID
            if context.args:
                message_text = ' '.join(context.args)
                clean_message = safe_send_message(message_text)
                final_message = f"{clean_message}\n\n{signature}"
                
                await context.bot.send_message(
                    chat_id=USER_CHAT_ID,
                    text=final_message,
                    reply_to_message_id=replied_message.message_id,
                    parse_mode=None,
                    disable_web_page_preview=True
                )
                logger.info(f"📤 /say: текст від {user_id} як reply на {replied_message.message_id} відправлено в USER_CHAT_ID")
            else:
                # Без тексту - пересилати саме повідомлення в USER_CHAT_ID
                if replied_message.text:
                    clean_message = safe_send_message(replied_message.text)
                    final_message = f"{clean_message}\n\n{signature}"
                    await context.bot.send_message(
                        chat_id=USER_CHAT_ID,
                        text=final_message,
                        parse_mode=None,
                        disable_web_page_preview=True
                    )
                elif replied_message.caption:
                    clean_caption = safe_send_message(replied_message.caption)
                    final_message = f"{clean_caption}\n\n{signature}"
                    await context.bot.send_message(
                        chat_id=USER_CHAT_ID,
                        text=final_message,
                        parse_mode=None,
                        disable_web_page_preview=True
                    )
                else:
                    if update.effective_chat:
                        await context.bot.forward_message(
                            chat_id=USER_CHAT_ID,
                            from_chat_id=update.effective_chat.id,
                            message_id=replied_message.message_id
                        )
                    await context.bot.send_message(
                        chat_id=USER_CHAT_ID,
                        text=signature,
                        parse_mode=None,
                        disable_web_page_preview=True
                    )
                logger.info(f"📤 /say: повідомлення від {user_id} пересилано в USER_CHAT_ID")
        elif context.args:
            message_text = ' '.join(context.args)
            
            # Перевіримо чи це посилання на Telegram повідомлення
            reply_to_id = None
            target_chat_id = USER_CHAT_ID
            
            # Шукаємо посилання у тексту
            link_match = re.search(r'https?://t\.me/c/\d+/\d+', message_text)
            if link_match:
                link = link_match.group()
                parsed_chat_id, parsed_message_id = parse_telegram_link(link)
                
                if parsed_chat_id and parsed_message_id:
                    # Видаляємо посилання з тексту
                    text_without_link = message_text.replace(link, '').strip()
                    clean_message = safe_send_message(text_without_link)
                    target_chat_id = parsed_chat_id
                    reply_to_id = parsed_message_id
                    final_message = f"{clean_message}\n\n{signature}"
                    logger.info(f"📤 /say: текст в чат {target_chat_id} reply на {reply_to_id}")
                else:
                    clean_message = safe_send_message(message_text)
                    final_message = f"{clean_message}\n\n{signature}"
                    logger.info(f"📤 /say: невірне посилання в тексті")
            else:
                clean_message = safe_send_message(message_text)
                final_message = f"{clean_message}\n\n{signature}"
            
            await context.bot.send_message(
                chat_id=target_chat_id,
                text=final_message,
                reply_to_message_id=reply_to_id,
                parse_mode=None,
                disable_web_page_preview=True
            )
            logger.info(f"📤 /say: текст від {user_id} відправлено")
            db.log_action("say", user_id, details=f"Message sent to user chat")
        else:
            await reply_and_delete(update, "❌ Вкажіть повідомлення після команди або відповідьте на повідомлення!", delay=0)
            return
        
            pass
        
    except Exception as e:
        try:
            await reply_and_delete(update, f"❌ Помилка відправки: {e}", delay=0)
        except:
            pass

async def says_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    
    if not update.effective_user or not update.message or not update.effective_chat:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    if db.is_say_blocked(user_id):
        await reply_and_delete(update, "❌ Вашу можливість використання /says заблоковано!")
        return
    
    if not USER_CHAT_ID:
        await reply_and_delete(update, "❌ Не налаштовано чат користувачів!")
        return
    
    try:
        if update.message.reply_to_message:
            replied_message = update.message.reply_to_message
            
            # Якщо вказаний текст після /says - відправити як reply в USER_CHAT_ID (анонімно)
            if context.args:
                message_text = ' '.join(context.args)
                clean_message = safe_send_message(message_text)
                
                await context.bot.send_message(
                    chat_id=USER_CHAT_ID,
                    text=clean_message,
                    reply_to_message_id=replied_message.message_id,
                    parse_mode=None,
                    disable_web_page_preview=True
                )
                logger.info(f"📤 /says: анонімний текст від {user_id} як reply на {replied_message.message_id} відправлено в USER_CHAT_ID")
            else:
                # Без тексту - пересилати саме повідомлення в USER_CHAT_ID
                if replied_message.text:
                    clean_message = safe_send_message(replied_message.text)
                    await context.bot.send_message(
                        chat_id=USER_CHAT_ID,
                        text=clean_message,
                        parse_mode=None,
                        disable_web_page_preview=True
                    )
                elif replied_message.caption:
                    clean_caption = safe_send_message(replied_message.caption)
                    await context.bot.send_message(
                        chat_id=USER_CHAT_ID,
                        text=clean_caption,
                        parse_mode=None,
                        disable_web_page_preview=True
                    )
                else:
                    if update.effective_chat:
                        await context.bot.forward_message(
                            chat_id=USER_CHAT_ID,
                            from_chat_id=update.effective_chat.id,
                            message_id=replied_message.message_id
                        )
                logger.info(f"📤 /says: повідомлення від {user_id} пересилано в USER_CHAT_ID")
        elif context.args:
            message_text = ' '.join(context.args)
            
            # Перевіримо чи це посилання на Telegram повідомлення
            reply_to_id = None
            target_chat_id = USER_CHAT_ID
            
            # Шукаємо посилання у тексту
            link_match = re.search(r'https?://t\.me/c/\d+/\d+', message_text)
            if link_match:
                link = link_match.group()
                parsed_chat_id, parsed_message_id = parse_telegram_link(link)
                
                if parsed_chat_id and parsed_message_id:
                    # Видаляємо посилання з тексту
                    text_without_link = message_text.replace(link, '').strip()
                    clean_message = safe_send_message(text_without_link)
                    target_chat_id = parsed_chat_id
                    reply_to_id = parsed_message_id
                    logger.info(f"📤 /says: текст в чат {target_chat_id} reply на {reply_to_id}")
                else:
                    clean_message = safe_send_message(message_text)
                    logger.info(f"📤 /says: невірне посилання в тексті")
            else:
                clean_message = safe_send_message(message_text)
            
            await context.bot.send_message(
                chat_id=target_chat_id,
                text=clean_message,
                reply_to_message_id=reply_to_id,
                parse_mode=None,
                disable_web_page_preview=True
            )
            logger.info(f"📤 /says: текст від {user_id} відправлено")
            db.log_action("says", user_id, details="Anonymous message sent to user chat")
        else:
            await reply_and_delete(update, "❌ Вкажіть повідомлення після команди або відповідьте на повідомлення!", delay=0)
            return
        
            pass
        
    except Exception as e:
        try:
            await reply_and_delete(update, f"❌ Помилка відправки: {e}", delay=0)
        except:
            pass

async def sayon_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    if db.is_say_blocked(user_id):
        await reply_and_delete(update, "❌ Вашу можливість використання sayon заблоковано!")
        return
    
    current_mode = db.get_online_mode(user_id)
    
    if current_mode == "sayon":
        db.remove_online_mode(user_id)
        await reply_and_delete(update, "✅ Режим sayon вимкнено")
        
        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
        
        log_message = f"""Власник/Адмін
{admin_name} {admin_username} [{user_id}]
Автоматичне пересилання з підписом вимкнено
#sayoff #id{user_id}"""
        
        await log_to_channel(context, log_message)
    else:
        source_chat_id = update.effective_chat.id if update.effective_chat else 0
        db.set_online_mode(user_id, "sayon", source_chat_id)
        await reply_and_delete(update, "✅ Режим sayon увімкнено! Ваші повідомлення будуть автоматично пересилатися з підписом.\nРежим вимкнеться автоматично через 5 хвилин неактивності.")
        
        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
        
        role_text = "Власник" if is_owner(user_id) else ("Головний адмін" if is_head_admin(user_id) else "Гном")
        
        log_message = f"""{role_text}
{admin_name} {admin_username} [{user_id}]
Автоматичне пересилання з підписом увімкнено
#sayon #id{user_id}"""
        
        await log_to_channel(context, log_message)

async def sayson_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    if db.is_say_blocked(user_id):
        await reply_and_delete(update, "❌ Вашу можливість використання sayson заблоковано!")
        return
    
    current_mode = db.get_online_mode(user_id)
    
    if current_mode == "sayson":
        db.remove_online_mode(user_id)
        await reply_and_delete(update, "✅ Режим sayson вимкнено")
        
        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
        
        log_message = f"""Власник/Адмін
{admin_name} {admin_username} [{user_id}]
Автоматичне пересилання без підпису вимкнено
#saysoff #id{user_id}"""
        
        await log_to_channel(context, log_message)
    else:
        source_chat_id = update.effective_chat.id if update.effective_chat else 0
        db.set_online_mode(user_id, "sayson", source_chat_id)
        await reply_and_delete(update, "✅ Режим sayson увімкнено! Ваші повідомлення будуть автоматично пересилатися анонімно.\nРежим вимкнеться автоматично через 5 хвилин неактивності.")
        
        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
        
        role_text = "Власник" if is_owner(user_id) else ("Головний адмін" if is_head_admin(user_id) else "Гном")
        
        log_message = f"""{role_text}
{admin_name} {admin_username} [{user_id}]
Автоматичне пересилання без підпису увімкнено
#sayson #id{user_id}"""
        
        await log_to_channel(context, log_message)

async def sayoff_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    current_mode = db.get_online_mode(user_id)
    
    if not current_mode:
        await reply_and_delete(update, "❌ Режим не вмикнено!")
        return
    
    db.remove_online_mode(user_id)
    await reply_and_delete(update, "✅ Режим вимкнено")
    
    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
    
    mode_text = "з підписом" if current_mode == "sayon" else "анонімно"
    log_message = f"""Власник/Адмін
{admin_name} {admin_username} [{user_id}]
Автоматичне пересилання {mode_text} вимкнено
#sayoff #id{user_id}"""
    
    await log_to_channel(context, log_message)

async def sayoffall_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ Тільки власник і головні адміни мають доступ до цієї команди!")
        return
    
    all_modes = db.get_all_online_modes()
    
    if not all_modes:
        await reply_and_delete(update, "❌ Немає активних режимів!")
        return
    
    count = len(all_modes)
    db.clear_all_online_modes()
    await reply_and_delete(update, f"✅ Вимкнено режим для {count} користувачів")
    
    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
    role_text = "Власник" if is_owner(user_id) else "Головний адмін"
    
    modes_list = "\n".join([f"• {m['full_name'] or m['user_id']} ({m['mode']})" for m in all_modes])
    
    log_message = f"""{role_text}
{admin_name} {admin_username} [{user_id}]
Вимкнено режими для {count} користувачів:
{modes_list}
#sayoffall"""
    
    await log_to_channel(context, log_message)

async def del_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Видалити повідомлення (тільки власник)"""
    save_user_from_update(update)
    
    if not update.effective_user or not update.message or not update.effective_chat:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Ця команда доступна тільки для власника!")
        return
    
    try:
        # Способ 1: Reply на повідомлення
        if update.message.reply_to_message:
            message_to_delete = update.message.reply_to_message
            chat_id = update.effective_chat.id
            message_id = message_to_delete.message_id
            
            # Отримуємо інформацію про автора та вміст повідомлення ДО видалення
            message_author = message_to_delete.from_user
            is_bot_message = message_author.is_bot if message_author else False
            author_name = safe_send_message(message_author.full_name or "Невідомий") if message_author else "Невідомий"
            
            # Зберігаємо вміст повідомлення
            message_text = message_to_delete.text or message_to_delete.caption or ""
            has_photo = message_to_delete.photo is not None
            has_animation = message_to_delete.animation is not None
            has_video = message_to_delete.video is not None
            
            media_file_id = None
            media_type = None
            if has_photo:
                media_file_id = message_to_delete.photo[-1].file_id
                media_type = "photo"
            elif has_animation:
                media_file_id = message_to_delete.animation.file_id
                media_type = "animation"
            elif has_video:
                media_file_id = message_to_delete.video.file_id
                media_type = "video"
            
            await context.bot.delete_message(chat_id=chat_id, message_id=message_id)
            
            # Визначаємо тип повідомлення для логування
            msg_type = "🤖 повідомлення бота" if is_bot_message else "повідомлення"
            
            await reply_and_delete(update, f"✅ {msg_type.capitalize()} видалено!", delay=0)
            logger.info(f"🗑️ {msg_type} #{message_id} видалено в чаті {chat_id} власником {user_id}")
            
            # Логуємо в канал
            if LOG_CHANNEL_ID:
                try:
                    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
                    admin_username = update.effective_user.username or ""
                    bot_emoji = "🤖" if is_bot_message else "💬"
                    
                    # Якщо є медіа - пересилаємо медіа з інформацією
                    if media_file_id:
                        caption = f"{admin_name} (@{admin_username}) [{user_id}]\n🗑️ видалив {msg_type}\n{bot_emoji} Автор: {author_name}\n• Чат: {chat_id}\n• Message ID: {message_id}"
                        if message_text:
                            caption += f"\n\n📝 Текст:\n{message_text[:500]}"
                        
                        if media_type == "photo":
                            await context.bot.send_photo(chat_id=LOG_CHANNEL_ID, photo=media_file_id, caption=caption, parse_mode=None)
                        elif media_type == "animation":
                            await context.bot.send_animation(chat_id=LOG_CHANNEL_ID, animation=media_file_id, caption=caption, parse_mode=None)
                        elif media_type == "video":
                            await context.bot.send_video(chat_id=LOG_CHANNEL_ID, video=media_file_id, caption=caption, parse_mode=None)
                    else:
                        # Якщо немає медіа - надсилаємо текстовий лог
                        log_text = f"{admin_name} (@{admin_username}) [{user_id}]\n🗑️ видалив {msg_type}\n{bot_emoji} Автор: {author_name}\n• Чат: {chat_id}\n• Message ID: {message_id}"
                        if message_text:
                            log_text += f"\n\n📝 Текст:\n{message_text[:500]}"
                        
                        await context.bot.send_message(chat_id=LOG_CHANNEL_ID, text=log_text, parse_mode=None)
                except Exception as e:
                    logger.warning(f"⚠️ Помилка при логуванні видалення в канал: {e}")
        
        # Способ 2: Посилання на повідомлення
        elif context.args:
            link = context.args[0]
            parsed_chat_id, parsed_message_id = parse_telegram_link(link)
            
            if parsed_chat_id and parsed_message_id:
                # Намагаємося отримати інформацію про повідомлення перед видаленням
                message_info = None
                is_bot_message = False
                author_name = "Невідомо"
                message_text = ""
                media_file_id = None
                media_type = None
                
                try:
                    message_info = await context.bot.get_message(chat_id=parsed_chat_id, message_id=parsed_message_id)
                    message_author = message_info.from_user
                    is_bot_message = message_author.is_bot if message_author else False
                    author_name = safe_send_message(message_author.full_name or "Невідомий") if message_author else "Невідомий"
                    
                    # Зберігаємо вміст повідомлення
                    message_text = message_info.text or message_info.caption or ""
                    
                    # Отримуємо медіа якщо є
                    if message_info.photo:
                        media_file_id = message_info.photo[-1].file_id
                        media_type = "photo"
                    elif message_info.animation:
                        media_file_id = message_info.animation.file_id
                        media_type = "animation"
                    elif message_info.video:
                        media_file_id = message_info.video.file_id
                        media_type = "video"
                except Exception as get_msg_error:
                    logger.warning(f"⚠️ Не вдалось отримати інформацію про повідомлення: {get_msg_error}")
                
                await context.bot.delete_message(chat_id=parsed_chat_id, message_id=parsed_message_id)
                
                # Визначаємо тип повідомлення для логування
                msg_type = "🤖 повідомлення бота" if is_bot_message else "повідомлення"
                
                await reply_and_delete(update, f"✅ {msg_type.capitalize()} видалено!", delay=0)
                logger.info(f"🗑️ {msg_type} #{parsed_message_id} видалено в чаті {parsed_chat_id} власником {user_id}")
                
                # Логуємо в канал
                if LOG_CHANNEL_ID:
                    try:
                        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
                        admin_username = update.effective_user.username or ""
                        bot_emoji = "🤖" if is_bot_message else "💬"
                        
                        # Якщо є медіа - пересилаємо медіа з інформацією
                        if media_file_id:
                            caption = f"{admin_name} (@{admin_username}) [{user_id}]\n🗑️ видалив {msg_type} по посиланню\n{bot_emoji} Автор: {author_name}\n• Чат: {parsed_chat_id}\n• Message ID: {parsed_message_id}"
                            if message_text:
                                caption += f"\n\n📝 Текст:\n{message_text[:500]}"
                            
                            if media_type == "photo":
                                await context.bot.send_photo(chat_id=LOG_CHANNEL_ID, photo=media_file_id, caption=caption, parse_mode=None)
                            elif media_type == "animation":
                                await context.bot.send_animation(chat_id=LOG_CHANNEL_ID, animation=media_file_id, caption=caption, parse_mode=None)
                            elif media_type == "video":
                                await context.bot.send_video(chat_id=LOG_CHANNEL_ID, video=media_file_id, caption=caption, parse_mode=None)
                        else:
                            # Якщо немає медіа - надсилаємо текстовий лог
                            log_text = f"{admin_name} (@{admin_username}) [{user_id}]\n🗑️ видалив {msg_type} по посиланню\n{bot_emoji} Автор: {author_name}\n• Чат: {parsed_chat_id}\n• Message ID: {parsed_message_id}"
                            if message_text:
                                log_text += f"\n\n📝 Текст:\n{message_text[:500]}"
                            
                            await context.bot.send_message(chat_id=LOG_CHANNEL_ID, text=log_text, parse_mode=None)
                    except Exception as e:
                        logger.warning(f"⚠️ Помилка при логуванні видалення в канал: {e}")
            else:
                await reply_and_delete(update, "❌ Невірне посилання! Приклад: /del https://t.me/c/2646171857/771721", delay=60)
        else:
            await reply_and_delete(update, "❌ Використання:\n1️⃣ /del (відповідь на повідомлення)\n2️⃣ /del https://t.me/c/2646171857/771721", delay=60)
    
    except Exception as e:
        logger.error(f"❌ Помилка при видаленні повідомлення: {e}")
        try:
            await reply_and_delete(update, f"❌ Помилка при видаленні: {str(e)[:100]}", delay=60)
        except:
            pass

async def askgpt_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Запитання до GPT"""
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not GPT_API_KEY:
        await reply_and_delete(update, "❌ GPT_API_KEY не встановлено! Попросіть власника налаштувати бота.")
        return
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть запитання для GPT!\n\nПриклад: /askgpt Як зробити паста?", delay=60)
        return
    
    question = " ".join(context.args)
    
    # Перевіримо довжину запитання
    if len(question) > 2000:
        await reply_and_delete(update, "❌ Запитання занадто довге (максимум 2000 символів)!", delay=60)
        return
    
    # Відправляємо "печатает" індикатор
    typing_msg = await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="🤖 Запитую GPT...",
        parse_mode=None
    )
    
    try:
        # Звернення до OpenAI API
        client = OpenAI(api_key=GPT_API_KEY)
        
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "user", "content": question}
            ],
            temperature=0.7,
            max_tokens=1500
        )
        
        gpt_answer = response.choices[0].message.content.strip()
        
        logger.info(f"🤖 GPT відповідь отримана від користувача {user_id}")
        
        # Формуємо відповідь
        response_text = f"🤖 <b>GPT Відповідь:</b>\n\n{gpt_answer}"
        
        # Видаляємо "печатает" повідомлення
        try:
            await typing_msg.delete()
        except:
            pass
        
        # Відправляємо відповідь
        sent_msg = await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=response_text,
            parse_mode="HTML"
        )
        
        # Видаляємо команду
        try:
            await update.message.delete()
        except:
            pass
        
        # Видаляємо відповідь через таймер
        asyncio.create_task(delete_message_after_delay(sent_msg, MESSAGE_DELETE_TIMER))
        
        # Логуємо в канал
        user_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        username = update.effective_user.username or ""
        
        log_message = f"""🤖 #ASKGPT
• Користувач: {user_name} (@{username}) [{user_id}]
• Запитання: {question[:100]}...
• Відповідь: {gpt_answer[:200]}...
• Група: {update.effective_chat.id}
#id{user_id}"""
        
        await log_to_channel(context, log_message)
        
    except Exception as e:
        logger.error(f"❌ Помилка при запиті до GPT: {e}")
        
        # Видаляємо "печатает" повідомлення
        try:
            await typing_msg.delete()
        except:
            pass
        
        error_text = f"❌ Помилка при запиті до GPT:\n{str(e)[:200]}"
        await reply_and_delete(update, error_text, delay=60)

async def quit_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Бот покидає чат (тільки для власника)"""
    if not update.effective_user or not update.message or not update.effective_chat:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Ця команда доступна тільки для власника!")
        return
    
    chat_id = update.effective_chat.id
    
    try:
        # Відправляємо прощальне повідомлення
        farewell_text = "Ви образали мого хозяїна, я йду від вас і бажаю вам всім найти Тернопіль"
        farewell_msg = await context.bot.send_message(
            chat_id=chat_id,
            text=farewell_text,
            parse_mode=None
        )
        
        # Логуємо вихід в канал
        if LOG_CHANNEL_ID:
            try:
                admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
                admin_username = update.effective_user.username or ""
                log_text = f"{admin_name} (@{admin_username}) [{user_id}]\n👋 виключив бота з чату\n• Чат: {chat_id}"
                await context.bot.send_message(
                    chat_id=LOG_CHANNEL_ID,
                    text=log_text,
                    parse_mode=None
                )
            except Exception as e:
                logger.warning(f"⚠️ Помилка при логуванні виходу бота в канал: {e}")
        
        logger.info(f"👋 Власник {user_id} почав вихід бота з чату {chat_id}")
        
        # Даємо 2 секунди на відправку повідомлення
        await asyncio.sleep(2)
        
        # Вихід з чату
        await context.bot.leave_chat(chat_id)
        logger.info(f"✅ Бот вийшов з чату {chat_id}")
        
    except Exception as e:
        logger.error(f"❌ Помилка при виході бота: {e}")
        try:
            await reply_and_delete(update, f"❌ Помилка при виході: {e}")
        except:
            pass

async def handle_all_messages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.effective_user or not update.message or not update.effective_chat:
        return
    
    # Обробка команди "Виходимо підарас"
    if update.message.text:
        text_lower = update.message.text.strip().lower()
        if text_lower == "виходимо підарас":
            user_id = update.effective_user.id
            if is_owner(user_id):
                await quit_command(update, context)
                return
        
        # Обробка команди "Давай права"
        if text_lower == "давай права":
            await giveperm_command(update, context)
            return
        
        # Обробка команди "Дати адмінку звичайну" ТА "Дати звичайну адмінку"
        if text_lower == "дати адмінку звичайну" or text_lower == "дати звичайну адмінку":
            await giveperm_simple_command(update, context)
            return
    
    # Видаляємо ВСІ повідомлення що починаються з "/"
    if update.message.text and update.message.text.startswith('/'):
        try:
            await update.message.delete()
        except:
            pass  # Не вдалось видалити команду
    
    # Сохраняем всех пользователей в БД при первом сообщении
    save_user_from_update(update)
    
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    
    if not can_use_bot(user_id):
        return
    
    # Обробка команд видалення профілю простим текстом (з дефісом на початку)
    if update.message.text and update.message.text.startswith('-'):
        text = update.message.text.strip()
        
        # -myname - видалити кастомне імʼя
        if text == '-myname':
            await del_myname_command(update, context)
            return
        
        # -mym - видалити профіль-фото
        elif text == '-mym':
            await del_mym_command(update, context)
            return
        
        # -mymt - видалити опис профілю
        elif text == '-mymt':
            await del_mymt_command(update, context)
            return
        
        # -htop @username - видалити посаду
        elif text.startswith('-htop'):
            parts = text.split(maxsplit=1)
            if len(parts) > 1:
                # Створюємо fake context.args для del_htop_command
                context.args = parts[1].split()
            else:
                context.args = []
            await del_htop_command(update, context)
            return
    
    if not USER_CHAT_ID:
        logger.error("❌ USER_CHAT_ID не встановлено!")
        return
    
    mode = db.get_online_mode(user_id)
    source_chat_id = db.get_online_mode_source(user_id)
    
    if not mode or source_chat_id != chat_id:
        return
    
    logger.info(f"📨 Пересилаємо ({mode}): user={user_id}, from_chat={chat_id}, to_chat={USER_CHAT_ID}")
    
    db.update_online_activity(user_id)
    
    try:
        if mode == "sayon":
            author_name = safe_send_message(update.effective_user.full_name or "Невідомий")
            username = f"@{safe_send_message(update.effective_user.username)}" if update.effective_user.username else ""
            signature = f"\n\n— {author_name} {username}"
            
            if update.message.text:
                clean_message = safe_send_message(update.message.text)
                await context.bot.send_message(
                    chat_id=USER_CHAT_ID,
                    text=f"{clean_message}{signature}",
                    parse_mode=None,
                    disable_web_page_preview=True
                )
            elif update.message.caption:
                clean_caption = safe_send_message(update.message.caption)
                await context.bot.send_message(
                    chat_id=USER_CHAT_ID,
                    text=f"{clean_caption}{signature}",
                    parse_mode=None,
                    disable_web_page_preview=True
                )
            else:
                await context.bot.forward_message(
                    chat_id=USER_CHAT_ID,
                    from_chat_id=chat_id,
                    message_id=update.message.message_id
                )
                await context.bot.send_message(
                    chat_id=USER_CHAT_ID,
                    text=signature.strip(),
                    parse_mode=None
                )
        
        elif mode == "sayson":
            if update.message.text:
                clean_message = safe_send_message(update.message.text)
                await context.bot.send_message(
                    chat_id=USER_CHAT_ID,
                    text=clean_message,
                    parse_mode=None,
                    disable_web_page_preview=True
                )
            elif update.message.caption:
                clean_caption = safe_send_message(update.message.caption)
                await context.bot.send_message(
                    chat_id=USER_CHAT_ID,
                    text=clean_caption,
                    parse_mode=None,
                    disable_web_page_preview=True
                )
            else:
                await context.bot.forward_message(
                    chat_id=USER_CHAT_ID,
                    from_chat_id=chat_id,
                    message_id=update.message.message_id
                )
        
        logger.info(f"✅ Повідомлення успішно пересилано")
    except Exception as e:
        logger.error(f"❌ Помилка автопересилання: {e}")


async def saypin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message or not update.effective_chat:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    if not USER_CHAT_ID:
        await reply_and_delete(update, "❌ Не налаштовано чат користувачів!")
        return
    
    try:
        sent_message = None
        
        if update.message.reply_to_message:
            replied_message = update.message.reply_to_message
            
            if replied_message.text:
                clean_message = safe_send_message(replied_message.text)
                sent_message = await context.bot.send_message(
                    chat_id=USER_CHAT_ID,
                    text=clean_message,
                    parse_mode=None,
                    disable_web_page_preview=True
                )
            elif replied_message.caption:
                clean_caption = safe_send_message(replied_message.caption)
                sent_message = await context.bot.send_message(
                    chat_id=USER_CHAT_ID,
                    text=clean_caption,
                    parse_mode=None,
                    disable_web_page_preview=True
                )
            else:
                sent_message = await context.bot.forward_message(
                    chat_id=USER_CHAT_ID,
                    from_chat_id=update.effective_chat.id,
                    message_id=replied_message.message_id
                )
        elif context.args:
            message_text = ' '.join(context.args)
            clean_message = safe_send_message(message_text)
            sent_message = await context.bot.send_message(
                chat_id=USER_CHAT_ID,
                text=clean_message,
                parse_mode=None,
                disable_web_page_preview=True
            )
        else:
            await reply_and_delete(update, "❌ Вкажіть повідомлення після команди або відповідьте на повідомлення!")
            return
        
        if sent_message:
            await context.bot.pin_chat_message(USER_CHAT_ID, sent_message.message_id)
        
        await reply_and_delete(update, "✅ Повідомлення відправлено і закріплено!")
        
    except Exception as e:
        logger.error(f"Помилка: {e}")
        await reply_and_delete(update, f"❌ Помилка: {e}")

async def save_s_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message or not update.effective_chat:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    if not update.message.reply_to_message:
        await reply_and_delete(update, "❌ Відповідьте на повідомлення яке потрібно зберегти!")
        return
    
    try:
        if not ADMIN_CHAT_ID:
            await reply_and_delete(update, "❌ Адмін-чат не налаштовано!")
            return
        
        replied_msg = update.message.reply_to_message
        
        # Спочатку спробуємо скопіювати (працює з bot messages і захищеним контентом)
        try:
            await context.bot.copy_message(
                chat_id=ADMIN_CHAT_ID,
                from_chat_id=update.effective_chat.id,
                message_id=replied_msg.message_id
            )
            logger.info(f"✅ Повідомлення скопійовано")
        except Exception as copy_error:
            logger.warning(f"⚠️ Помилка копіювання: {copy_error}, спробую альтернативний метод...")
            
            # Визначаємо тип медіа для логування
            media_type = "невідомо"
            if replied_msg.sticker:
                media_type = "стікер 📌"
            elif replied_msg.photo:
                media_type = "фото 🖼️"
            elif replied_msg.video:
                media_type = "відео 🎬"
            elif replied_msg.animation:
                media_type = "гіфка 🎞️"
            elif replied_msg.document:
                media_type = "документ 📎"
            elif replied_msg.audio:
                media_type = "аудіо 🎵"
            elif replied_msg.text:
                media_type = "текст 📝"
            
            logger.info(f"📤 Тип контенту: {media_type}")
            
            # Якщо копіювання не спрацює, пересилаємо
            try:
                await context.bot.forward_message(
                    chat_id=ADMIN_CHAT_ID,
                    from_chat_id=update.effective_chat.id,
                    message_id=replied_msg.message_id
                )
                logger.info(f"✅ Повідомлення пересилано ({media_type})")
            except Exception as forward_error:
                logger.warning(f"⚠️ Помилка пересилання: {forward_error}, копіюю вміст...")
                
                # Останній варіант - копіюємо вміст (перевіряємо МЕДІА перед ТЕКСТОМ)
                if replied_msg.sticker:
                    logger.info("📌 Копіюю стікер")
                    await context.bot.send_sticker(
                        chat_id=ADMIN_CHAT_ID,
                        sticker=replied_msg.sticker.file_id
                    )
                elif replied_msg.photo:
                    logger.info("🖼️ Копіюю фото")
                    await context.bot.send_photo(
                        chat_id=ADMIN_CHAT_ID,
                        photo=replied_msg.photo[-1].file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.video:
                    logger.info("🎬 Копіюю відео")
                    await context.bot.send_video(
                        chat_id=ADMIN_CHAT_ID,
                        video=replied_msg.video.file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.animation:
                    logger.info("🎞️ Копіюю гіфку")
                    await context.bot.send_animation(
                        chat_id=ADMIN_CHAT_ID,
                        animation=replied_msg.animation.file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.document:
                    logger.info("📎 Копіюю документ")
                    await context.bot.send_document(
                        chat_id=ADMIN_CHAT_ID,
                        document=replied_msg.document.file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.audio:
                    logger.info("🎵 Копіюю аудіо")
                    await context.bot.send_audio(
                        chat_id=ADMIN_CHAT_ID,
                        audio=replied_msg.audio.file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.text:
                    logger.info("📝 Копіюю текст")
                    await context.bot.send_message(
                        chat_id=ADMIN_CHAT_ID,
                        text=replied_msg.text,
                        parse_mode=None
                    )
                else:
                    logger.warning("❓ Невідомий тип повідомлення")
                    await context.bot.send_message(
                        chat_id=ADMIN_CHAT_ID,
                        text="[Повідомлення без тексту]"
                    )
        
        # Тихе збереження - без повідомлення користувачеві
        try:
            await update.message.delete()
        except:
            pass
        
    except Exception as e:
        await reply_and_delete(update, f"❌ Помилка при збереженні: {e}")

async def online_list_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    online_modes = db.get_all_online_modes()
    
    if not online_modes:
        await reply_and_delete(update, "📵 Немає адмінів в онлайн-режимі")
        return
    
    message = "📱 **Адміни в онлайн-режимі:**\n\n"
    
    for mode_data in online_modes:
        name = mode_data.get("full_name", "Невідомий")
        username = f"(@{mode_data.get('username')})" if mode_data.get("username") else ""
        mode = "sayon (з підписом)" if mode_data["mode"] == "sayon" else "sayson (анонімно)"
        message += f"• {name} {username}\n  Режим: {mode}\n\n"
    
    await reply_and_delete(update, message)

async def sayb_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_manage_gnomes(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!")
        return
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть ID користувача!")
        return
    
    try:
        target_id = int(context.args[0])
        
        if is_owner(target_id) and not is_owner(user_id):
            await reply_and_delete(update, "❌ Не можна блокувати власника!")
            return
        
        if is_head_admin(target_id) and not is_owner(user_id):
            await reply_and_delete(update, "❌ Тільки власник може блокувати головних адмінів!")
            return
        
        db.block_say_command(target_id, user_id, 
                             update.effective_user.full_name or "", update.effective_user.username or "")
        await reply_and_delete(update, f"✅ Користувач {target_id} заблокований від використання /say та /says")
        db.log_action("sayb", user_id, target_id)
        
    except ValueError:
        await reply_and_delete(update, "❌ Невірний ID!")

async def sayu_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_manage_gnomes(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!")
        return
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть ID користувача!")
        return
    
    try:
        target_id = int(context.args[0])
        db.unblock_say_command(target_id)
        await reply_and_delete(update, f"✅ Користувач {target_id} розблокований для використання /say та /says")
        db.log_action("sayu", user_id, target_id)
        
    except ValueError:
        await reply_and_delete(update, "❌ Невірний ID!")


async def alarm_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    user_name = update.effective_user.full_name or "Невідомий"
    username = update.effective_user.username or ""
    
    alarm_text = " ".join(context.args) if context.args else "Виклик адміністрації"
    
    message_link = ""
    if update.message.reply_to_message:
        chat_id = str(USER_CHAT_ID).replace("-100", "")
        message_link = f"\n👀 Дивитись повідомлення: http://t.me/c/{chat_id}/{update.message.reply_to_message.message_id}"
    
    alarm_message = f"""🚨 #ALARM
Користувач: {user_name} (@{username}) [{user_id}]
Текст: {alarm_text}{message_link}
#id{user_id}"""
    
    try:
        sent_msg = await context.bot.send_message(
            chat_id=ADMIN_CHAT_ID,
            text=alarm_message,
            parse_mode=None
        )
        
        try:
            await context.bot.pin_chat_message(ADMIN_CHAT_ID, sent_msg.message_id)
        except:
            pass
        
        # Логування в канал
        if LOG_CHANNEL_ID:
            try:
                await context.bot.send_message(
                    chat_id=LOG_CHANNEL_ID,
                    text=alarm_message,
                    parse_mode=None
                )
            except Exception as e:
                logger.warning(f"⚠️ Помилка при логуванні тривоги в канал: {e}")
        
        await reply_and_delete(update, "✅ Передано на перегляд адміністрації, очікуйте.")
        
    except Exception as e:
        logger.error(f"Помилка alarm: {e}")

async def broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!")
        return
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть текст для розсилки!")
        return
    
    message_text = " ".join(context.args)
    clean_message = safe_send_message(message_text)
    
    await reply_and_delete(update, f"📢 Розпочато розсилку повідомлення всім користувачам...")
    
    all_users = db.get_all_users()
    sent_count = 0
    failed_count = 0
    
    logger.info(f"🔊 Розсилка розпочата: {len(all_users)} користувачів")
    
    for target_user_id in all_users:
        try:
            await context.bot.send_message(
                chat_id=target_user_id,
                text=clean_message,
                parse_mode=None
            )
            sent_count += 1
        except Exception as e:
            failed_count += 1
            logger.warning(f"⚠️ Не вдалось отправити користувачу {target_user_id}: {e}")
    
    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    admin_username = f"@{update.effective_user.username}" if update.effective_user.username else ""
    
    result_message = f"""✅ Розсилка завершена!
📤 Отправлено: {sent_count}
❌ Помилок: {failed_count}
👤 Адмін: {admin_name} {admin_username}
📝 Текст: {clean_message}"""
    
    await reply_and_delete(update, result_message)
    
    logger.info(f"✅ Розсилка завершена: {sent_count} успішно, {failed_count} помилок")

async def hto_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Розширена інформація про користувача з профіль-системою"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    target_user_id = user_id
    target_user_name = update.effective_user.full_name or "Невідомий"
    target_username = update.effective_user.username or ""
    
    # Перевіряємо чи це адмін (гном, головний адмін або власник)
    is_admin = is_gnome(user_id) or is_head_admin(user_id) or is_owner(user_id)
    
    # Якщо є аргумент (@username або ID) - адміни можуть переглядати чужих
    if context.args:
        if not is_admin:
            await reply_and_delete(update, "❌ Тільки адміни можуть переглядати інших користувачів!", delay=60)
            return
        
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
        if target_user:
            target_user_id = target_user["user_id"]
            target_user_name = target_user["full_name"]
            target_username = target_user["username"]
        else:
            await reply_and_delete(update, "❌ Користувача не знайдено!", delay=60)
            return
    # Без аргументів і без reply - показуємо інформацію про себе
    elif update.message.reply_to_message and update.message.reply_to_message.from_user:
        # Якщо є reply - адміни можуть переглядати чужих
        if is_admin or user_id == update.message.reply_to_message.from_user.id:
            target_user_id = update.message.reply_to_message.from_user.id
            target_user_name = update.message.reply_to_message.from_user.full_name or "Невідомий"
            target_username = update.message.reply_to_message.from_user.username or ""
        else:
            await reply_and_delete(update, "❌ Ви можете переглядати тільки свій профіль!", delay=60)
            return
    
    user_data = db.get_user(target_user_id)
    custom_name = db.get_custom_name(target_user_id)
    profile_desc = db.get_profile_description(target_user_id)
    custom_position = db.get_custom_position(target_user_id)
    
    # Визначаємо посаду - перевіряємо через функції
    if is_owner(target_user_id):
        position_display = "👑 Власник"
    elif is_head_admin(target_user_id):
        position_display = "🔒 Головний Адмін"
    elif is_gnome(target_user_id):
        position_display = "🧙 Гном"
    else:
        position_display = "👤 Користувач"
    
    # Якщо є кастомна посада - додаємо
    if custom_position:
        position_display += f" ({custom_position})"
    
    info_message = f"""👤 ПРОФІЛЬ КОРИСТУВАЧА

"""
    
    # Кастомне імʼя (якщо є)
    if custom_name:
        info_message += f"📝 Імʼя: {custom_name}\n"
    else:
        info_message += f"📝 Імʼя: {target_user_name}\n"
    
    # Опис профілю (якщо є)
    if profile_desc:
        info_message += f"📄 Про себе: {profile_desc}\n"
    
    info_message += f"""
@{target_username if target_username else 'не вказано'}
ID: {target_user_id}
{position_display}
"""
    
    if user_data and user_data.get("joined_at"):
        # Форматуємо дату: день.місяць.рік - години:хвилини
        try:
            from datetime import datetime
            joined_dt = datetime.fromisoformat(user_data['joined_at'])
            formatted_date = joined_dt.strftime("%d.%m.%Y - %H:%M")
            info_message += f"📅 Дата вступу: {formatted_date}\n"
        except:
            info_message += f"📅 Дата вступу: {user_data['joined_at']}\n"
    
    # Додаємо день народження якщо є
    if user_data and user_data.get("birth_date"):
        info_message += f"🎂 День народження: {user_data['birth_date']}\n"
    
    # Отримуємо профіль-фото якщо є
    profile_pic = db.get_profile_picture(target_user_id)
    if profile_pic:
        try:
            # Якщо є фото/гіфка - надсилаємо її з описом
            if profile_pic["media_type"] == "photo":
                sent_msg = await context.bot.send_photo(
                    chat_id=update.message.chat_id,
                    photo=profile_pic["file_id"],
                    caption=info_message,
                    parse_mode="HTML"
                )
                # Видаляємо через 60 секунд (1 хвилина)
                asyncio.create_task(delete_message_after_delay(sent_msg, 60))
            elif profile_pic["media_type"] == "gif":
                sent_msg = await context.bot.send_animation(
                    chat_id=update.message.chat_id,
                    animation=profile_pic["file_id"],
                    caption=info_message,
                    parse_mode="HTML"
                )
                # Видаляємо через 60 секунд (1 хвилина)
                asyncio.create_task(delete_message_after_delay(sent_msg, 60))
        except Exception as e:
            logger.warning(f"⚠️ Не вдалось надіслати профіль-фото з описом: {e}")
            # Якщо помилка - просто надіслемо текст
            await reply_and_delete(update, info_message, delay=60)
    else:
        # Якщо немає фото - просто надіслемо текст
        await reply_and_delete(update, info_message, delay=60)

async def note_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Зберегти нотатку - доступно для всіх користувачів"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть текст нотатки!\nПриклад: /note важливе завдання на завтра")
        return
    
    note_text = " ".join(context.args)
    db.add_note(user_id, note_text)
    
    try:
        if NOTES_CHANNEL_ID:
            user_name = update.effective_user.full_name or "Невідомий"
            username = f"@{update.effective_user.username}" if update.effective_user.username else ""
            
            note_message = f"""📝 Нотатка від {user_name} {username} [{user_id}]

{note_text}

#id{user_id}"""
            
            await context.bot.send_message(
                chat_id=NOTES_CHANNEL_ID,
                text=note_message,
                parse_mode=None
            )
        
        await reply_and_delete(update, "✅ Нотатку збережено!")
        
    except Exception as e:
        logger.error(f"Помилка збереження нотатки: {e}")
        await reply_and_delete(update, f"❌ Помилка: {e}")

async def notes_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Показати нотатки - кожен користувач видит тільки свої (вінні власник може видіти чужі)"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    target_id = user_id
    
    # Тільки власник може переглядати нотатки інших користувачів
    if context.args and is_owner(user_id):
        try:
            target_id = int(context.args[0])
        except:
            identifier = context.args[0]
            target_user = await get_user_info(update, context, identifier)
            if target_user:
                target_id = target_user["user_id"]
    
    notes = db.get_notes(target_id)
    
    if not notes:
        await reply_and_delete(update, "📝 Нотаток не знайдено")
        return
    
    # Отримуємо ім'я користувача для заголовка
    user_info = db.get_user(target_id)
    user_name = user_info.get("full_name", "Невідомий") if user_info else "Невідомий"
    
    message = f"📝 Нотатки користувача {user_name} [{target_id}]:\n\n"
    
    for idx, note in enumerate(notes, 1):
        formatted_time = format_kyiv_time(note['created_at'])
        message += f"{idx}. {note['text']}\n   ({formatted_time})\n\n"
    
    await reply_and_delete(update, message)

async def delnote_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Видалити нотатку за номером - доступно для всіх користувачів (тільки свої)"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть номер нотатки для видалення!\nПриклад: /delnote 1")
        return
    
    try:
        note_number = int(context.args[0])
    except ValueError:
        await reply_and_delete(update, "❌ Вкажіть число! Приклад: /delnote 1")
        return
    
    # Отримуємо всі нотатки користувача
    notes = db.get_notes(user_id)
    
    if not notes:
        await reply_and_delete(update, "📝 У вас немає нотаток!")
        return
    
    if note_number < 1 or note_number > len(notes):
        await reply_and_delete(update, f"❌ Нотатка номер {note_number} не знайдена! У вас {len(notes)} нотаток.")
        return
    
    # Видаляємо нотатку (нотатки у db.get_notes() впорядковані від нових до старих)
    note_to_delete = notes[note_number - 1]
    note_id = note_to_delete['id']
    note_text = note_to_delete['text']
    
    if db.delete_note(note_id):
        await reply_and_delete(update, f"✅ Нотатка видалена!\n📝 Текст: {note_text[:50]}...")
        logger.info(f"🗑️ Нотатка #{note_id} видалена користувачем {user_id}")
        
        # Логування в канал
        username_str = f"@{update.effective_user.username}" if update.effective_user.username else ""
        log_text = f"{update.effective_user.full_name} ({username_str}) [{user_id}]\n🗑️ видалив нотатку\n📝 {note_text[:100]}\n• Група: {USER_CHAT_ID}"
        
        try:
            await context.bot.send_message(
                chat_id=LOG_CHANNEL_ID,
                text=log_text,
                parse_mode=None
            )
        except Exception as e:
            logger.warning(f"⚠️ Помилка при логуванні видалення нотатки в канал: {e}")
    else:
        await reply_and_delete(update, "❌ Помилка при видаленні нотатки!")

async def deltimer_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Встановити таймер автоматичного видалення відповідей (1-60 секунд)"""
    global MESSAGE_DELETE_TIMER
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Ця команда доступна тільки для власника!")
        return
    
    if not context.args:
        await reply_and_delete(update, f"⏱️ Поточний таймер видалення: {MESSAGE_DELETE_TIMER} секунд\n\nЯк змінити: /deltimer [1-60]\nПриклад: /deltimer 10", delay=60)
        return
    
    try:
        delay = int(context.args[0])
        
        if delay < 1 or delay > 60:
            await reply_and_delete(update, "❌ Таймер має бути від 1 до 60 секунд!\nПриклад: /deltimer 5", delay=60)
            return
        
        MESSAGE_DELETE_TIMER = delay
        save_config()
        logger.info(f"✅ /deltimer: встановлено таймер на {delay} сек")
        
        await reply_and_delete(update, f"✅ Таймер встановлено на {delay} сек!\n⏱️ Усі повідомлення бота видаляються через {delay} сек.", delay=60)
        logger.info(f"⏱️ Власник {user_id} встановив таймер видалення на {delay} секунд")
        
        if LOG_CHANNEL_ID:
            try:
                await context.bot.send_message(
                    chat_id=LOG_CHANNEL_ID,
                    text=f"⏱️ Таймер видалення змінено на {delay} секунд\nВласник: {update.effective_user.full_name}"
                )
            except:
                pass
    except ValueError:
        await reply_and_delete(update, "❌ Вкажіть число від 1 до 60!\nПриклад: /deltimer 5", delay=60)

async def restart_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global RESTART_BOT
    save_user_from_update(update)
    """Перезапустити бота (тільки для власника)"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Ця команда доступна тільки для власника!")
        return
    
    await reply_and_delete(update, "✅ Бот успішно перезавантажено! ⚡", delay=3)
    logger.info(f"🔄 Бот перезавантажено власником {user_id}")
    
    # Встановлюємо флаг перезапуску
    RESTART_BOT = True
    # Даємо час на відправку повідомлення
    await asyncio.sleep(0.5)
    # Зупиняємо додаток
    await context.application.stop()

async def myname_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Встановити кастомне імʼя (видиме скрізь в команді)"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    if not context.args:
        current_name = db.get_custom_name(user_id)
        if current_name:
            await reply_and_delete(update, f"📝 Ваше кастомне імʼя: {current_name}\n\nЯк використовувати: /myname [нове імʼя]\nЩоб видалити: /myname - або /myname clear", delay=60)
        else:
            await reply_and_delete(update, "❌ Вкажіть імʼя!\nПриклад: /myname Мій Нік\nЩоб видалити: /myname - або /myname clear", delay=60)
        return
    
    custom_name = ' '.join(context.args)
    
    # Видалення кастомного імʼя
    if custom_name in ['-', 'clear']:
        old_name = db.get_custom_name(user_id)
        if db.delete_custom_name(user_id):
            old_name_text = f" ({old_name})" if old_name else ""
            await reply_and_delete(update, f"✅ Кастомне імʼя{old_name_text} видалено! Тепер видиме стандартне імʼя.", delay=60)
            logger.info(f"🗑️ Видалено кастомне імʼя '{old_name}' користувачем {user_id}")
            
            # Логування в канал
            if LOG_CHANNEL_ID:
                try:
                    username_str = f"@{update.effective_user.username}" if update.effective_user.username else ""
                    log_text = f"{update.effective_user.full_name} ({username_str}) [{user_id}]\n🗑️ видалив імʼя\n• Група: {USER_CHAT_ID}"
                    await context.bot.send_message(
                        chat_id=LOG_CHANNEL_ID,
                        text=log_text
                    )
                except Exception as e:
                    logger.warning(f"⚠️ Помилка при логуванні видалення імʼя в канал: {e}")
        else:
            await reply_and_delete(update, "❌ Помилка при видаленні кастомного імʼя!", delay=60)
        return
    
    # Встановлення нового імʼя
    if len(custom_name) > 100:
        await reply_and_delete(update, "❌ Імʼя занадто довге (максимум 100 символів)!", delay=60)
        return
    
    if db.set_custom_name(user_id, custom_name):
        await reply_and_delete(update, f"✅ Кастомне імʼя встановлено!\n📝 Ваше нове імʼя: {custom_name}\n\nТепер воно буде видиме скрізь!", delay=60)
        logger.info(f"✏️ Користувач {user_id} встановив кастомне імʼя: {custom_name}")
        
        # Логування в канал
        if LOG_CHANNEL_ID:
            try:
                username_str = f"@{update.effective_user.username}" if update.effective_user.username else ""
                log_text = f"{update.effective_user.full_name} ({username_str}) [{user_id}]\n✏️ встановив імʼя\n({custom_name})\n• Група: {USER_CHAT_ID}"
                await context.bot.send_message(
                    chat_id=LOG_CHANNEL_ID,
                    text=log_text
                )
            except Exception as e:
                logger.warning(f"⚠️ Помилка при логуванні імʼя в канал: {e}")
    else:
        await reply_and_delete(update, "❌ Помилка при встановленні кастомного імʼя!", delay=60)

async def mym_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Встановити профіль-гіфку або фото, або видалити (-) """
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    # Видалення фото/гіфки
    if context.args and context.args[0] == '-':
        pic = db.get_profile_picture(user_id)
        old_pic_text = f" ({pic['media_type']})" if pic else ""
        if db.delete_profile_picture(user_id):
            await reply_and_delete(update, f"✅ Профіль-фото{old_pic_text} видалено! Тепер видиме стандартне.", delay=60)
            logger.info(f"🗑️ Видалено профіль-фото користувачем {user_id}")
            
            # Логування в канал
            if LOG_CHANNEL_ID:
                try:
                    username_str = f"@{update.effective_user.username}" if update.effective_user.username else ""
                    log_text = f"{update.effective_user.full_name} ({username_str}) [{user_id}]\n🗑️ видалив медіа опис\n• Група: {USER_CHAT_ID}"
                    await context.bot.send_message(
                        chat_id=LOG_CHANNEL_ID,
                        text=log_text
                    )
                except Exception as e:
                    logger.warning(f"⚠️ Помилка при логуванні видалення фото в канал: {e}")
        else:
            await reply_and_delete(update, "❌ Помилка при видаленні фото!", delay=60)
        return
    
    # Перевіряємо чи це reply на медіа
    if not update.message.reply_to_message:
        await reply_and_delete(update, "❌ Відповідьте на гіфку або фото!\nЩоб видалити: /mym -", delay=60)
        return
    
    reply = update.message.reply_to_message
    
    if reply.animation:
        # Це гіфка
        file_id = reply.animation.file_id
        media_type = "gif"
        emoji = "🎬"
    elif reply.photo:
        # Це фото
        file_id = reply.photo[-1].file_id
        media_type = "photo"
        emoji = "🖼️"
    else:
        await reply_and_delete(update, "❌ Це не гіфка і не фото!", delay=60)
        return
    
    if db.set_profile_picture(user_id, media_type, file_id):
        await reply_and_delete(update, f"✅ Профіль-{emoji} встановлено!", delay=60)
        logger.info(f"🖼️ Користувач {user_id} встановив профіль-{media_type}")
        
        # Логування в канал з медіа
        if LOG_CHANNEL_ID:
            try:
                username_str = f"@{update.effective_user.username}" if update.effective_user.username else ""
                caption = f"{update.effective_user.full_name} ({username_str}) [{user_id}]\n{emoji} встановив медіа опис\n• Група: {USER_CHAT_ID}"
                if media_type == "gif":
                    await context.bot.send_animation(
                        chat_id=LOG_CHANNEL_ID,
                        animation=file_id,
                        caption=caption,
                        parse_mode=None
                    )
                elif media_type == "photo":
                    await context.bot.send_photo(
                        chat_id=LOG_CHANNEL_ID,
                        photo=file_id,
                        caption=caption,
                        parse_mode=None
                    )
                logger.info(f"📤 Профіль-{media_type} логовано в канал для {user_id}")
            except Exception as e:
                logger.warning(f"⚠️ Помилка при логуванні профіль-{media_type} в канал: {e}")
    else:
        await reply_and_delete(update, "❌ Помилка при встановленні фото!", delay=60)
async def mymt_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Встановити опис профілю або видалити (-)"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not context.args:
        current_desc = db.get_profile_description(user_id)
        if current_desc:
            await reply_and_delete(update, f"📄 Ваш опис: {current_desc}\n\nЯк використовувати: /mymt [новий опис]\nЩоб видалити: /mymt - або /mymt clear", delay=60)
        else:
            await reply_and_delete(update, "❌ Вкажіть опис!\nПриклад: /mymt Я люблю програмування\nЩоб видалити: /mymt - або /mymt clear", delay=60)
        return
    
    description = " ".join(context.args)
    
    # Видалення опису
    if description in ['-', 'clear']:
        old_desc = db.get_profile_description(user_id)
        if db.delete_profile_description(user_id):
            old_desc_text = f" ({old_desc})" if old_desc else ""
            await reply_and_delete(update, f"✅ Опис профілю{old_desc_text} видалено! Тепер видиме стандартне.", delay=60)
            logger.info(f"🗑️ Видалено опис профілю '{old_desc}' користувачем {user_id}")
            
            # Логування в канал
            if LOG_CHANNEL_ID:
                try:
                    username_str = f"@{update.effective_user.username}" if update.effective_user.username else ""
                    log_text = f"{update.effective_user.full_name} ({username_str}) [{user_id}]\n🗑️ видалив опис\n• Група: {USER_CHAT_ID}"
                    await context.bot.send_message(
                        chat_id=LOG_CHANNEL_ID,
                        text=log_text
                    )
                except Exception as e:
                    logger.warning(f"⚠️ Помилка при логуванні видалення опису в канал: {e}")
        else:
            await reply_and_delete(update, "❌ Помилка при видаленні опису!", delay=60)
        return
    
    # Встановлення нового опису
    if len(description) > 300:
        await reply_and_delete(update, "❌ Опис занадто довгий (максимум 300 символів)!", delay=60)
        return
    
    if db.set_profile_description(user_id, description):
        await reply_and_delete(update, f"✅ Опис профілю встановлено!\n📄 {description}", delay=60)
        logger.info(f"📝 Користувач {user_id} встановив опис: {description}")
        
        # Логування в канал
        if LOG_CHANNEL_ID:
            try:
                username_str = f"@{update.effective_user.username}" if update.effective_user.username else ""
                log_text = f"{update.effective_user.full_name} ({username_str}) [{user_id}]\n📝 оновив опис\n({description})\n• Група: {USER_CHAT_ID}"
                await context.bot.send_message(
                    chat_id=LOG_CHANNEL_ID,
                    text=log_text
                )
            except Exception as e:
                logger.warning(f"⚠️ Помилка при логуванні опису в канал: {e}")
    else:
        await reply_and_delete(update, "❌ Помилка при встановленні опису!", delay=60)
async def htop_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Призначити кастомну посаду користувачу через reply або @username/ID"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Ця команда доступна тільки для власника!")
        return
    
    target_user_id = None
    target_user_name = None
    position = None
    
    # Способ 1: Reply на повідомлення
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user_id = update.message.reply_to_message.from_user.id
        target_user_name = update.message.reply_to_message.from_user.full_name or "Невідомий"
        if context.args:
            position = " ".join(context.args)
    # Способ 2: @username або ID як перший аргумент
    elif context.args and len(context.args) >= 1:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
        if target_user:
            target_user_id = target_user["user_id"]
            target_user_name = target_user["full_name"]
            # Посада - усі аргументи крім першого
            if len(context.args) > 1:
                position = " ".join(context.args[1:])
        else:
            await reply_and_delete(update, "❌ Користувача не знайдено!", delay=60)
            return
    else:
        await reply_and_delete(update, "❌ Використовуйте:\n/htop [посада] (reply на повідомлення)\nабо\n/htop @username [посада]\nабо\n/htop ID [посада]", delay=60)
        return
    
    if not target_user_id or not target_user_name:
        await reply_and_delete(update, """❌ Користувача не знайдено!

Можливі причини:
• Користувач ніколи не писав в цей бот/групу
• Невірно введене ім'я (@username)
• Акаунт приватний або видалений

Спробуйте:
• Впевніться, що користувач є членом групи
• Попросіть його написати хоча б 1 повідомлення
• Используйте ID замість @username (якщо знаєте ID)
• Reply на його повідомлення і /htop [посада]""", delay=60)
        return
    
    # Якщо немає позиції - показуємо поточну або просимо вказати
    if not position:
        current_pos = db.get_custom_position(target_user_id)
        if current_pos:
            await reply_and_delete(update, f"✅ Поточна посада {target_user_name}: {current_pos}\n\nЯк встановити нову:\n/htop @{target_user_name} [посада]\nЩоб видалити: /htop {target_user_id} -", delay=60)
        else:
            await reply_and_delete(update, f"❌ Вкажіть посаду для {target_user_name}!\nПриклад: /htop @{target_user_name} Старший розробник\nЩоб видалити: /htop {target_user_id} -", delay=60)
        return
    
    # Видалення посади
    if position in ['-', 'clear']:
        current_pos = db.get_custom_position(target_user_id)
        if db.delete_custom_position(target_user_id):
            old_pos_text = f" ({current_pos})" if current_pos else ""
            await reply_and_delete(update, f"✅ Посаду {target_user_name}{old_pos_text} видалено! Тепер видиме стандартна посада.", delay=60)
            logger.info(f"🗑️ Власник видалив посаду користувача {target_user_id}: {current_pos}")
        else:
            await reply_and_delete(update, "❌ Помилка при видаленні посади!", delay=60)
        return
    
    # Встановлення нової посади
    if len(position) > 50:
        await reply_and_delete(update, "❌ Посада занадто довга (максимум 50 символів)!", delay=60)
        return
    
    if db.set_custom_position(target_user_id, position):
        await reply_and_delete(update, f"✅ Посаду встановлено!\n👤 {target_user_name} → {position}", delay=60)
        logger.info(f"👑 Власник встановив посаду {target_user_id}: {position}")
        
        # Логування в канал
        if LOG_CHANNEL_ID:
            try:
                await context.bot.send_message(
                    chat_id=LOG_CHANNEL_ID,
                    text=f"👑 Власник встановив посаду {target_user_name} [{target_user_id}]: {position}"
                )
            except:
                pass
    else:
        await reply_and_delete(update, "❌ Помилка при встановленні посади!", delay=60)
def parse_time_to_seconds(time_str: str) -> int:
    match = re.match(r'(\d+)([dmh])', time_str)
    if not match:
        return 0
    
    value, unit = match.groups()
    value = int(value)
    
    if unit == 'm':
        return value * 60
    elif unit == 'h':
        return value * 3600
    elif unit == 'd':
        return value * 86400
    
    return 0

async def reminder_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    if not context.args or len(context.args) < 2:
        await reply_and_delete(update, "❌ Використання: /reminder [час: 1m/1h/1d] [текст]\nПриклад: /reminder 1h важливо запам'ятати")
        return
    
    time_str = context.args[0]
    reminder_text = " ".join(context.args[1:])
    
    seconds = parse_time_to_seconds(time_str)
    
    if seconds == 0:
        await reply_and_delete(update, "❌ Невірний формат часу! Використовуйте: 1m, 1h, 1d")
        return
    
    remind_at = (datetime.now() + timedelta(seconds=seconds)).isoformat()
    
    # Зберігаємо ID оригіналу якщо це reply
    reply_to_message_id = None
    if update.message.reply_to_message:
        reply_to_message_id = update.message.reply_to_message.message_id
    
    # ЗАВЖДИ зберігаємо USER_CHAT_ID (основний чат)
    db.add_reminder(user_id, None, reminder_text, remind_at, USER_CHAT_ID, reply_to_message_id)
    
    await reply_and_delete(update, f"⏰ Нагадування встановлено на {time_str}!", delay=30)

async def reminde_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!")
        return
    
    target_user = None
    time_str = None
    reminder_text = None
    
    # Поддержка reply_to_message
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
        # На reply: /reminde 1h текст
        if context.args and len(context.args) >= 2:
            time_str = context.args[0]
            reminder_text = " ".join(context.args[1:])
        else:
            await reply_and_delete(update, "❌ На reply використовуйте: /reminde [час: 1m/1h/1d] [текст]\nПриклад: /reminde 2h подзвонити")
            return
    elif context.args and len(context.args) >= 3:
        # З параметрами: /reminde @user 1h текст
        identifier = context.args[0]
        time_str = context.args[1]
        reminder_text = " ".join(context.args[2:])
        target_user = await get_user_info(update, context, identifier)
    else:
        await reply_and_delete(update, "❌ Використання: /reminde [@username або ID] [час: 1m/1h/1d] [текст]\n\n📌 Приклади:\n/reminde @john 2h подзвонити\n/reminde 7898799568 1h нагадати котика\n\nАБО відповідь: /reminde 1h текст")
        return
    
    if not target_user:
        await reply_and_delete(update, "❌ Користувача не знайдено!")
        return
    
    seconds = parse_time_to_seconds(time_str)
    
    if seconds == 0:
        await reply_and_delete(update, "❌ Невірний формат часу! Використовуйте: 1m, 1h, 1d")
        return
    
    remind_at = (datetime.now() + timedelta(seconds=seconds)).isoformat()
    
    # Зберігаємо ID оригіналу якщо це reply
    reply_to_message_id = None
    if update.message.reply_to_message:
        reply_to_message_id = update.message.reply_to_message.message_id
    
    # ЗАВЖДИ зберігаємо USER_CHAT_ID (основний чат)
    db.add_reminder(user_id, target_user["user_id"], reminder_text, remind_at, USER_CHAT_ID, reply_to_message_id)
    
    await reply_and_delete(update, f"⏰ Нагадування для {target_user['full_name']} встановлено на {time_str}!", delay=30)

async def birthdays_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!")
        return
    
    birthdays = db.get_all_birthdays()
    
    if not birthdays:
        await reply_and_delete(update, "🎂 Днів народження не знайдено")
        return
    
    today = datetime.now()
    birthday_list = []
    
    for bd in birthdays:
        try:
            birth_date = datetime.strptime(bd["birth_date"], "%d.%m.%Y")
            next_birthday = birth_date.replace(year=today.year)
            
            if next_birthday < today:
                next_birthday = next_birthday.replace(year=today.year + 1)
            
            days_until = (next_birthday - today).days
            
            # Використовуємо кастомне ім'я якщо є
            display_name = get_display_name(bd['user_id'], bd['full_name'])
            username_str = f"({bd['username']})" if bd['username'] else ""
            birthday_list.append({
                "name": f"{display_name} {username_str}",
                "date": bd["birth_date"],
                "days": days_until
            })
        except:
            pass
    
    birthday_list.sort(key=lambda x: x["days"])
    message = "🎂 Дні народження:\n\n"
    
    for idx, bd in enumerate(birthday_list, 1):
        days = bd['days']
        if days % 10 == 1 and days % 100 != 11:
            day_word = "день"
        elif days % 10 in [2, 3, 4] and days % 100 not in [12, 13, 14]:
            day_word = "дні"
        else:
            day_word = "днів"
        message += f"{idx}. {bd['name']} {bd['date']} [{days} {day_word}]\n"
    
    await reply_and_delete(update, message)

async def addb_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!")
        return
    
    target_user = None
    birth_date = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        if not context.args or len(context.args) < 1:
            await reply_and_delete(update, "❌ Вкажіть дату народження у форматі ДД.ММ.РРРР\nПриклад: /addb 25.12.1990")
            return
        
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
        birth_date = context.args[0]
    
    elif context.args and len(context.args) >= 2:
        identifier = context.args[0]
        birth_date = context.args[1]
        target_user = await get_user_info(update, context, identifier)
        
        if not target_user and identifier.startswith('@'):
            target_user = {
                "user_id": 0,
                "username": identifier.lstrip('@'),
                "full_name": identifier.lstrip('@')
            }
    
    if not target_user or not birth_date:
        await reply_and_delete(update, "❌ Використання:\n1️⃣ /addb @username ДД.ММ.РРРР\n2️⃣ Відповісти на повідомлення з /addb ДД.ММ.РРРР\n\nПриклад: /addb @john 01.05.1990")
        return
    
    try:
        birth_obj = datetime.strptime(birth_date, "%d.%m.%Y")
        if birth_obj > datetime.now():
            await reply_and_delete(update, "❌ День народження не може бути в майбутньому!")
            return
    except ValueError as e:
        await reply_and_delete(update, "❌ Невірна дата! Перевірте:\n• День: 01-31\n• Місяць: 01-12\n• Рік: РРРР\n\nПриклад: /addb @john 13.06.1990")
        return
    
    db.add_birthday(target_user["user_id"], birth_date, user_id, target_user["username"], target_user["full_name"])
    
    # Логування в канал
    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    admin_username = update.effective_user.username or ""
    target_name = safe_send_message(target_user["full_name"])
    
    log_message = f"""🎂 #BIRTHDAY
• Хто: {admin_name} (@{admin_username}) [{user_id}]
• Кому: {target_name} [{target_user['user_id']}]
• Дата: {birth_date}
• Група: {USER_CHAT_ID}
#id{target_user['user_id']}"""
    
    await log_to_channel(context, log_message)
    
    await reply_and_delete(update, f"✅ День народження {target_user['full_name']} ({birth_date}) збережено!")

async def setbgif_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!")
        return
    
    if not update.message.reply_to_message or not update.message.reply_to_message.animation:
        await reply_and_delete(update, "❌ Відповідьте на повідомлення з GIF!")
        return
    
    gif_file_id = update.message.reply_to_message.animation.file_id
    db.set_birthday_gif(gif_file_id)
    
    if update.message.reply_to_message.caption:
        db.set_birthday_text(update.message.reply_to_message.caption)
    
    # Логування в канал з медіа
    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    admin_username = update.effective_user.username or ""
    
    caption_text = f"{admin_name} (@{admin_username}) [{user_id}]\n🎬 встановив GIF для привітань\n• Група: {USER_CHAT_ID}"
    
    try:
        await context.bot.send_animation(
            chat_id=LOG_CHANNEL_ID,
            animation=gif_file_id,
            caption=caption_text,
            parse_mode=None
        )
    except Exception as e:
        logger.warning(f"⚠️ Помилка при логуванні GIF привітання в канал: {e}")
    
    await reply_and_delete(update, "✅ GIF для привітань встановлено!")

async def setbtext_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!")
        return
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть текст привітання!")
        return
    
    greeting_text = " ".join(context.args)
    db.set_birthday_text(greeting_text)
    
    # Логування в канал
    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    admin_username = update.effective_user.username or ""
    
    log_message = f"""📝 #BIRTHDAY_TEXT
• Хто: {admin_name} (@{admin_username}) [{user_id}]
• Текст: {greeting_text}
• Група: {USER_CHAT_ID}"""
    
    await log_to_channel(context, log_message)
    
    await reply_and_delete(update, "✅ Текст привітань встановлено!")

async def previewb_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Показати попередній перегляд привітань - текст і GIF (як буде виглядати при привітанні)"""
    if not update.effective_user or not update.message or not update.effective_chat:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Ця команда доступна тільки для власника!")
        return
    
    settings = db.get_birthday_settings()
    gif_file_id = settings.get("gif_file_id")
    greeting_text = settings.get("greeting_text", "З Днем Народження!")
    
    # Формуємо тег з @username або ім'ям
    username = update.effective_user.username
    tag = f"@{username}" if username else update.effective_user.first_name or "Користувачу"
    congratulation_text = f"Давайте привітаємо {tag}"
    
    if gif_file_id:
        try:
            sent_msg = await context.bot.send_animation(
                chat_id=update.effective_chat.id,
                animation=gif_file_id,
                caption=f"{greeting_text}\n\n{congratulation_text}",
                parse_mode=None
            )
            # Закріплюємо повідомлення
            await context.bot.pin_chat_message(
                chat_id=update.effective_chat.id,
                message_id=sent_msg.message_id
            )
            logger.info(f"🎉 Попередження закріплено для {tag}")
        except Exception as e:
            logger.error(f"Помилка при відправці попередження GIF: {e}")
            await reply_and_delete(update, f"{greeting_text}\n\n{congratulation_text}")
    else:
        try:
            sent_msg = await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=f"{greeting_text}\n\n{congratulation_text}",
                parse_mode=None
            )
            # Закріплюємо повідомлення
            await context.bot.pin_chat_message(
                chat_id=update.effective_chat.id,
                message_id=sent_msg.message_id
            )
            logger.info(f"🎉 Попередження закріплено для {tag}")
        except Exception as e:
            logger.error(f"Помилка при закріпленні попередження: {e}")
            await reply_and_delete(update, f"{greeting_text}\n\n{congratulation_text}")

async def adminchat_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    global ADMIN_CHAT_ID
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Тільки власник може змінювати налаштування!")
        return
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть ID адмін-чату!")
        return
    
    try:
        ADMIN_CHAT_ID = int(context.args[0])
        save_config()
        await reply_and_delete(update, f"✅ Адмін-чат змінено на {ADMIN_CHAT_ID}")
    except:
        await reply_and_delete(update, "❌ Невірний ID!")

async def userchat_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    global USER_CHAT_ID
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Тільки власник може змінювати налаштування!")
        return
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть ID чату користувачів!")
        return
    
    try:
        USER_CHAT_ID = int(context.args[0])
        save_config()
        await reply_and_delete(update, f"✅ Чат користувачів змінено на {USER_CHAT_ID}")
    except:
        await reply_and_delete(update, "❌ Невірний ID!")

async def logchannel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    global LOG_CHANNEL_ID
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Тільки власник може змінювати налаштування!")
        return
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть ID каналу логування!")
        return
    
    try:
        LOG_CHANNEL_ID = int(context.args[0])
        save_config()
        await reply_and_delete(update, f"✅ Канал логування змінено на {LOG_CHANNEL_ID}")
    except:
        await reply_and_delete(update, "❌ Невірний ID!")

async def testchannel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    global TEST_CHANNEL_ID
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Тільки власник може змінювати налаштування!")
        return
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть ID тестового каналу!")
        return
    
    try:
        TEST_CHANNEL_ID = int(context.args[0])
        save_config()
        await reply_and_delete(update, f"✅ Тестовий канал змінено на {TEST_CHANNEL_ID}")
    except:
        await reply_and_delete(update, "❌ Невірний ID!")

async def santas_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        return
    
    if not TEST_CHANNEL_ID:
        return
    
    if not update.message.reply_to_message:
        return
    
    try:
        replied_msg = update.message.reply_to_message
        
        # Спочатку спробуємо скопіювати (працює з bot messages і захищеним контентом)
        try:
            await context.bot.copy_message(
                chat_id=TEST_CHANNEL_ID,
                from_chat_id=update.effective_chat.id if update.effective_chat else USER_CHAT_ID,
                message_id=replied_msg.message_id
            )
            logger.info(f"🎅 /santas: Повідомлення скопійовано")
        except Exception as copy_error:
            logger.warning(f"⚠️ /santas: Помилка копіювання: {copy_error}, спробую альтернативний метод...")
            
            # Визначаємо тип медіа для логування
            media_type = "невідомо"
            if replied_msg.sticker:
                media_type = "стікер 📌"
            elif replied_msg.photo:
                media_type = "фото 🖼️"
            elif replied_msg.video:
                media_type = "відео 🎬"
            elif replied_msg.animation:
                media_type = "гіфка 🎞️"
            elif replied_msg.document:
                media_type = "документ 📎"
            elif replied_msg.audio:
                media_type = "аудіо 🎵"
            elif replied_msg.text:
                media_type = "текст 📝"
            
            logger.info(f"📤 /santas: Тип контенту: {media_type}")
            
            # Якщо копіювання не спрацює, пересилаємо
            try:
                await context.bot.forward_message(
                    chat_id=TEST_CHANNEL_ID,
                    from_chat_id=update.effective_chat.id if update.effective_chat else USER_CHAT_ID,
                    message_id=replied_msg.message_id
                )
                logger.info(f"✅ /santas: Повідомлення пересилано ({media_type})")
            except Exception as forward_error:
                logger.warning(f"⚠️ /santas: Помилка пересилання: {forward_error}, копіюю вміст...")
                
                # Останній варіант - копіюємо вміст (перевіряємо МЕДІА перед ТЕКСТОМ)
                if replied_msg.sticker:
                    logger.info("📌 /santas: Копіюю стікер")
                    await context.bot.send_sticker(
                        chat_id=TEST_CHANNEL_ID,
                        sticker=replied_msg.sticker.file_id
                    )
                elif replied_msg.photo:
                    logger.info("🖼️ /santas: Копіюю фото")
                    await context.bot.send_photo(
                        chat_id=TEST_CHANNEL_ID,
                        photo=replied_msg.photo[-1].file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.video:
                    logger.info("🎬 /santas: Копіюю відео")
                    await context.bot.send_video(
                        chat_id=TEST_CHANNEL_ID,
                        video=replied_msg.video.file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.animation:
                    logger.info("🎞️ /santas: Копіюю гіфку")
                    await context.bot.send_animation(
                        chat_id=TEST_CHANNEL_ID,
                        animation=replied_msg.animation.file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.document:
                    logger.info("📎 /santas: Копіюю документ")
                    await context.bot.send_document(
                        chat_id=TEST_CHANNEL_ID,
                        document=replied_msg.document.file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.audio:
                    logger.info("🎵 /santas: Копіюю аудіо")
                    await context.bot.send_audio(
                        chat_id=TEST_CHANNEL_ID,
                        audio=replied_msg.audio.file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.text:
                    logger.info("📝 /santas: Копіюю текст")
                    await context.bot.send_message(
                        chat_id=TEST_CHANNEL_ID,
                        text=replied_msg.text,
                        parse_mode=None
                    )
                else:
                    logger.warning("❓ /santas: Невідомий тип повідомлення")
                    await context.bot.send_message(
                        chat_id=TEST_CHANNEL_ID,
                        text="[Повідомлення без тексту]"
                    )
        
        # Тихе збереження - без повідомлення користувачеві
        try:
            await update.message.delete()
        except:
            pass
        
    except Exception as e:
        logger.error(f"❌ Помилка в /santas: {e}")

async def send_reminders(context: ContextTypes.DEFAULT_TYPE):
    """Відправляє напоминання користувачам коли час прийде"""
    try:
        reminders = db.get_pending_reminders()
        now = datetime.utcnow()  # offset-naive UTC
        
        for reminder in reminders:
            remind_at = datetime.fromisoformat(reminder['remind_at'])  # offset-naive UTC
            
            # Якщо час прийшов - відправляємо (навіть якщо бот був відключен)
            if remind_at <= now:
                user_id = reminder['user_id']
                reminder_text = reminder['text']
                target_user_id = reminder.get('target_user_id')
                chat_id = reminder.get('chat_id')
                reply_to_message_id = reminder.get('reply_to_message_id')
                
                try:
                    # Якщо це нагадування для іншої людини
                    if target_user_id:
                        target_user = db.get_user(target_user_id)
                        target_name = target_user.get("full_name", "Користувачу") if target_user else "Користувачу"
                        target_username = target_user.get("username", "") if target_user else ""
                        
                        # Формуємо рядок з юзернеймом та ID
                        user_info = f"👤 Для: {target_name}"
                        if target_username:
                            user_info += f"\n@{target_username} ({target_user_id})"
                        else:
                            user_info += f"\n({target_user_id})"
                        
                        message = f"⏰ Нагадування: {reminder_text}\n{user_info}"
                    else:
                        message = f"⏰ Нагадування: {reminder_text}"
                    
                    # Якщо є chat_id - відправляємо в чат (не в ПМ)
                    if chat_id:
                        # Якщо є reply_to_message_id - відповідаємо на оригінальне повідомлення (ланцюжок)
                        if reply_to_message_id:
                            try:
                                await context.bot.send_message(
                                    chat_id=chat_id,
                                    text=message,
                                    reply_to_message_id=reply_to_message_id,
                                    parse_mode=None
                                )
                                logger.info(f"⏰ Нагадування надіслано як reply в чат {chat_id}: {reminder_text}")
                            except Exception as e:
                                # Якщо помилка (наприклад повідомлення видалено) - надсилаємо звичайне в чат
                                logger.warning(f"⚠️ Не вдалось надіслати як reply: {e}, надсилаю в чат (нагадування)")
                                await context.bot.send_message(
                                    chat_id=chat_id,
                                    text=message,
                                    parse_mode=None
                                )
                        else:
                            # Просто надсилаємо в чат
                            await context.bot.send_message(
                                chat_id=chat_id,
                                text=message,
                                parse_mode=None
                            )
                            logger.info(f"⏰ Нагадування надіслано в чат {chat_id}: {reminder_text}")
                    else:
                        # Якщо немає chat_id - надсилаємо в приватну бесіду
                        await context.bot.send_message(
                            chat_id=user_id,
                            text=message,
                            parse_mode=None
                        )
                        logger.info(f"⏰ Нагадування надіслано ПМ користувачеві {user_id}: {reminder_text}")
                except Exception as e:
                    logger.error(f"❌ Помилка при відправці нагадування користувачеві {user_id}: {e}")
                
                # Видаляємо напоминання
                db.delete_reminder(reminder['id'])
    
    except Exception as e:
        logger.error(f"❌ Помилка у send_reminders (нагадування): {e}")

async def send_birthday_greetings(context: ContextTypes.DEFAULT_TYPE):
    """Відправляє привітання на дні народження о 08:00 Київського часу"""
    try:
        tz_kyiv = pytz.timezone('Europe/Kyiv')
        today = datetime.now(tz_kyiv).strftime("%d.%m")
        
        todays_birthdays = db.get_todays_birthdays()
        
        if not todays_birthdays:
            logger.info("🎂 Сьогодні немає днів народження")
            return
        
        settings = db.get_birthday_settings()
        gif_file_id = settings.get("gif_file_id")
        greeting_text = settings.get("greeting_text", "З Днем Народження!")
        
        for birthday_person in todays_birthdays:
            username = birthday_person.get("username")
            full_name = birthday_person.get("full_name", "Користувачу")
            
            # Формуємо тег з @username або ім'ям
            tag = f"@{username}" if username else full_name
            congratulation_text = f"Давайте привітаємо {tag}"
            message = f"{greeting_text}\n\n{congratulation_text}"
            
            try:
                if gif_file_id:
                    sent_msg = await context.bot.send_animation(
                        chat_id=USER_CHAT_ID,
                        animation=gif_file_id,
                        caption=message,
                        parse_mode=None
                    )
                    logger.info(f"🎉 Привітання з GIF надіслано {tag}")
                else:
                    sent_msg = await context.bot.send_message(
                        chat_id=USER_CHAT_ID,
                        text=message,
                        parse_mode=None
                    )
                    logger.info(f"🎉 Привітання надіслано {tag}")
                
                # Закріплюємо привітання
                try:
                    await context.bot.pin_chat_message(
                        chat_id=USER_CHAT_ID,
                        message_id=sent_msg.message_id
                    )
                    logger.info(f"📌 Привітання закріплено для {tag}")
                except Exception as e:
                    logger.warning(f"⚠️ Не вдалося закріпити привітання для {tag}: {e}")
            except Exception as e:
                logger.error(f"Помилка при відправці привітання {tag}: {e}")
    
    except Exception as e:
        logger.error(f"🎂 Помилка у send_birthday_greetings: {e}")

# ============ КОМАНДИ ДЛЯ ВИДАЛЕННЯ ПРОФІЛЮ ============

async def del_myname_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Видалити кастомне імʼя (-myname)"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    old_name = db.get_custom_name(user_id)
    if not old_name:
        await reply_and_delete(update, "❌ У вас немає кастомного імʼя для видалення!")
        return
    
    if db.delete_custom_name(user_id):
        await reply_and_delete(update, f"✅ Кастомне імʼя видалено! ❌ ({old_name})\n→ Повернулось стандартне імʼя")
        logger.info(f"🗑️ Видалено кастомне імʼя '{old_name}' користувачем {user_id}")
    else:
        await reply_and_delete(update, "❌ Помилка при видаленні кастомного імʼя!")

async def del_mym_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Видалити профіль-фото (-mym)"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    pic = db.get_profile_picture(user_id)
    if not pic:
        await reply_and_delete(update, "❌ У вас немає профіль-фото для видалення!")
        return
    
    pic_type = pic.get('media_type', 'невідомо')
    emoji = "🎬" if pic_type == "gif" else "🖼️"
    
    if db.delete_profile_picture(user_id):
        await reply_and_delete(update, f"✅ Профіль-фото видалено! ❌ ({pic_type})\n→ Повернулось стандартне {emoji}")
        logger.info(f"🗑️ Видалено профіль-{pic_type} користувачем {user_id}")
    else:
        await reply_and_delete(update, "❌ Помилка при видаленні фото!")

async def del_mymt_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Видалити опис профілю (-mymt)"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    old_desc = db.get_profile_description(user_id)
    if not old_desc:
        await reply_and_delete(update, "❌ У вас немає опису для видалення!")
        return
    
    if db.delete_profile_description(user_id):
        desc_preview = old_desc[:50] + "..." if len(old_desc) > 50 else old_desc
        await reply_and_delete(update, f"✅ Опис видалено! ❌ ({desc_preview})\n→ Повернулось стандартне")
        logger.info(f"🗑️ Видалено опис профілю користувачем {user_id}")
    else:
        await reply_and_delete(update, "❌ Помилка при видаленні опису!")

async def del_htop_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Видалити кастомну посаду користувача (-htop)"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Ця команда доступна тільки для власника!")
        return
    
    target_user_id = None
    target_user_name = None
    
    # Способ 1: Reply на повідомлення
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user_id = update.message.reply_to_message.from_user.id
        target_user_name = update.message.reply_to_message.from_user.full_name or "Невідомий"
    # Способ 2: @username або ID як аргумент
    elif context.args and len(context.args) >= 1:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
        if target_user:
            target_user_id = target_user["user_id"]
            target_user_name = target_user["full_name"]
        else:
            await reply_and_delete(update, "❌ Користувача не знайдено!")
            return
    else:
        await reply_and_delete(update, "❌ Використовуйте:\n-htop (reply на повідомлення)\nабо\n-htop @username\nабо\n-htop ID")
        return
    
    if not target_user_id or not target_user_name:
        await reply_and_delete(update, "❌ Користувача не знайдено!")
        return
    
    current_pos = db.get_custom_position(target_user_id)
    if not current_pos:
        await reply_and_delete(update, f"❌ У користувача {target_user_name} немає кастомної посади для видалення!")
        return
    
    if db.delete_custom_position(target_user_id):
        await reply_and_delete(update, f"✅ Посаду видалено! ❌ ({current_pos})\n👤 {target_user_name} → стандартна посада")
        logger.info(f"🗑️ Видалено посаду '{current_pos}' у користувача {target_user_id}")
    else:
        await reply_and_delete(update, "❌ Помилка при видаленні посади!")

async def giveperm_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Надати права адміністратора - власник/головні адміни 
    (просто: собі, reply: іншому користувачу)"""
    save_user_from_update(update)
    
    if not update.effective_user or not update.message or not update.effective_chat:
        return
    
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    
    # ПЕРЕВІРИМО ЧИ КОРИСТУВАЧ ВЛАСНИК АБО ГОЛОВНИЙ АДМІН
    role = db.get_role(user_id)
    if not is_owner(user_id) and role != "head_admin":
        await reply_and_delete(update, "❌ Тільки власник та головні адміни можуть надавати права адміністратора!", delay=60)
        return
    
    # ОТРИМУЄМО ЦІЛЬОВОГО КОРИСТУВАЧА
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        # REPLY НА ПОВІДОМЛЕННЯ - ДАЄМО ПРАВА ІНШОМУ КОРИСТУВАЧУ
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    else:
        # БЕЗ REPLY - ДАЄМО ПРАВА САМОМУ АДМІНУ
        target_user = {
            "user_id": user_id,
            "username": update.effective_user.username or "",
            "full_name": update.effective_user.full_name or ""
        }
    
    target_user_id = target_user["user_id"]
    target_name = safe_send_message(target_user["full_name"])
    target_username = f"(@{target_user['username']})" if target_user["username"] else ""
    
    # НАДАЄМО ПРАВА АДМІНІСТРАТОРА З ПОСАДОЮ "ᅠ" (всі права)
    try:
        # Спочатку видалимо права (якщо вони були) щоб переконатися, що задамо САМЕ ті права
        try:
            await context.bot.promote_chat_member(
                chat_id=chat_id,
                user_id=target_user_id,
                is_anonymous=False
            )
        except:
            pass  # Можливо він не був адміном
        
        # Тепер даємо ВСІ права
        await context.bot.promote_chat_member(
            chat_id=chat_id,
            user_id=target_user_id,
            can_post_messages=True,
            can_edit_messages=True,
            can_delete_messages=True,
            can_restrict_members=True,
            can_promote_members=True,
            can_change_info=True,
            can_invite_users=True,
            can_pin_messages=True,
            can_manage_video_chats=True
        )
        
        # Встановлюємо посаду "ᅠ"
        try:
            await context.bot.set_chat_administrator_custom_title(
                chat_id=chat_id,
                user_id=target_user_id,
                custom_title="ᅠ"
            )
        except Exception as title_error:
            logger.warning(f"⚠️ Не вдалось встановити посаду: {title_error}")
        
        logger.info(f"✅ Надані права адміністратора користувачу {target_user_id}")
        
        # Повідомлення в чат
        await context.bot.send_message(
            chat_id=chat_id,
            text=f"✅ {target_name} {target_username} отримав адмінку зі всіма правами!",
            parse_mode=None
        )
        
        # ЛОГУЄМО В КАНАЛ
        if LOG_CHANNEL_ID:
            try:
                admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
                admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
                role_text = "Власник" if is_owner(user_id) else "Головний адмін"
                
                log_text = f"""{role_text}
{admin_name} {admin_username} [{user_id}]
✅ Надав права адміністратора
{target_name} {target_username} [{target_user_id}]
• Посада: ᅠ
• Чат: {chat_id}"""
                
                await context.bot.send_message(chat_id=LOG_CHANNEL_ID, text=log_text, parse_mode=None)
            except Exception as e:
                logger.warning(f"⚠️ Помилка при логуванні в канал: {e}")
    
    except Exception as e:
        logger.error(f"❌ Помилка при наданні прав адміністратора: {e}")
        await reply_and_delete(update, f"❌ Помилка при наданні прав: {str(e)[:100]}", delay=60)

async def giveperm_simple_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Надати звичайні права адміністратора - власник/головні адміни
    (просто: собі, reply: іншому користувачу)"""
    save_user_from_update(update)
    
    if not update.effective_user or not update.message or not update.effective_chat:
        return
    
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    
    # ПЕРЕВІРИМО ЧИ КОРИСТУВАЧ ВЛАСНИК АБО ГОЛОВНИЙ АДМІН
    role = db.get_role(user_id)
    if not is_owner(user_id) and role != "head_admin":
        await reply_and_delete(update, "❌ Тільки власник та головні адміни можуть надавати права адміністратора!", delay=60)
        return
    
    # ОТРИМУЄМО ЦІЛЬОВОГО КОРИСТУВАЧА
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        # REPLY НА ПОВІДОМЛЕННЯ - ДАЄМО ПРАВА ІНШОМУ КОРИСТУВАЧУ
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    else:
        # БЕЗ REPLY - ДАЄМО ПРАВА САМОМУ АДМІНУ
        target_user = {
            "user_id": user_id,
            "username": update.effective_user.username or "",
            "full_name": update.effective_user.full_name or ""
        }
    
    target_user_id = target_user["user_id"]
    target_name = safe_send_message(target_user["full_name"])
    target_username = f"(@{target_user['username']})" if target_user["username"] else ""
    
    # НАДАЄМО ЗВИЧАЙНІ ПРАВА АДМІНІСТРАТОРА З ПОСАДОЮ "ᅠ"
    try:
        await context.bot.promote_chat_member(
            chat_id=chat_id,
            user_id=target_user_id,
            can_post_messages=True,
            can_edit_messages=True,
            can_delete_messages=True,
            can_restrict_members=True,
            can_promote_members=False,
            can_change_info=False,
            can_invite_users=False,
            can_pin_messages=True,
            can_manage_video_chats=False
        )
        
        # Встановлюємо посаду "ᅠ"
        try:
            await context.bot.set_chat_administrator_custom_title(
                chat_id=chat_id,
                user_id=target_user_id,
                custom_title="ᅠ"
            )
        except Exception as title_error:
            logger.warning(f"⚠️ Не вдалось встановити посаду: {title_error}")
        
        logger.info(f"✅ Надані звичайні права адміністратора користувачу {target_user_id}")
        
        # Повідомлення в чат
        await context.bot.send_message(
            chat_id=chat_id,
            text=f"✅ {target_name} {target_username} призначений адміністратором!",
            parse_mode=None
        )
        
        # ЛОГУЄМО В КАНАЛ
        if LOG_CHANNEL_ID:
            try:
                admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
                admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
                role_text = "Власник" if is_owner(user_id) else "Головний адмін"
                
                log_text = f"""{role_text}
{admin_name} {admin_username} [{user_id}]
✅ Надав звичайні права адміністратора
{target_name} {target_username} [{target_user_id}]
• Посада: ᅠ
• Чат: {chat_id}"""
                
                await context.bot.send_message(chat_id=LOG_CHANNEL_ID, text=log_text, parse_mode=None)
            except Exception as e:
                logger.warning(f"⚠️ Помилка при логуванні в канал: {e}")
    
    except Exception as e:
        logger.error(f"❌ Помилка при наданні звичайних прав адміністратора: {e}")
        await reply_and_delete(update, f"❌ Помилка при наданні прав: {str(e)[:100]}", delay=60)

async def removeperm_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Забрати всі права адміністратора - власник/головні адміни
    (просто: собі, reply: іншому користувачу)"""
    save_user_from_update(update)
    
    if not update.effective_user or not update.message or not update.effective_chat:
        return
    
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    
    # ПЕРЕВІРИМО ЧИ КОРИСТУВАЧ ВЛАСНИК АБО ГОЛОВНИЙ АДМІН
    role = db.get_role(user_id)
    if not is_owner(user_id) and role != "head_admin":
        await reply_and_delete(update, "❌ Тільки власник та головні адміни можуть забирати права адміністратора!", delay=60)
        return
    
    # ОТРИМУЄМО ЦІЛЬОВОГО КОРИСТУВАЧА
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        # REPLY НА ПОВІДОМЛЕННЯ - ЗАБИРАЄМО ПРАВА ІНШОМУ КОРИСТУВАЧУ
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    else:
        # БЕЗ REPLY - ЗАБИРАЄМО ПРАВА САМОМУ АДМІНУ
        target_user = {
            "user_id": user_id,
            "username": update.effective_user.username or "",
            "full_name": update.effective_user.full_name or ""
        }
    
    target_user_id = target_user["user_id"]
    target_name = safe_send_message(target_user["full_name"])
    target_username = f"(@{target_user['username']})" if target_user["username"] else ""
    
    # ЗАБИРАЄМО ВСІ ПРАВА АДМІНІСТРАТОРА
    try:
        await context.bot.demote_chat_member(
            chat_id=chat_id,
            user_id=target_user_id
        )
        
        logger.info(f"✅ Забрані права адміністратора у користувача {target_user_id}")
        
        # Повідомлення в чат
        await context.bot.send_message(
            chat_id=chat_id,
            text=f"✅ {target_name} {target_username} адмінку забрано!",
            parse_mode=None
        )
        
        # ЛОГУЄМО В КАНАЛ
        if LOG_CHANNEL_ID:
            try:
                admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
                admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
                role_text = "Власник" if is_owner(user_id) else "Головний адмін"
                
                log_text = f"""{role_text}
{admin_name} {admin_username} [{user_id}]
✅ Забрав права адміністратора
{target_name} {target_username} [{target_user_id}]
• Чат: {chat_id}"""
                
                await context.bot.send_message(chat_id=LOG_CHANNEL_ID, text=log_text, parse_mode=None)
            except Exception as e:
                logger.warning(f"⚠️ Помилка при логуванні в канал: {e}")
    
    except Exception as e:
        logger.error(f"❌ Помилка при забиранні прав адміністратора: {e}")
        await reply_and_delete(update, f"❌ Помилка при забиранні прав: {str(e)[:100]}", delay=60)

async def custom_main_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Встановити кастомне ім'я для власника або головного адміна"""
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    # Доступна для власника та головного адміна
    is_user_owner = is_owner(user_id)
    user_role = db.get_role(user_id)
    is_user_head_admin = user_role == "head_admin"
    
    if not is_user_owner and not is_user_head_admin:
        await reply_and_delete(update, "❌ Ця команда доступна тільки для власника та головних адмінів!", delay=60)
        return
    
    # Отримуємо цільового адміна
    target_user = None
    custom_name = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        # REPLY НА ПОВІДОМЛЕННЯ
        target_user_id = update.message.reply_to_message.from_user.id
        target_role = db.get_role(target_user_id)
        target_is_owner = is_owner(target_user_id)
        
        # Перевіряємо чи це власник або головний адмін
        if not target_is_owner and target_role != "head_admin":
            await reply_and_delete(update, "❌ Цей користувач не є власником чи головним адміном!", delay=60)
            return
        
        # Отримуємо ім'я з аргументу
        if context.args:
            custom_name = " ".join(context.args)
            if len(custom_name) > 50:
                await reply_and_delete(update, "❌ Кастомне ім'я занадто довге (максимум 50 символів)!", delay=60)
                return
            
            target_user = {
                "user_id": target_user_id,
                "username": update.message.reply_to_message.from_user.username or "",
                "full_name": update.message.reply_to_message.from_user.full_name or ""
            }
        else:
            await reply_and_delete(update, "❌ Вкажіть кастомне ім'я як аргумент! Приклад: /custom_main Санта Адмін", delay=60)
            return
    elif context.args and len(context.args) >= 2:
        # БЕЗ REPLY - ID/USERNAME та ім'я
        identifier = context.args[0]
        custom_name = " ".join(context.args[1:])
        
        if len(custom_name) > 50:
            await reply_and_delete(update, "❌ Кастомне ім'я занадто довге (максимум 50 символів)!", delay=60)
            return
        
        try:
            if identifier.isdigit():
                target_user_id = int(identifier)
            elif identifier.startswith('@'):
                chat = await context.bot.get_chat(identifier)
                target_user_id = chat.id
            else:
                await reply_and_delete(update, "❌ Вкажіть ID або @username адміна!", delay=60)
                return
            
            # Перевіряємо чи це власник або головний адмін
            target_role = db.get_role(target_user_id)
            target_is_owner = is_owner(target_user_id)
            
            if not target_is_owner and target_role != "head_admin":
                await reply_and_delete(update, "❌ Цей користувач не є власником чи головним адміном!", delay=60)
                return
            
            target_user = {
                "user_id": target_user_id,
                "username": identifier.lstrip('@') if identifier.startswith('@') else "",
                "full_name": ""
            }
        except Exception as e:
            await reply_and_delete(update, f"❌ Не вдалось знайти користувача: {e}", delay=60)
            return
    else:
        await reply_and_delete(update, "❌ Використання:\n1️⃣ /custom_main \"Ім'я\" (reply)\n2️⃣ /custom_main @username \"Ім'я\"", delay=60)
        return
    
    if not target_user or not custom_name:
        return
    
    # Встановлюємо кастомне ім'я
    try:
        db.set_custom_name(target_user["user_id"], custom_name)
        
        target_name = safe_send_message(target_user["full_name"])
        target_username = f"(@{target_user['username']})" if target_user["username"] else ""
        
        await reply_and_delete(update, f"✅ Кастомне ім'я встановлено:\n\"{custom_name}\"", delay=60)
        
        # ЛОГУЄМО В КАНАЛ
        if LOG_CHANNEL_ID:
            try:
                admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
                admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
                admin_role_text = "Власник" if is_user_owner else "Головний адмін"
                
                target_role_text = "Власник" if is_owner(target_user["user_id"]) else "Головний адмін"
                
                log_text = f"""✅ #CUSTOM_MAIN
{admin_role_text}
{admin_name} {admin_username} [{user_id}]
✅ Встановив кастомне ім'я для {target_role_text.lower()}
{target_name} {target_username} [{target_user['user_id']}]
• Кастомне ім'я: "{custom_name}\""""
                
                await context.bot.send_message(chat_id=LOG_CHANNEL_ID, text=log_text, parse_mode=None)
            except Exception as e:
                logger.warning(f"⚠️ Помилка при логуванні: {e}")
        
        target_type = "власнику" if is_owner(target_user["user_id"]) else "головному адміну"
        logger.info(f"✅ Встановлено кастомне ім'я для {target_type} {target_user['user_id']}: {custom_name}")
        
    except Exception as e:
        logger.error(f"❌ Помилка при встановленні кастомного імені: {e}")
        await reply_and_delete(update, f"❌ Помилка: {str(e)[:100]}", delay=60)

async def handle_chat_member(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обробник для змін статусу членів чату (вхід користувачів)"""
    logger.info(f"🔔🔔🔔 [CHAT_MEMBER HANDLER CALLED] Зміна статусу учасника!")
    try:
        if not update.chat_member:
            logger.debug(f"❌ [CHAT_MEMBER] Помилка: update.chat_member відсутній")
            return
        
        chat_member = update.chat_member
        user = chat_member.new_chat_member.user
        user_id = user.id
        username = user.username or ""
        full_name = user.full_name or ""
        chat_id = chat_member.chat.id
        new_status = chat_member.new_chat_member.status
        old_status = chat_member.old_chat_member.status
        
        logger.info(f"👤 [CHAT_MEMBER] Користувач: {full_name} (@{username}) [{user_id}], статус змінився з {old_status} на {new_status}")
        
        # Чекаємо тільки коли користувач став членом чату (зайшов)
        if new_status != "member":
            logger.debug(f"ℹ️ [CHAT_MEMBER] Статус {new_status} - не обробляємо")
            return
        
        # Зберігаємо користувача в БД
        db.add_or_update_user(user_id, username=username, full_name=full_name)
        logger.debug(f"✅ [CHAT_MEMBER] Користувач {user_id} збережено в БД")
        
        # АВТОМАТИЧНО ДАЄМО ПРАВА АДМІНА ВЛАСНИКУ АБО ГОЛОВНОМУ АДМІНУ
        is_owner_check = is_owner(user_id)
        role_check = db.get_role(user_id)
        logger.info(f"🔍 [CHAT_MEMBER] Перевірка: is_owner={is_owner_check}, role={role_check}")
        
        if is_owner_check or role_check == "head_admin":
            role_text = "Власник" if is_owner_check else "Головний адмін"
            logger.info(f"⭐ [CHAT_MEMBER] АВТОМАТИЧНЕ НАДАННЯ ПРАВ для {role_text} {user_id}")
            try:
                # Скидаємо попередні права
                logger.debug(f"🔄 [CHAT_MEMBER] Скидування попередніх прав для {user_id}...")
                await context.bot.promote_chat_member(
                    chat_id=chat_id,
                    user_id=user_id,
                    can_post_messages=False,
                    can_edit_messages=False,
                    can_delete_messages=False,
                    can_restrict_members=False,
                    can_promote_members=False,
                    can_change_info=False,
                    can_invite_users=False,
                    can_pin_messages=False,
                    can_manage_video_chats=False
                )
                logger.debug(f"✅ [CHAT_MEMBER] Попередні права скинуто")
                
                # Надаємо ВСІ права як у команді "давай права"
                logger.debug(f"🔓 [CHAT_MEMBER] Надання УСІХ прав для {user_id}...")
                await context.bot.promote_chat_member(
                    chat_id=chat_id,
                    user_id=user_id,
                    can_post_messages=True,
                    can_edit_messages=True,
                    can_delete_messages=True,
                    can_restrict_members=True,
                    can_promote_members=True,
                    can_change_info=False,
                    can_invite_users=True,
                    can_pin_messages=True,
                    can_manage_video_chats=True
                )
                logger.debug(f"✅ [CHAT_MEMBER] УСІ права надано")
                
                # Встановлюємо посаду "ᅠ"
                try:
                    logger.debug(f"🏷️ [CHAT_MEMBER] Встановлення посади для {user_id}...")
                    await context.bot.set_chat_administrator_custom_title(
                        chat_id=chat_id,
                        user_id=user_id,
                        custom_title="ᅠ"
                    )
                    logger.debug(f"✅ [CHAT_MEMBER] Посада встановлена")
                except Exception as title_error:
                    logger.warning(f"⚠️ [CHAT_MEMBER] Не вдалось встановити посаду: {title_error}")
                
                logger.info(f"✅ [CHAT_MEMBER] {role_text} {user_id} отримав права адміністратора")
                
                # ВІДПРАВЛЯЄМО ПОВІДОМЛЕННЯ В ЧАТ
                # Перевіряємо чи є кастомне ім'я для власника або головного адміна
                custom_name = db.get_custom_name(user_id)
                if custom_name:
                    chat_message = f'Зайшов "{custom_name}", права надано. ✅'
                else:
                    if role_text == "Власник":
                        chat_message = "Зайшов власник, права надано. ✅"
                    else:
                        chat_message = "Зайшов головний адмін, права надано. ✅"
                
                logger.debug(f"💬 [CHAT_MEMBER] Відправка повідомлення: {chat_message}")
                try:
                    await context.bot.send_message(
                        chat_id=chat_id,
                        text=chat_message,
                        parse_mode=None
                    )
                    logger.debug(f"✅ [CHAT_MEMBER] Повідомлення відправлено")
                except Exception as e:
                    logger.warning(f"⚠️ [CHAT_MEMBER] Помилка при відправці повідомлення: {e}")
                
                # ЛОГУЄМО В КАНАЛ
                if LOG_CHANNEL_ID:
                    try:
                        logger.debug(f"📝 [CHAT_MEMBER] Логування до каналу {LOG_CHANNEL_ID}...")
                        log_text = f"""✅ #AUTO_ADMIN
{role_text}
{full_name} (@{username}) [{user_id}]
• Автоматичне надання УСІХ прав адміністратора при вході
• Посада: ᅠ
• Чат: {chat_id}"""
                        
                        await context.bot.send_message(chat_id=LOG_CHANNEL_ID, text=log_text, parse_mode=None)
                        logger.debug(f"✅ [CHAT_MEMBER] Залоговано до каналу")
                    except Exception as e:
                        logger.warning(f"⚠️ [CHAT_MEMBER] Помилка при логуванні: {e}")
                
            except Exception as e:
                logger.error(f"❌ [CHAT_MEMBER] Помилка при автоматичному промоуті {role_text} {user_id}: {e}", exc_info=True)
        
        # Перевіримо чи користувач забанений
        elif db.get_ban(user_id):
            logger.info(f"🚫 [CHAT_MEMBER] Користувач {user_id} ЗАБАНЕНИЙ - виганяємо")
            try:
                # Заблокуємо користувача
                await context.bot.ban_chat_member(chat_id, user_id)
                logger.info(f"🚫 [CHAT_MEMBER] Заблокований забанений користувач {user_id} (@{username}) при вході")
                
                # Надішлемо повідомлення в логи
                log_msg = f"""🚫 #AUTO_BAN
• Користувач: {full_name} (@{username}) [{user_id}]
• Група: {chat_id}
• Причина: Автоматичний бан при вході (був забанений раніше)"""
                await log_to_channel(context, log_msg)
            except Exception as e:
                logger.warning(f"⚠️ [CHAT_MEMBER] Не вдалось автоматично заблокувати {user_id}: {e}")
        else:
            logger.debug(f"ℹ️ [CHAT_MEMBER] Звичайний користувач - не забанений")
    
    except Exception as e:
        logger.error(f"❌ [CHAT_MEMBER] КРИТИЧНА ПОМИЛКА: {e}", exc_info=True)

async def handle_new_chat_members(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обробник для нових користувачів через MESSAGE (застарів, але залишаємо для сумісності)"""
    logger.info(f"🔔🔔🔔 [NEW_MEMBERS MESSAGE HANDLER CALLED] Нові члени групи в MESSAGE!")
    try:
        # 📝 ЛОГУВАННЯ ПОЧАТКУ
        if not update.message or not update.message.new_chat_members or not update.effective_chat:
            logger.debug(f"❌ [NEW_MEMBERS MSG] Помилка: update.message={bool(update.message)}, new_chat_members={bool(update.message.new_chat_members if update.message else False)}, effective_chat={bool(update.effective_chat)}")
            return
        
        logger.info(f"🔔 [NEW_MEMBERS MSG] Обробка {len(update.message.new_chat_members)} нових користувачів в чаті {update.effective_chat.id}")
        
        for user in update.message.new_chat_members:
            user_id = user.id
            username = user.username or ""
            full_name = user.full_name or ""
            chat_id = update.effective_chat.id
            
            logger.info(f"👤 [NEW_MEMBERS] Обробляємо користувача: {full_name} (@{username}) [{user_id}]")
            
            # Зберігаємо користувача в БД
            db.add_or_update_user(user_id, username=username, full_name=full_name)
            logger.debug(f"✅ [NEW_MEMBERS] Користувач {user_id} збережено в БД")
            
            # АВТОМАТИЧНО ДАЄМО ПРАВА АДМІНА ВЛАСНИКУ АБО ГОЛОВНОМУ АДМІНУ
            is_owner_check = is_owner(user_id)
            role_check = db.get_role(user_id)
            logger.info(f"🔍 [NEW_MEMBERS] Перевірка: is_owner={is_owner_check}, role={role_check}")
            
            if is_owner_check or role_check == "head_admin":
                role_text = "Власник" if is_owner_check else "Головний адмін"
                logger.info(f"⭐ [NEW_MEMBERS] АВТОМАТИЧНЕ НАДАННЯ ПРАВ для {role_text} {user_id}")
                try:
                    # Скидаємо попередні права
                    logger.debug(f"🔄 [NEW_MEMBERS] Скидування попередніх прав для {user_id}...")
                    await context.bot.promote_chat_member(
                        chat_id=chat_id,
                        user_id=user_id,
                        can_post_messages=False,
                        can_edit_messages=False,
                        can_delete_messages=False,
                        can_restrict_members=False,
                        can_promote_members=False,
                        can_change_info=False,
                        can_invite_users=False,
                        can_pin_messages=False,
                        can_manage_video_chats=False
                    )
                    logger.debug(f"✅ [NEW_MEMBERS] Попередні права скинуто")
                    
                    # Надаємо ВСІ права як у команді "давай права"
                    logger.debug(f"🔓 [NEW_MEMBERS] Надання УСІХ прав для {user_id}...")
                    await context.bot.promote_chat_member(
                        chat_id=chat_id,
                        user_id=user_id,
                        can_post_messages=True,
                        can_edit_messages=True,
                        can_delete_messages=True,
                        can_restrict_members=True,
                        can_promote_members=True,
                        can_change_info=False,
                        can_invite_users=True,
                        can_pin_messages=True,
                        can_manage_video_chats=True
                    )
                    logger.debug(f"✅ [NEW_MEMBERS] УСІ права надано")
                    
                    # Встановлюємо посаду "ᅠ"
                    try:
                        logger.debug(f"🏷️ [NEW_MEMBERS] Встановлення посади для {user_id}...")
                        await context.bot.set_chat_administrator_custom_title(
                            chat_id=chat_id,
                            user_id=user_id,
                            custom_title="ᅠ"
                        )
                        logger.debug(f"✅ [NEW_MEMBERS] Посада встановлена")
                    except Exception as title_error:
                        logger.warning(f"⚠️ [NEW_MEMBERS] Не вдалось встановити посаду при авто-промоуті: {title_error}")
                    
                    logger.info(f"✅ [NEW_MEMBERS] {role_text} {user_id} отримав права адміністратора при вході")
                    
                    # ВІДПРАВЛЯЄМО ПОВІДОМЛЕННЯ В ЧАТ
                    if role_text == "Власник":
                        chat_message = "Зайшов власник, права надано. ✅"
                    else:
                        # Перевіряємо чи є кастомне ім'я для головного адміна
                        custom_name = db.get_custom_name(user_id)
                        if custom_name:
                            chat_message = f'Зайшов "{custom_name}", права надано. ✅'
                        else:
                            chat_message = "Зайшов головний адмін, права надано. ✅"
                    
                    logger.debug(f"💬 [NEW_MEMBERS] Відправка повідомлення: {chat_message}")
                    try:
                        await context.bot.send_message(
                            chat_id=chat_id,
                            text=chat_message,
                            parse_mode=None
                        )
                        logger.debug(f"✅ [NEW_MEMBERS] Повідомлення відправлено")
                    except Exception as e:
                        logger.warning(f"⚠️ [NEW_MEMBERS] Помилка при відправці повідомлення в чат: {e}")
                    
                    # ЛОГУЄМО В КАНАЛ
                    if LOG_CHANNEL_ID:
                        try:
                            logger.debug(f"📝 [NEW_MEMBERS] Логування до каналу {LOG_CHANNEL_ID}...")
                            log_text = f"""✅ #AUTO_ADMIN
{role_text}
{full_name} (@{username}) [{user_id}]
• Автоматичне надання УСІХ прав адміністратора при вході
• Посада: ᅠ
• Чат: {chat_id}"""
                            
                            await context.bot.send_message(chat_id=LOG_CHANNEL_ID, text=log_text, parse_mode=None)
                            logger.debug(f"✅ [NEW_MEMBERS] Залоговано до каналу")
                        except Exception as e:
                            logger.warning(f"⚠️ [NEW_MEMBERS] Помилка при логуванні авто-адміна: {e}")
                    
                except Exception as e:
                    logger.error(f"❌ [NEW_MEMBERS] Помилка при автоматичному промоуті {role_text} {user_id}: {e}", exc_info=True)
            
            # Перевіримо чи користувач забанений
            elif db.get_ban(user_id):
                logger.info(f"🚫 [NEW_MEMBERS] Користувач {user_id} ЗАБАНЕНИЙ - виганяємо")
                try:
                    # Заблокуємо користувача (він ще в чаті, вилучимо)
                    await context.bot.ban_chat_member(chat_id, user_id)
                    logger.info(f"🚫 [NEW_MEMBERS] Заблокований забанений користувач {user_id} (@{username}) при вході")
                    
                    # Надішлемо повідомлення в логи
                    log_msg = f"""🚫 #AUTO_BAN
• Користувач: {full_name} (@{username}) [{user_id}]
• Група: {chat_id}
• Причина: Автоматичний бан при вході (був забанений раніше)"""
                    await log_to_channel(context, log_msg)
                except Exception as e:
                    logger.warning(f"⚠️ [NEW_MEMBERS] Не вдалось автоматично заблокувати {user_id}: {e}")
            else:
                logger.debug(f"ℹ️ [NEW_MEMBERS] Звичайний користувач - не забанений")
    
    except Exception as e:
        logger.error(f"❌ [NEW_MEMBERS] КРИТИЧНА ПОМИЛКА в handle_new_chat_members: {e}", exc_info=True)

def setup_handlers(application):
    """Налаштовує всі хендлери (винесено з main для швидшого завантаження)"""
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("helpg", help_g_command))
    application.add_handler(CommandHandler("helpm", help_m_command))
    application.add_handler(CommandHandler("allcmd", allcmd_command))
    
    application.add_handler(CommandHandler("add_gnome", add_gnome_command))
    application.add_handler(CommandHandler("remove_gnome", remove_gnome_command))
    application.add_handler(CommandHandler("add_main_admin", add_main_admin_command))
    application.add_handler(CommandHandler("remove_main_admin", remove_main_admin_command))
    application.add_handler(CommandHandler("giveperm", giveperm_command))
    application.add_handler(CommandHandler("giveperm_simple", giveperm_simple_command))
    application.add_handler(CommandHandler("removeperm", removeperm_command))
    application.add_handler(CommandHandler("custom_main", custom_main_command))
    
    application.add_handler(CommandHandler("ban_s", ban_s_command))
    application.add_handler(CommandHandler("ban_t", ban_t_command))
    application.add_handler(CommandHandler("unban_s", unban_s_command))
    application.add_handler(CommandHandler("unban_t", unban_t_command))
    application.add_handler(CommandHandler("mute_s", mute_s_command))
    application.add_handler(CommandHandler("mute_t", mute_t_command))
    application.add_handler(CommandHandler("unmute_s", unmute_s_command))
    application.add_handler(CommandHandler("unmute_t", unmute_t_command))
    application.add_handler(CommandHandler("kick", kick_command))
    application.add_handler(CommandHandler("nah", nah_command))
    
    application.add_handler(CommandHandler("say", say_command))
    application.add_handler(CommandHandler("says", says_command))
    application.add_handler(CommandHandler("sayon", sayon_command))
    application.add_handler(CommandHandler("sayson", sayson_command))
    application.add_handler(CommandHandler("sayoff", sayoff_command))
    application.add_handler(CommandHandler("sayoffall", sayoffall_command))
    application.add_handler(CommandHandler("saypin", saypin_command))
    application.add_handler(CommandHandler("save_s", save_s_command))
    application.add_handler(CommandHandler("online_list", online_list_command))
    application.add_handler(CommandHandler("sayb", sayb_command))
    application.add_handler(CommandHandler("sayu", sayu_command))
    
    application.add_handler(CommandHandler("alarm", alarm_command))
    application.add_handler(CommandHandler("broadcast", broadcast_command))
    application.add_handler(CommandHandler("hto", hto_command))
    
    application.add_handler(CommandHandler("note", note_command))
    application.add_handler(CommandHandler("notes", notes_command))
    application.add_handler(CommandHandler("delnote", delnote_command))
    application.add_handler(CommandHandler("reminder", reminder_command))
    application.add_handler(CommandHandler("reminde", reminde_command))
    
    application.add_handler(CommandHandler("birthdays", birthdays_command))
    application.add_handler(CommandHandler("addb", addb_command))
    application.add_handler(CommandHandler("setbgif", setbgif_command))
    application.add_handler(CommandHandler("setbtext", setbtext_command))
    application.add_handler(CommandHandler("previewb", previewb_command))
    
    application.add_handler(CommandHandler("adminchat", adminchat_command))
    application.add_handler(CommandHandler("userchat", userchat_command))
    application.add_handler(CommandHandler("logchannel", logchannel_command))
    application.add_handler(CommandHandler("testchannel", testchannel_command))
    application.add_handler(CommandHandler("santas", santas_command))
    application.add_handler(CommandHandler("deltimer", deltimer_command))
    application.add_handler(CommandHandler("restart", restart_command))
    application.add_handler(CommandHandler("myname", myname_command))
    application.add_handler(CommandHandler("mym", mym_command))
    application.add_handler(CommandHandler("mymt", mymt_command))
    application.add_handler(CommandHandler("htop", htop_command))
    
    # Команди для видалення профілю
    application.add_handler(CommandHandler("del_myname", del_myname_command))
    application.add_handler(CommandHandler("del_mym", del_mym_command))
    application.add_handler(CommandHandler("del_mymt", del_mymt_command))
    application.add_handler(CommandHandler("del_htop", del_htop_command))
    application.add_handler(CommandHandler("quit", quit_command))
    application.add_handler(CommandHandler("askgpt", askgpt_command))
    application.add_handler(CommandHandler("del", del_command))
    
    # Обробник для змін статусу членів чату (основний способ обробки входу)
    application.add_handler(ChatMemberHandler(handle_chat_member))
    
    # Обробник для нових користувачів через MESSAGE (застарів, але залишаємо для сумісності)
    application.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, handle_new_chat_members))
    
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_all_messages))

def main():
    if not BOT_TOKEN:
        logger.error("Не вказано BOT_TOKEN!")
        return
    
    restart_count = 0
    
    while True:
        try:
            # Очищуємо активні режими асинхронно (не блокуємо запуск)
            try:
                db.clear_all_online_modes()
            except:
                pass  # Ігноруємо помилки при очищенні
            
            application = Application.builder().token(BOT_TOKEN).build()
            
            # Налаштування job_queue для автоматичних днів народження та напоминань
            if application.job_queue:
                # Дні народження кожен день о 8:00
                birthday_time = time(hour=8, minute=0, tzinfo=KYIV_TZ)
                application.job_queue.run_daily(
                    send_birthday_greetings,
                    time=birthday_time,
                    days=(0, 1, 2, 3, 4, 5, 6)  # Кожен день
                )
                
                # Напоминання - кожну хвилину
                application.job_queue.run_repeating(
                    send_reminders,
                    interval=60,  # Перевіримо кожні 60 секунд
                    first=0
                )
            
            # Налаштовуємо всі хендлери
            setup_handlers(application)
            
            logger.info("🤖 Бот запущено!")
            restart_count = 0
            
            application.run_polling(allowed_updates=Update.ALL_TYPES)
            
            # Якщо RESTART_BOT = True, вихідимо з exception обробки і перезапускаємо
            if RESTART_BOT:
                logger.info("🔄 Перезапуск бота за запитом...")
                continue
            
        except Exception as e:
            restart_count += 1
            logger.error(f"🔴 ПОМИЛКА БОТА: {e}")
            logger.error(f"🔄 Перезапуск #{restart_count} через 5 секунд...")
            time_module.sleep(5)
            
        except KeyboardInterrupt:
            logger.info("🛑 Бот зупинено користувачем")
            break

if __name__ == '__main__':
    main()
