# 🎅 Santa Admin Bot

Комплексний Telegram адміністративний бот з системою ролей, модерацією, пересиланням повідомлень, днями народження та повним управлінням чатом.

[![Python](https://img.shields.io/badge/Python-3.9%2B-blue)](https://www.python.org/)
[![Telegram Bot API](https://img.shields.io/badge/Telegram%20Bot-API-blue)](https://core.telegram.org/bots/api)
[![License](https://img.shields.io/badge/License-MIT-green)](LICENSE)

## ✨ Ключові Можливості

### 👥 Система Ролей
- **Owner (Власник)**: Повний доступ до всіх команд
- **Head Admins**: Управління гномами, модерація, логування
- **Gnomes (Гноми)**: Пересилання повідомлень, нотатки, нагадування
- **Users (Користувачі)**: Персональні налаштування, нотатки

### 🤐 Модерація
- `/ban_s`, `/ban_t` - Бан користувачів (тихий/публічний)
- `/mute_s`, `/mute_t` - Мутування (тихе/публічне)
- `/kick` - Вигнання з чату
- `/nah` - Чорний список (тільки Owner)

### 💬 Пересилання Повідомлень
- `/say` - З підписом автора
- `/says` - Анонімно
- `/sayon` - Автоматичне пересилання з підписом
- `/sayson` - Автоматичне анонімне пересилання
- Підтримка посилань на Telegram повідомлення: `/says текст https://t.me/c/CHAT_ID/MESSAGE_ID`

### 🎂 Дні Народження
- Автоматичні привітання о 08:00 AM Київськ
- Кастомні GIF та текст
- Закріплення повідомлення в чаті
- Персональне тегування

### 📝 Нотатки & Нагадування
- Особисті нотатки для кожного користувача
- Видалення нотаток за номером: `/delnote 1`
- Нагадування на певний час: `/reminder 1h текст`
- Дублювання в канал для архіву

### 👤 Профіль Користувача
- `/myname` - Кастомне імʼя
- `/mym` - Профіль-гіфка/фото (reply на медіа)
- `/mymt` - Опис профілю
- `/hto` - Переглянути профіль
- `/htop` - Кастомна посада (Owner)

### 📊 Логування
- Усі адміністративні дії логуються
- Структуровані повідомлення з хештегами
- Історія модерації та операцій

## 🚀 Швидкий Старт

### Найпростіший спосіб: Replit

1. **Натисни**: [![Run on Replit](https://replit.com/badge/github/YOUR_USERNAME/santa-admin-bot)](https://replit.com/new/github/YOUR_USERNAME/santa-admin-bot)
2. **Додай .env** з BOT_TOKEN
3. **Натисни Run** - Готово! ✅

### На власному сервері

```bash
# 1. Клонуй
git clone https://github.com/YOUR_USERNAME/santa-admin-bot.git
cd santa-admin-bot

# 2. Встанови залежності
pip install -r requirements.txt

# 3. Налаштуй
cp .env.example .env
# Заповни .env своїм BOT_TOKEN

# 4. Запусти
python bot.py
```

**Детально див.** [GitHub-SETUP.md](GitHub-SETUP.md)

## 📖 Основні Команди

### Для Всіх
- `/start` - Початок роботи
- `/help` - Допомога
- `/myname [ім'я]` - Встановити кастомне імʼя
- `/note` - Зберегти нотатку
- `/notes` - Показати свої нотатки
- `/hto` - Переглянути свій профіль

### Для Гномів+
- `/say текст` - Пересилання з підписом
- `/says текст` - Пересилання анонімно
- `/sayon` - Ввімкнути режим автопересилання
- `/reminder 1h текст` - Нагадування

### Для Head Admins+
- `/ban_t @user` - Публічний бан
- `/mute_t @user` - Публічне мутування
- `/add_gnome @user` - Додати гнома
- `/remove_gnome @user` - Видалити гнома
- `/broadcast текст` - Розсилка
- `/addb 1999-12-25 @user` - Додати день народження

### Для Owner
- `/admin_chat <ID>` - Встановити адмін-чат
- `/user_chat <ID>` - Встановити користувацький чат
- `/restart` - Перезапустити бота
- `/add_main_admin @user` - Призначити Head Admin
- `/nah @user` - Чорний список

## 🏗️ Архітектура

```
santa-admin-bot/
├── bot.py              # Головний файл бота
├── database.py         # Робота з БД (SQLite)
├── config.json         # Налаштування
├── .env.example        # Приклад .env
├── requirements.txt    # Залежності
├── README.md           # Це файл
└── GitHub-SETUP.md     # Інструкція розгортування
```

### База Даних
- **SQLite** (вбудована)
- 13+ таблиць для всіх даних
- Автоматичне створення при першому запуску
- Резервна копія: `bot_database.db.backup`

## 🔧 Налаштування

### config.json
```json
{
  "ADMIN_CHAT_ID": -1002496348691,      // ID адмін-групи
  "USER_CHAT_ID": -1002646171857,       // ID основної групи
  "LOG_CHANNEL_ID": -1002863334815,     // ID каналу логування
  "NOTES_CHANNEL_ID": -1002477496414,   // ID каналу нотаток
  "TEST_CHANNEL_ID": -1002863334815,    // ID тестового каналу
  "OWNER_IDS": [7247114478],            // ID власника
  "MESSAGE_DELETE_TIMER": 5             // Таймер видалення (сек)
}
```

### Отримання ID
Напиши боту:
```
/adminchat - отримати ID адмін-групи
/userchat - отримати ID основної групи
```

## 📦 Залежності

```
python-telegram-bot>=20.0
python-dotenv>=0.19.0
pytz>=2021.3
APScheduler>=3.10.0
```

## 🐛 Debugging

### Ввімкни Verbose Logging
```python
# У bot.py
logging.basicConfig(level=logging.DEBUG)
```

### Перевір Логи
```bash
tail -f bot.log
```

### Тестування
```bash
python -c "from database import Database; db = Database(); print('✅ БД OK')"
```

## 🚀 Deploy Options

### Replit (Найпростіше) ✅
- Один клік запуску
- Автоматичні перезапуски
- Вбудована БД
- Безплатно!

### VPS / Dedicated Server
- Повна контроль
- Виробничого рівня
- Docker підтримка

### GitHub Actions
- Автоматичні оновлення
- CI/CD pipeline

Див. [GitHub-SETUP.md](GitHub-SETUP.md) для детальних інструкцій!

## 📊 Статистика

- **30+ команд** для управління
- **13+ таблиць БД** для даних
- **2000+ рядків коду** Python
- **100% функціональний** production-ready

## 🤝 Контрибʼюція

Знайшов баг? Хочеш додати фіч?

1. Fork репозиторій
2. Створи branch: `git checkout -b feature/amazing-feature`
3. Commit: `git commit -m 'Add some amazing feature'`
4. Push: `git push origin feature/amazing-feature`
5. Open Pull Request

## 📝 License

MIT License - див. [LICENSE](LICENSE)

## 👤 Автор

- **Santa Admin Bot** - [@dont_luck](https://t.me/dont_luck) (ID: 7247114478)

## 🙏 Подякуємо!

Якщо проект тобі подобається:
- ⭐ Залиш звізду
- 🔔 Стань спостерігачем
- 💬 Обговорюй ідеї

## 📞 Контакти & Підтримка

- 🤖 Telegram: [@santa_admin_bot](https://t.me/dont_luck)
- 💬 DM: [@dont_luck](https://t.me/dont_luck)
- 📧 Issues: GitHub Issues

---

**Версія**: 1.0.0  
**Останнє оновлення**: Листопад 2025  
**Статус**: ✅ Production Ready
