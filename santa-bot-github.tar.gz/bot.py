import logging
import json
import os
import re
import time as time_module
import asyncio
from datetime import datetime, timedelta, time
from typing import Optional
import pytz
from telegram import Update, ChatPermissions, ChatMember
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
from telegram.ext import JobQueue
from database import Database

# Глобальний флаг для перезапуску
RESTART_BOT = False

# Кешування timezone для швидшого завантаження
KYIV_TZ = pytz.timezone('Europe/Kyiv')

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

with open('config.json', 'r', encoding='utf-8') as f:
    config = json.load(f)

BOT_TOKEN = os.getenv('BOT_TOKEN', config.get('TOKEN', ''))
ADMIN_CHAT_ID = config.get('ADMIN_CHAT_ID')
USER_CHAT_ID = config.get('USER_CHAT_ID')
LOG_CHANNEL_ID = config.get('LOG_CHANNEL_ID')
NOTES_CHANNEL_ID = config.get('NOTES_CHANNEL_ID')
TEST_CHANNEL_ID = config.get('TEST_CHANNEL_ID')
OWNER_IDS = config.get('OWNER_IDS', [])
MESSAGE_DELETE_TIMER = config.get('MESSAGE_DELETE_TIMER', 5)

db = Database()

def format_kyiv_time(iso_string: str) -> str:
    """Форматує ISO дату в формат: 2025-10-24 о 13:24 (Київ)"""
    try:
        dt = datetime.fromisoformat(iso_string)
        if dt.tzinfo is None:
            dt = pytz.UTC.localize(dt)
        tz = pytz.timezone('Europe/Kyiv')
        dt_kyiv = dt.astimezone(tz)
        return dt_kyiv.strftime('%Y-%m-%d о %H:%M')
    except:
        return iso_string

def save_config():
    with open('config.json', 'w', encoding='utf-8') as f:
        json.dump({
            "ADMIN_CHAT_ID": ADMIN_CHAT_ID,
            "USER_CHAT_ID": USER_CHAT_ID,
            "LOG_CHANNEL_ID": LOG_CHANNEL_ID,
            "NOTES_CHANNEL_ID": NOTES_CHANNEL_ID,
            "TEST_CHANNEL_ID": TEST_CHANNEL_ID,
            "OWNER_IDS": OWNER_IDS,
            "MESSAGE_DELETE_TIMER": MESSAGE_DELETE_TIMER
        }, f, indent=2, ensure_ascii=False)

def is_owner(user_id: int) -> bool:
    return user_id in OWNER_IDS

def is_head_admin(user_id: int) -> bool:
    return db.get_role(user_id) == "head_admin"

def is_gnome(user_id: int) -> bool:
    return db.get_role(user_id) == "gnome"

def can_use_bot(user_id: int) -> bool:
    return is_owner(user_id) or is_head_admin(user_id) or is_gnome(user_id)

def parse_telegram_link(link: str):
    """Парсить посилання на Telegram повідомлення: https://t.me/c/2646171857/770828"""
    match = re.search(r't\.me/c/(\d+)/(\d+)', link)
    if match:
        # Для приватних каналів Telegram: chat_id = -1000000000000 - ID
        channel_id = int(match.group(1))
        chat_id = -1000000000000 - channel_id
        message_id = int(match.group(2))
        logger.info(f"📎 Парсено посилання: channel_id={channel_id}, chat_id={chat_id}, message_id={message_id}")
        return chat_id, message_id
    return None, None

def can_manage_gnomes(user_id: int) -> bool:
    return is_owner(user_id) or is_head_admin(user_id)

def can_ban_mute(user_id: int) -> bool:
    return is_owner(user_id) or is_head_admin(user_id)

def get_display_name(user_id: int, default_name: str = "Невідомий") -> str:
    """Отримати кастомне імʼя користувача або стандартне"""
    custom_name = db.get_custom_name(user_id)
    if custom_name:
        return custom_name
    return default_name or "Невідомий"

def safe_send_message(text: str) -> str:
    if not text:
        return ""
    text = str(text)
    text = re.sub(r'[<>&]', '', text)
    text = re.sub(r'[@#]', '', text)
    text = re.sub(r'[\[\]]', '', text)
    return text.strip()

async def delete_message_after_delay(message, delay: int = 5):
    """Видаляє повідомлення через delay секунд"""
    try:
        await asyncio.sleep(delay)
        await message.delete()
    except Exception as e:
        logger.debug(f"⚠️ Не вдалось видалити повідомлення: {e}")

async def reply_and_delete(update: Update, text: str, delay: Optional[int] = None):
    """Надсилає відповідь та видаляє її через delay секунд"""
    global MESSAGE_DELETE_TIMER
    try:
        msg = await update.message.reply_text(text)
        if delay is None:
            delay = MESSAGE_DELETE_TIMER
        asyncio.create_task(delete_message_after_delay(msg, delay))
        return msg
    except Exception as e:
        logger.error(f"Помилка при надсиланні повідомлення: {e}")
        return None

async def log_to_channel(context: ContextTypes.DEFAULT_TYPE, message: str):
    if LOG_CHANNEL_ID:
        try:
            await context.bot.send_message(
                chat_id=LOG_CHANNEL_ID,
                text=message,
                parse_mode=None
            )
        except Exception as e:
            logger.error(f"Помилка логування в канал: {e}")

async def get_user_info(update: Update, context: ContextTypes.DEFAULT_TYPE, identifier: str) -> Optional[dict]:
    try:
        if identifier.startswith('@'):
            # Видаляємо @ і пробуємо знайти через обидва способи
            username = identifier.lstrip('@')
            logger.debug(f"🔍 Пошук користувача @{username}")
            
            # Спроба 1: Пошук в базі даних (ПЕРШИЙ ВАРІАНТ)
            logger.info(f"🔍 Спроба 1: Пошук в БД за username '@{username}'")
            user_data = db.get_user_by_username(username)
            if user_data:
                logger.info(f"✅ ЗНАЙДЕНО в БД! user_id={user_data['user_id']}, username={user_data.get('username')}, full_name={user_data.get('full_name')}")
                return {
                    "user_id": user_data["user_id"],
                    "username": user_data.get("username", ""),
                    "full_name": user_data.get("full_name", "")
                }
            logger.info(f"⚠️ Не знайдено в БД по запиту '{username}'")
            
            # Спроба 2: Використовуємо get_chat з @username (API Telegram)
            logger.debug(f"🔍 Спроба 2: Пошук через Telegram API")
            try:
                chat = await context.bot.get_chat(f"@{username}")
                logger.debug(f"✅ Знайдено через API: {chat}")
                return {
                    "user_id": chat.id,
                    "username": chat.username or username,
                    "full_name": chat.full_name or chat.first_name or ""
                }
            except Exception as e:
                logger.debug(f"⚠️ API Telegram не знайшов: {e}")
            
            # Спроба 3: Пошук через get_chat_member в обох чатах
            logger.debug(f"🔍 Спроба 3: Пошук через get_chat_member в чатах")
            all_user_ids = db.get_all_users()
            for user_id in all_user_ids:
                try:
                    chat_member = await context.bot.get_chat_member(USER_CHAT_ID, user_id)
                    if chat_member.user.username and chat_member.user.username.lower() == username.lower():
                        logger.debug(f"✅ Знайдено в USER_CHAT: {chat_member.user}")
                        return {
                            "user_id": user_id,
                            "username": chat_member.user.username,
                            "full_name": chat_member.user.full_name or ""
                        }
                except:
                    pass
            
            logger.warning(f"❌ Користувача @{username} не знайдено")
            # Покращена помилка для користувача
            logger.info(f"⚠️ Можливі причини:")
            logger.info(f"   1. Користувач @{username} ніколи не писав повідомлення у бот/групу")
            logger.info(f"   2. Акаунт приватний або був видалений")
            logger.info(f"   3. Невірно введене ім'я користувача")
            return None
        else:
            # Пошук по ID
            user_id = int(identifier)
            try:
                chat_member = await context.bot.get_chat_member(USER_CHAT_ID, user_id)
                user = chat_member.user
            except:
                try:
                    if ADMIN_CHAT_ID:
                        chat_member = await context.bot.get_chat_member(ADMIN_CHAT_ID, user_id)
                        user = chat_member.user
                    else:
                        logger.error(f"Не вдалося знайти користувача з ID {user_id}")
                        return None
                except Exception as e:
                    logger.error(f"Не вдалося знайти користувача з ID {user_id}: {e}")
                    return None
            
            return {
                "user_id": user.id,
                "username": user.username or "",
                "full_name": user.full_name or ""
            }
    except Exception as e:
        logger.error(f"Помилка отримання інформації про користувача {identifier}: {e}")
        return None

def save_user_from_update(update: Update):
    """Сохранить пользователя в БД з інформацією з Update"""
    if not update.effective_user:
        return
    
    user_id = update.effective_user.id
    username = update.effective_user.username or ""
    full_name = update.effective_user.full_name or ""
    
    db.add_or_update_user(user_id, username=username, full_name=full_name)
    logger.debug(f"💾 Збережено користувача: {user_id} (@{username}) {full_name}")

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.message:
        return
    
    # Сохраняем пользователя в БД
    save_user_from_update(update)
    
    help_text = """🎄 SANTA ADMIN BOT

Ласкаво просимо! 👋

/help - показати команди для користувачів"""
    
    await reply_and_delete(update, help_text, delay=60)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Команди для звичайних користувачів"""
    if not update.message:
        return
    
    help_text = """📚 КОМАНДИ ДЛЯ КОРИСТУВАЧІВ

👤 ПЕРСОНАЛЬНІ НАЛАШТУВАННЯ:
/myname - встановити кастомне імʼя (видиме скрізь)
/mym - встановити профіль-гіфку/фото (reply на медіа)
/mymt - встановити опис профілю (до 300 символів)
/hto - переглянути свій профіль (без аргумента)

📝 НОТАТКИ ТА НАГАДУВАННЯ:
/note - зберегти нотатку (для всіх!)
/notes - показати свої нотатки (для всіх!)
/delnote - видалити нотатку за номером (для всіх!)
/reminder - створити нагадування для себе
/reminde - створити нагадування для іншого користувача

🎂 ДНИ НАРОДЖЕННЯ:
/birthdays - показати список днів народження
/addb - додати день народження користувачу

👥 ІНФОРМАЦІЯ:
/alarm - виклик адміністрації
/hto - інформація про користувача
/online_list - показати список адмінів онлайн
/help - показати цю справку
/helpg - команди для гномів (якщо у вас є права)"""
    
    await reply_and_delete(update, help_text, delay=60)

async def help_g_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Команди для гномів"""
    if not update.message or not update.effective_user:
        return
    
    user_id = update.effective_user.id
    
    if not is_gnome(user_id) and not is_head_admin(user_id) and not is_owner(user_id):
        await reply_and_delete(update, "❌ Ця команда доступна тільки для гномів, головних адмінів і власника!")
        return
    
    help_text = """🧙 КОМАНДИ ДЛЯ ГНОМІВ

👤 ПЕРСОНАЛЬНІ НАЛАШТУВАННЯ:
/myname - встановити кастомне імʼя (видиме скрізь)
/mym - встановити профіль-гіфку/фото (reply на медіа)
/mymt - встановити опис профілю (до 300 символів)
/hto - переглянути свій профіль (без аргумента)

🗣️ ВІДПРАВЛЕННЯ ПОВІДОМЛЕНЬ:
/say - надіслати повідомлення з підписом
/says - надіслати анонімне повідомлення
/sayon - увімкнути режим авто-відповіді з підписом
/sayson - увімкнути режим анонімних авто-відповідей
/sayoff - вимкнути режим авто-відповіді
/saypin - надіслати і закріпити повідомлення
/save_s - зберегти повідомлення в адмін-чат
/sayb - заблокувати можливість використання /say користувачу
/sayu - розблокувати можливість використання /say користувачу

📢 РОЗСИЛКА:
/broadcast - розсилка повідомлення всім

📝 НОТАТКИ ТА НАГАДУВАННЯ (доступно ДЛЯ ВСІХ):
/note - зберегти нотатку
/notes - показати свої нотатки
/delnote - видалити нотатку за номером
/reminder - створити нагадування для себе
/reminde - створити нагадування для іншого користувача

🎂 ДНИ НАРОДЖЕННЯ:
/birthdays - показати список днів народження
/addb - додати день народження користувачу

👥 ІНФОРМАЦІЯ:
/alarm - виклик адміністрації
/hto - інформація про користувача
/online_list - показати список адмінів онлайн
/help - команди для звичайних користувачів
/helpg - показати цю справку
/helpm - команди для головних адмінів (якщо у вас є права)
/allcmd - команди для власника (якщо у вас є права)"""
    
    await reply_and_delete(update, help_text, delay=60)

async def help_m_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Команди для головних адмінів"""
    if not update.message or not update.effective_user:
        return
    
    user_id = update.effective_user.id
    
    if not is_head_admin(user_id) and not is_owner(user_id):
        await reply_and_delete(update, "❌ Ця команда доступна тільки для головних адмінів і власника!")
        return
    
    help_text = """👑 КОМАНДИ ДЛЯ ГОЛОВНИХ АДМІНІВ

🔧 УПРАВЛІННЯ ГНОМАМИ:
/add_gnome - додати гнома
/remove_gnome - видалити гнома

🚫 МОДЕРАЦІЯ:
/ban_s - тихий бан користувача
/ban_t - публічний бан користувача
/unban_s - тихе розблокування користувача
/unban_t - публічне розблокування користувача
/mute_s - тихий мут користувача
/mute_t - публічний мут користувача
/unmute_s - тихе розмут користувача
/unmute_t - публічне розмут користувача
/kick - вигнати учасника з чату
/nah - додати користувача в чорний список

🗣️ ВІДПРАВЛЕННЯ ПОВІДОМЛЕНЬ:
/say - надіслати повідомлення з підписом
/says - надіслати анонімне повідомлення
/sayon - увімкнути режим авто-відповіді з підписом
/sayson - увімкнути режим анонімних авто-відповідей
/sayoff - вимкнути режим авто-відповіді
/sayoffall - вимкнути режим для ВСІХ користувачів
/saypin - надіслати і закріпити повідомлення
/save_s - зберегти повідомлення в адмін-чат
/sayb - заблокувати можливість використання /say користувачу
/sayu - розблокувати можливість використання /say користувачу

📢 РОЗСИЛКА:
/broadcast - розсилка повідомлення всім

👤 ПЕРСОНАЛЬНІ НАЛАШТУВАННЯ:
/myname - встановити кастомне імʼя (видиме скрізь)

📝 НОТАТКИ ТА НАГАДУВАННЯ (доступно ДЛЯ ВСІХ):
/note - зберегти нотатку
/notes - показати свої нотатки
/delnote - видалити нотатку за номером
/reminder - створити нагадування для себе
/reminde - створити нагадування для іншого користувача

🎂 ДНИ НАРОДЖЕННЯ:
/birthdays - показати список днів народження
/addb - додати день народження користувачу

👥 ІНФОРМАЦІЯ:
/alarm - виклик адміністрації
/hto - інформація про користувача
/online_list - показати список адмінів онлайн
/help - команди для звичайних користувачів
/helpg - показати цю справку
/helpm - команди для власника (якщо у вас є права)
/allcmd - команди для власника (якщо у вас є права)"""
    
    await reply_and_delete(update, help_text, delay=60)

async def allcmd_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Всі команди для власника"""
    if not update.message or not update.effective_user:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Ця команда доступна тільки для власника!")
        return
    
    help_text = """🌟 ВСІ ДОСТУПНІ КОМАНДИ ВЛАСНИКА

🔑 УПРАВЛІННЯ АДМІНАМИ:
/add_main_admin - додати головного адміна
/remove_main_admin - видалити головного адміна

🔧 УПРАВЛІННЯ ГНОМАМИ:
/add_gnome - додати гнома
/remove_gnome - видалити гнома

🚫 МОДЕРАЦІЯ:
/ban_s - тихий бан користувача
/ban_t - публічний бан користувача
/unban_s - тихе розблокування користувача
/unban_t - публічне розблокування користувача
/mute_s - тихий мут користувача
/mute_t - публічний мут користувача
/unmute_s - тихе розмут користувача
/unmute_t - публічне розмут користувача
/kick - вигнати учасника з чату
/nah - додати користувача в чорний список

🗣️ ВІДПРАВЛЕННЯ ПОВІДОМЛЕНЬ:
/say - надіслати повідомлення з підписом
/says - надіслати анонімне повідомлення
/sayon - увімкнути режим авто-відповіді з підписом
/sayson - увімкнути режим анонімних авто-відповідей
/sayoff - вимкнути режим авто-відповіді
/sayoffall - вимкнути режим для ВСІХ користувачів
/saypin - надіслати і закріпити повідомлення
/save_s - зберегти повідомлення в адмін-чат
/sayb - заблокувати можливість використання /say користувачу
/sayu - розблокувати можливість використання /say користувачу
/santas - тихо зберегти повідомлення в канал Санти

📢 РОЗСИЛКА:
/broadcast - розсилка повідомлення всім

👤 ПЕРСОНАЛЬНІ НАЛАШТУВАННЯ (доступно ДЛЯ ВСІХ):
/myname - встановити кастомне імʼя (видиме скрізь)
/mym - встановити профіль-гіфку/фото (reply на медіа)
/mymt - встановити опис профілю (до 300 символів)
/hto - переглянути свій профіль (без аргумента)
/htop - призначити кастомну посаду користувачу (reply на mensaje)

📝 НОТАТКИ ТА НАГАДУВАННЯ (доступно ДЛЯ ВСІХ):
/note - зберегти нотатку
/notes - показати свої нотатки (можете переглядати чужі за ID)
/delnote - видалити нотатку за номером
/reminder - створити нагадування для себе
/reminde - створити нагадування для іншого користувача

🎂 ДНИ НАРОДЖЕННЯ:
/birthdays - показати список днів народження
/addb - додати день народження користувачу
/setbgif - встановити GIF для привітань днів народження
/setbtext - встановити текст привітань днів народження
/previewb - показати попередній перегляд привітань (текст і GIF)

⚙️ НАЛАШТУВАННЯ:
/adminchat - змінити ID адмін-чату
/userchat - змінити ID чату користувачів
/logchannel - змінити ID каналу логування
/testchannel - змінити ID тестового каналу
/deltimer - встановити таймер видалення відповідей (1-60 сек)
/restart - перезапустити бота

👥 ІНФОРМАЦІЯ:
/alarm - виклик адміністрації
/hto - інформація про користувача
/online_list - показати список адмінів онлайн
/help - команди для звичайних користувачів
/helpg - команди для гномів
/helpm - команди для головних адмінів
/allcmd - показати ВСІ команди (ця справка)"""
    
    await reply_and_delete(update, help_text, delay=60)

async def add_gnome_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_manage_gnomes(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    db.add_role(target_user["user_id"], "gnome", user_id, target_user["full_name"], target_user["username"])
    
    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
    target_name = safe_send_message(target_user["full_name"])
    target_username = f"(@{target_user['username']})" if target_user["username"] else ""
    
    role_text = "Власник" if is_owner(user_id) else "Головний адмін"
    
    message = f"""{role_text}
{admin_name} {admin_username} [{user_id}]
➕ Призначив гномом
{target_name} {target_username} [{target_user['user_id']}]"""
    
    await reply_and_delete(update, f"✅ {target_name} призначений гномом!", delay=60)
    
    await log_to_channel(context, message + "\n#add_gnome")
    db.log_action("add_gnome", user_id, target_user["user_id"], message)

async def remove_gnome_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_manage_gnomes(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    db.remove_role(target_user["user_id"])
    
    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
    target_name = safe_send_message(target_user["full_name"])
    target_username = f"(@{target_user['username']})" if target_user["username"] else ""
    
    role_text = "Власник" if is_owner(user_id) else "Головний адмін"
    
    message = f"""{role_text}
{admin_name} {admin_username} [{user_id}]
➖ Видалив гнома
{target_name} {target_username} [{target_user['user_id']}]"""
    
    await reply_and_delete(update, f"✅ {target_name} видалений з гномів!", delay=60)
    
    await log_to_channel(context, message + "\n#remove_gnome")
    db.log_action("remove_gnome", user_id, target_user["user_id"], message)

async def add_main_admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Тільки власник може додавати головних адмінів!")
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    db.add_role(target_user["user_id"], "head_admin", user_id, target_user["full_name"], target_user["username"])
    
    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
    target_name = safe_send_message(target_user["full_name"])
    target_username = f"(@{target_user['username']})" if target_user["username"] else ""
    
    message = f"""Власник
{admin_name} {admin_username} [{user_id}]
➕ Призначив Головним адміном
{target_name} {target_username} [{target_user['user_id']}]"""
    
    await reply_and_delete(update, f"✅ {target_name} призначений головним адміном!", delay=60)
    
    await log_to_channel(context, message + "\n#add_main_admin")
    db.log_action("add_main_admin", user_id, target_user["user_id"], message)

async def remove_main_admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Тільки власник може видаляти головних адмінів!")
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    db.remove_role(target_user["user_id"])
    
    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
    target_name = safe_send_message(target_user["full_name"])
    target_username = f"(@{target_user['username']})" if target_user["username"] else ""
    
    message = f"""Власник
{admin_name} {admin_username} [{user_id}]
➖ Видалив Головного адміна
{target_name} {target_username} [{target_user['user_id']}]"""
    
    await reply_and_delete(update, f"✅ {target_name} видалений з головних адмінів!", delay=60)
    
    await log_to_channel(context, message + "\n#remove_main_admin")
    db.log_action("remove_main_admin", user_id, target_user["user_id"], message)


async def ban_s_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    try:
        await context.bot.ban_chat_member(USER_CHAT_ID, target_user["user_id"])
        db.add_ban(target_user["user_id"], user_id, "Тихий бан", 
                   update.effective_user.full_name or "", update.effective_user.username or "")
        
        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        admin_username = update.effective_user.username or ""
        target_name = safe_send_message(target_user["full_name"])
        
        log_message = f"""🚷 #BAN
• Хто: {admin_name} ({admin_username}) [{user_id}]
• Кому: {target_name} [{target_user['user_id']}]
• Група: {USER_CHAT_ID}
#id{target_user['user_id']}"""
        
        await log_to_channel(context, log_message)
        await reply_and_delete(update, "✅ Користувача заблоковано (тихо)")
        db.log_action("ban_s", user_id, target_user["user_id"], log_message)
    except Exception as e:
        logger.error(f"Помилка бану: {e}")
        await reply_and_delete(update, f"❌ Боту потрібні права або помилка: {e}", delay=60)

async def ban_t_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    reason = " ".join(context.args) if context.args else "Порушення правил"
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    
    if not target_user:
        await reply_and_delete(update, "❌ Відповідьте на повідомлення користувача!", delay=60)
        return
    
    try:
        await context.bot.ban_chat_member(USER_CHAT_ID, target_user["user_id"])
        db.add_ban(target_user["user_id"], user_id, reason, 
                   update.effective_user.full_name or "", update.effective_user.username or "")
        
        await context.bot.send_message(
            chat_id=USER_CHAT_ID,
            text=f"🚫 Користувач {target_user['full_name']} заблокований.\nПричина: {reason}",
            parse_mode=None
        )
        
        try:
            await context.bot.send_message(
                chat_id=target_user["user_id"],
                text=f"Ви були заблоковані. Причина: {reason}",
                parse_mode=None
            )
        except:
            pass
        
        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        admin_username = update.effective_user.username or ""
        target_name = safe_send_message(target_user["full_name"])
        
        log_message = f"""🚷 #BAN
• Хто: {admin_name} ({admin_username}) [{user_id}]
• Кому: {target_name} [{target_user['user_id']}]
• Причина: {reason}
• Група: {USER_CHAT_ID}
#id{target_user['user_id']}"""
        
        await log_to_channel(context, log_message)
        await reply_and_delete(update, "✅ Користувача заблоковано публічно", delay=60)
        db.log_action("ban_t", user_id, target_user["user_id"], log_message)
    except Exception as e:
        logger.error(f"Помилка бану: {e}")
        await reply_and_delete(update, f"❌ Боту потрібні права або помилка: {e}", delay=60)

async def unban_s_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    try:
        await context.bot.unban_chat_member(USER_CHAT_ID, target_user["user_id"])
        db.remove_ban(target_user["user_id"])
        await reply_and_delete(update, "✅ Користувача розблоковано (тихо)")
        db.log_action("unban_s", user_id, target_user["user_id"])
    except Exception as e:
        logger.error(f"Помилка команди: {e}")
        try:
            await reply_and_delete(update, f"❌ Помилка: {e}", delay=60)
        except:
            pass

async def unban_t_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    try:
        await context.bot.unban_chat_member(USER_CHAT_ID, target_user["user_id"])
        db.remove_ban(target_user["user_id"])
        
        await context.bot.send_message(
            chat_id=USER_CHAT_ID,
            text=f"✅ Користувач {target_user['full_name']} розблокований.",
            parse_mode=None
        )
        
        await reply_and_delete(update, "✅ Користувача розблоковано публічно", delay=60)
        db.log_action("unban_t", user_id, target_user["user_id"])
    except Exception as e:
        logger.error(f"Помилка команди: {e}")
        try:
            await reply_and_delete(update, f"❌ Помилка: {e}", delay=60)
        except:
            pass

async def mute_s_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    try:
        permissions = ChatPermissions(can_send_messages=False)
        await context.bot.restrict_chat_member(USER_CHAT_ID, target_user["user_id"], permissions)
        db.add_mute(target_user["user_id"], user_id, "Тихий мут", 
                    update.effective_user.full_name or "", update.effective_user.username or "")
        await reply_and_delete(update, "✅ Користувача замучено (тихо)")
        db.log_action("mute_s", user_id, target_user["user_id"])
    except Exception as e:
        await reply_and_delete(update, f"❌ Боту потрібні права або помилка: {e}", delay=60)

async def mute_t_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    reason = " ".join(context.args) if context.args else "Порушення правил"
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    
    if not target_user:
        await reply_and_delete(update, "❌ Відповідьте на повідомлення користувача!", delay=60)
        return
    
    try:
        permissions = ChatPermissions(can_send_messages=False)
        await context.bot.restrict_chat_member(USER_CHAT_ID, target_user["user_id"], permissions)
        db.add_mute(target_user["user_id"], user_id, reason, 
                    update.effective_user.full_name or "", update.effective_user.username or "")
        
        await context.bot.send_message(
            chat_id=USER_CHAT_ID,
            text=f"🔇 Користувач {target_user['full_name']} замучений.\nПричина: {reason}",
            parse_mode=None
        )
        
        await reply_and_delete(update, "✅ Користувача замучено публічно", delay=60)
        db.log_action("mute_t", user_id, target_user["user_id"], reason)
    except Exception as e:
        await reply_and_delete(update, f"❌ Боту потрібні права або помилка: {e}", delay=60)

async def unmute_s_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    try:
        permissions = ChatPermissions(
            can_send_messages=True,
            can_send_polls=True,
            can_send_other_messages=True,
            can_add_web_page_previews=True
        )
        await context.bot.restrict_chat_member(USER_CHAT_ID, target_user["user_id"], permissions)
        db.remove_mute(target_user["user_id"])
        await reply_and_delete(update, "✅ Користувача розмучено (тихо)")
        db.log_action("unmute_s", user_id, target_user["user_id"])
    except Exception as e:
        logger.error(f"Помилка команди: {e}")
        try:
            await reply_and_delete(update, f"❌ Помилка: {e}", delay=60)
        except:
            pass

async def unmute_t_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    try:
        permissions = ChatPermissions(
            can_send_messages=True,
            can_send_polls=True,
            can_send_other_messages=True,
            can_add_web_page_previews=True
        )
        await context.bot.restrict_chat_member(USER_CHAT_ID, target_user["user_id"], permissions)
        db.remove_mute(target_user["user_id"])
        
        await context.bot.send_message(
            chat_id=USER_CHAT_ID,
            text=f"🔊 Користувач {target_user['full_name']} розмучений.",
            parse_mode=None
        )
        
        await reply_and_delete(update, "✅ Користувача розмучено публічно", delay=60)
        db.log_action("unmute_t", user_id, target_user["user_id"])
    except Exception as e:
        logger.error(f"Помилка команди: {e}")
        try:
            await reply_and_delete(update, f"❌ Помилка: {e}", delay=60)
        except:
            pass

async def kick_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!", delay=60)
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!", delay=60)
        return
    
    try:
        await context.bot.ban_chat_member(USER_CHAT_ID, target_user["user_id"])
        await context.bot.unban_chat_member(USER_CHAT_ID, target_user["user_id"])
        await reply_and_delete(update, "✅ Користувача вигнано з чату", delay=60)
        db.log_action("kick", user_id, target_user["user_id"])
    except Exception as e:
        await reply_and_delete(update, f"❌ Боту потрібні права або помилка: {e}", delay=60)

async def nah_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Тільки власник може додавати в чорний список!")
        return
    
    target_user = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
    elif context.args:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Вкажіть ID, @username або відповідьте на повідомлення користувача!")
        return
    
    db.add_to_blacklist(target_user["user_id"], user_id, "Чорний список", 
                        update.effective_user.full_name or "", update.effective_user.username or "")
    
    try:
        await context.bot.ban_chat_member(USER_CHAT_ID, target_user["user_id"])
    except:
        pass
    
    await reply_and_delete(update, f"✅ {target_user['full_name']} додано в чорний список!")
    db.log_action("blacklist", user_id, target_user["user_id"], "Added to blacklist")


async def say_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message or not update.effective_chat:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    if db.is_say_blocked(user_id):
        await reply_and_delete(update, "❌ Вашу можливість використання /say заблоковано!")
        return
    
    if not USER_CHAT_ID:
        await reply_and_delete(update, "❌ Не налаштовано чат користувачів!")
        return
    
    author_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    username = f"@{safe_send_message(update.effective_user.username)}" if update.effective_user.username else ""
    signature = f"— {author_name} {username}"
    
    try:
        if update.message.reply_to_message:
            replied_message = update.message.reply_to_message
            
            # Якщо вказаний текст після /say - відправити як reply в USER_CHAT_ID
            if context.args:
                message_text = ' '.join(context.args)
                clean_message = safe_send_message(message_text)
                final_message = f"{clean_message}\n\n{signature}"
                
                await context.bot.send_message(
                    chat_id=USER_CHAT_ID,
                    text=final_message,
                    reply_to_message_id=replied_message.message_id,
                    parse_mode=None,
                    disable_web_page_preview=True
                )
                logger.info(f"📤 /say: текст від {user_id} як reply на {replied_message.message_id} відправлено в USER_CHAT_ID")
            else:
                # Без тексту - пересилати саме повідомлення в USER_CHAT_ID
                if replied_message.text:
                    clean_message = safe_send_message(replied_message.text)
                    final_message = f"{clean_message}\n\n{signature}"
                    await context.bot.send_message(
                        chat_id=USER_CHAT_ID,
                        text=final_message,
                        parse_mode=None,
                        disable_web_page_preview=True
                    )
                elif replied_message.caption:
                    clean_caption = safe_send_message(replied_message.caption)
                    final_message = f"{clean_caption}\n\n{signature}"
                    await context.bot.send_message(
                        chat_id=USER_CHAT_ID,
                        text=final_message,
                        parse_mode=None,
                        disable_web_page_preview=True
                    )
                else:
                    if update.effective_chat:
                        await context.bot.forward_message(
                            chat_id=USER_CHAT_ID,
                            from_chat_id=update.effective_chat.id,
                            message_id=replied_message.message_id
                        )
                    await context.bot.send_message(
                        chat_id=USER_CHAT_ID,
                        text=signature,
                        parse_mode=None,
                        disable_web_page_preview=True
                    )
                logger.info(f"📤 /say: повідомлення від {user_id} пересилано в USER_CHAT_ID")
        elif context.args:
            message_text = ' '.join(context.args)
            
            # Перевіримо чи це посилання на Telegram повідомлення
            reply_to_id = None
            target_chat_id = USER_CHAT_ID
            
            # Шукаємо посилання у тексту
            link_match = re.search(r'https?://t\.me/c/\d+/\d+', message_text)
            if link_match:
                link = link_match.group()
                parsed_chat_id, parsed_message_id = parse_telegram_link(link)
                
                if parsed_chat_id and parsed_message_id:
                    # Видаляємо посилання з тексту
                    text_without_link = message_text.replace(link, '').strip()
                    clean_message = safe_send_message(text_without_link)
                    target_chat_id = parsed_chat_id
                    reply_to_id = parsed_message_id
                    final_message = f"{clean_message}\n\n{signature}"
                    logger.info(f"📤 /say: текст в чат {target_chat_id} reply на {reply_to_id}")
                else:
                    clean_message = safe_send_message(message_text)
                    final_message = f"{clean_message}\n\n{signature}"
                    logger.info(f"📤 /say: невірне посилання в тексті")
            else:
                clean_message = safe_send_message(message_text)
                final_message = f"{clean_message}\n\n{signature}"
            
            await context.bot.send_message(
                chat_id=target_chat_id,
                text=final_message,
                reply_to_message_id=reply_to_id,
                parse_mode=None,
                disable_web_page_preview=True
            )
            logger.info(f"📤 /say: текст від {user_id} відправлено")
            db.log_action("say", user_id, details=f"Message sent to user chat")
        else:
            await reply_and_delete(update, "❌ Вкажіть повідомлення після команди або відповідьте на повідомлення!")
            return
        
    except Exception as e:
        logger.error(f"Помилка відправки: {e}")
        try:
            await reply_and_delete(update, f"❌ Помилка відправки: {e}")
        except:
            pass

async def says_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message or not update.effective_chat:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    if db.is_say_blocked(user_id):
        await reply_and_delete(update, "❌ Вашу можливість використання /says заблоковано!")
        return
    
    if not USER_CHAT_ID:
        await reply_and_delete(update, "❌ Не налаштовано чат користувачів!")
        return
    
    try:
        if update.message.reply_to_message:
            replied_message = update.message.reply_to_message
            
            # Якщо вказаний текст після /says - відправити як reply в USER_CHAT_ID (анонімно)
            if context.args:
                message_text = ' '.join(context.args)
                clean_message = safe_send_message(message_text)
                
                await context.bot.send_message(
                    chat_id=USER_CHAT_ID,
                    text=clean_message,
                    reply_to_message_id=replied_message.message_id,
                    parse_mode=None,
                    disable_web_page_preview=True
                )
                logger.info(f"📤 /says: анонімний текст від {user_id} як reply на {replied_message.message_id} відправлено в USER_CHAT_ID")
            else:
                # Без тексту - пересилати саме повідомлення в USER_CHAT_ID
                if replied_message.text:
                    clean_message = safe_send_message(replied_message.text)
                    await context.bot.send_message(
                        chat_id=USER_CHAT_ID,
                        text=clean_message,
                        parse_mode=None,
                        disable_web_page_preview=True
                    )
                elif replied_message.caption:
                    clean_caption = safe_send_message(replied_message.caption)
                    await context.bot.send_message(
                        chat_id=USER_CHAT_ID,
                        text=clean_caption,
                        parse_mode=None,
                        disable_web_page_preview=True
                    )
                else:
                    if update.effective_chat:
                        await context.bot.forward_message(
                            chat_id=USER_CHAT_ID,
                            from_chat_id=update.effective_chat.id,
                            message_id=replied_message.message_id
                        )
                logger.info(f"📤 /says: повідомлення від {user_id} пересилано в USER_CHAT_ID")
        elif context.args:
            message_text = ' '.join(context.args)
            
            # Перевіримо чи це посилання на Telegram повідомлення
            reply_to_id = None
            target_chat_id = USER_CHAT_ID
            
            # Шукаємо посилання у тексту
            link_match = re.search(r'https?://t\.me/c/\d+/\d+', message_text)
            if link_match:
                link = link_match.group()
                parsed_chat_id, parsed_message_id = parse_telegram_link(link)
                
                if parsed_chat_id and parsed_message_id:
                    # Видаляємо посилання з тексту
                    text_without_link = message_text.replace(link, '').strip()
                    clean_message = safe_send_message(text_without_link)
                    target_chat_id = parsed_chat_id
                    reply_to_id = parsed_message_id
                    logger.info(f"📤 /says: текст в чат {target_chat_id} reply на {reply_to_id}")
                else:
                    clean_message = safe_send_message(message_text)
                    logger.info(f"📤 /says: невірне посилання в тексті")
            else:
                clean_message = safe_send_message(message_text)
            
            await context.bot.send_message(
                chat_id=target_chat_id,
                text=clean_message,
                reply_to_message_id=reply_to_id,
                parse_mode=None,
                disable_web_page_preview=True
            )
            logger.info(f"📤 /says: текст від {user_id} відправлено")
            db.log_action("says", user_id, details="Anonymous message sent to user chat")
        else:
            await reply_and_delete(update, "❌ Вкажіть повідомлення після команди або відповідьте на повідомлення!")
            return
        
    except Exception as e:
        logger.error(f"Помилка відправки: {e}")
        try:
            await reply_and_delete(update, f"❌ Помилка відправки: {e}")
        except:
            pass

async def sayon_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    if db.is_say_blocked(user_id):
        await reply_and_delete(update, "❌ Вашу можливість використання sayon заблоковано!")
        return
    
    current_mode = db.get_online_mode(user_id)
    
    if current_mode == "sayon":
        db.remove_online_mode(user_id)
        await reply_and_delete(update, "✅ Режим sayon вимкнено")
        
        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
        
        log_message = f"""Власник/Адмін
{admin_name} {admin_username} [{user_id}]
Автоматичне пересилання з підписом вимкнено
#sayoff #id{user_id}"""
        
        await log_to_channel(context, log_message)
    else:
        source_chat_id = update.effective_chat.id if update.effective_chat else 0
        db.set_online_mode(user_id, "sayon", source_chat_id)
        await reply_and_delete(update, "✅ Режим sayon увімкнено! Ваші повідомлення будуть автоматично пересилатися з підписом.\nРежим вимкнеться автоматично через 5 хвилин неактивності.")
        
        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
        
        role_text = "Власник" if is_owner(user_id) else ("Головний адмін" if is_head_admin(user_id) else "Гном")
        
        log_message = f"""{role_text}
{admin_name} {admin_username} [{user_id}]
Автоматичне пересилання з підписом увімкнено
#sayon #id{user_id}"""
        
        await log_to_channel(context, log_message)

async def sayson_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    if db.is_say_blocked(user_id):
        await reply_and_delete(update, "❌ Вашу можливість використання sayson заблоковано!")
        return
    
    current_mode = db.get_online_mode(user_id)
    
    if current_mode == "sayson":
        db.remove_online_mode(user_id)
        await reply_and_delete(update, "✅ Режим sayson вимкнено")
        
        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
        
        log_message = f"""Власник/Адмін
{admin_name} {admin_username} [{user_id}]
Автоматичне пересилання без підпису вимкнено
#saysoff #id{user_id}"""
        
        await log_to_channel(context, log_message)
    else:
        source_chat_id = update.effective_chat.id if update.effective_chat else 0
        db.set_online_mode(user_id, "sayson", source_chat_id)
        await reply_and_delete(update, "✅ Режим sayson увімкнено! Ваші повідомлення будуть автоматично пересилатися анонімно.\nРежим вимкнеться автоматично через 5 хвилин неактивності.")
        
        admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
        admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
        
        role_text = "Власник" if is_owner(user_id) else ("Головний адмін" if is_head_admin(user_id) else "Гном")
        
        log_message = f"""{role_text}
{admin_name} {admin_username} [{user_id}]
Автоматичне пересилання без підпису увімкнено
#sayson #id{user_id}"""
        
        await log_to_channel(context, log_message)

async def sayoff_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    current_mode = db.get_online_mode(user_id)
    
    if not current_mode:
        await reply_and_delete(update, "❌ Режим не вмикнено!")
        return
    
    db.remove_online_mode(user_id)
    await reply_and_delete(update, "✅ Режим вимкнено")
    
    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
    
    mode_text = "з підписом" if current_mode == "sayon" else "анонімно"
    log_message = f"""Власник/Адмін
{admin_name} {admin_username} [{user_id}]
Автоматичне пересилання {mode_text} вимкнено
#sayoff #id{user_id}"""
    
    await log_to_channel(context, log_message)

async def sayoffall_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ Тільки власник і головні адміни мають доступ до цієї команди!")
        return
    
    all_modes = db.get_all_online_modes()
    
    if not all_modes:
        await reply_and_delete(update, "❌ Немає активних режимів!")
        return
    
    count = len(all_modes)
    db.clear_all_online_modes()
    await reply_and_delete(update, f"✅ Вимкнено режим для {count} користувачів")
    
    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    admin_username = f"(@{update.effective_user.username})" if update.effective_user.username else ""
    role_text = "Власник" if is_owner(user_id) else "Головний адмін"
    
    modes_list = "\n".join([f"• {m['full_name'] or m['user_id']} ({m['mode']})" for m in all_modes])
    
    log_message = f"""{role_text}
{admin_name} {admin_username} [{user_id}]
Вимкнено режими для {count} користувачів:
{modes_list}
#sayoffall"""
    
    await log_to_channel(context, log_message)

async def handle_all_messages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.effective_user or not update.message or not update.effective_chat:
        return
    
    # Сохраняем всех пользователей в БД при первом сообщении
    save_user_from_update(update)
    
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    
    if not can_use_bot(user_id):
        return
    
    # Обробка команд видалення профілю простим текстом (з дефісом на початку)
    if update.message.text and update.message.text.startswith('-'):
        text = update.message.text.strip()
        
        # -myname - видалити кастомне імʼя
        if text == '-myname':
            await del_myname_command(update, context)
            return
        
        # -mym - видалити профіль-фото
        elif text == '-mym':
            await del_mym_command(update, context)
            return
        
        # -mymt - видалити опис профілю
        elif text == '-mymt':
            await del_mymt_command(update, context)
            return
        
        # -htop @username - видалити посаду
        elif text.startswith('-htop'):
            parts = text.split(maxsplit=1)
            if len(parts) > 1:
                # Створюємо fake context.args для del_htop_command
                context.args = parts[1].split()
            else:
                context.args = []
            await del_htop_command(update, context)
            return
    
    if not USER_CHAT_ID:
        logger.error("❌ USER_CHAT_ID не встановлено!")
        return
    
    mode = db.get_online_mode(user_id)
    source_chat_id = db.get_online_mode_source(user_id)
    
    if not mode or source_chat_id != chat_id:
        return
    
    logger.info(f"📨 Пересилаємо ({mode}): user={user_id}, from_chat={chat_id}, to_chat={USER_CHAT_ID}")
    
    db.update_online_activity(user_id)
    
    try:
        if mode == "sayon":
            author_name = safe_send_message(update.effective_user.full_name or "Невідомий")
            username = f"@{safe_send_message(update.effective_user.username)}" if update.effective_user.username else ""
            signature = f"\n\n— {author_name} {username}"
            
            if update.message.text:
                clean_message = safe_send_message(update.message.text)
                await context.bot.send_message(
                    chat_id=USER_CHAT_ID,
                    text=f"{clean_message}{signature}",
                    parse_mode=None,
                    disable_web_page_preview=True
                )
            elif update.message.caption:
                clean_caption = safe_send_message(update.message.caption)
                await context.bot.send_message(
                    chat_id=USER_CHAT_ID,
                    text=f"{clean_caption}{signature}",
                    parse_mode=None,
                    disable_web_page_preview=True
                )
            else:
                await context.bot.forward_message(
                    chat_id=USER_CHAT_ID,
                    from_chat_id=chat_id,
                    message_id=update.message.message_id
                )
                await context.bot.send_message(
                    chat_id=USER_CHAT_ID,
                    text=signature.strip(),
                    parse_mode=None
                )
        
        elif mode == "sayson":
            if update.message.text:
                clean_message = safe_send_message(update.message.text)
                await context.bot.send_message(
                    chat_id=USER_CHAT_ID,
                    text=clean_message,
                    parse_mode=None,
                    disable_web_page_preview=True
                )
            elif update.message.caption:
                clean_caption = safe_send_message(update.message.caption)
                await context.bot.send_message(
                    chat_id=USER_CHAT_ID,
                    text=clean_caption,
                    parse_mode=None,
                    disable_web_page_preview=True
                )
            else:
                await context.bot.forward_message(
                    chat_id=USER_CHAT_ID,
                    from_chat_id=chat_id,
                    message_id=update.message.message_id
                )
        
        logger.info(f"✅ Повідомлення успішно пересилано")
    except Exception as e:
        logger.error(f"❌ Помилка автопересилання: {e}")


async def saypin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message or not update.effective_chat:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    if not USER_CHAT_ID:
        await reply_and_delete(update, "❌ Не налаштовано чат користувачів!")
        return
    
    try:
        sent_message = None
        
        if update.message.reply_to_message:
            replied_message = update.message.reply_to_message
            
            if replied_message.text:
                clean_message = safe_send_message(replied_message.text)
                sent_message = await context.bot.send_message(
                    chat_id=USER_CHAT_ID,
                    text=clean_message,
                    parse_mode=None,
                    disable_web_page_preview=True
                )
            elif replied_message.caption:
                clean_caption = safe_send_message(replied_message.caption)
                sent_message = await context.bot.send_message(
                    chat_id=USER_CHAT_ID,
                    text=clean_caption,
                    parse_mode=None,
                    disable_web_page_preview=True
                )
            else:
                sent_message = await context.bot.forward_message(
                    chat_id=USER_CHAT_ID,
                    from_chat_id=update.effective_chat.id,
                    message_id=replied_message.message_id
                )
        elif context.args:
            message_text = ' '.join(context.args)
            clean_message = safe_send_message(message_text)
            sent_message = await context.bot.send_message(
                chat_id=USER_CHAT_ID,
                text=clean_message,
                parse_mode=None,
                disable_web_page_preview=True
            )
        else:
            await reply_and_delete(update, "❌ Вкажіть повідомлення після команди або відповідьте на повідомлення!")
            return
        
        if sent_message:
            await context.bot.pin_chat_message(USER_CHAT_ID, sent_message.message_id)
        
        await reply_and_delete(update, "✅ Повідомлення відправлено і закріплено!")
        
    except Exception as e:
        logger.error(f"Помилка: {e}")
        await reply_and_delete(update, f"❌ Помилка: {e}")

async def save_s_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message or not update.effective_chat:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    if not update.message.reply_to_message:
        await reply_and_delete(update, "❌ Відповідьте на повідомлення яке потрібно зберегти!")
        return
    
    try:
        if not ADMIN_CHAT_ID:
            await reply_and_delete(update, "❌ Адмін-чат не налаштовано!")
            return
        
        replied_msg = update.message.reply_to_message
        
        # Спочатку спробуємо скопіювати (працює з bot messages і захищеним контентом)
        try:
            await context.bot.copy_message(
                chat_id=ADMIN_CHAT_ID,
                from_chat_id=update.effective_chat.id,
                message_id=replied_msg.message_id
            )
            logger.info(f"✅ Повідомлення скопійовано")
        except Exception as copy_error:
            logger.warning(f"⚠️ Помилка копіювання: {copy_error}, спробую альтернативний метод...")
            
            # Визначаємо тип медіа для логування
            media_type = "невідомо"
            if replied_msg.sticker:
                media_type = "стікер 📌"
            elif replied_msg.photo:
                media_type = "фото 🖼️"
            elif replied_msg.video:
                media_type = "відео 🎬"
            elif replied_msg.animation:
                media_type = "гіфка 🎞️"
            elif replied_msg.document:
                media_type = "документ 📎"
            elif replied_msg.audio:
                media_type = "аудіо 🎵"
            elif replied_msg.text:
                media_type = "текст 📝"
            
            logger.info(f"📤 Тип контенту: {media_type}")
            
            # Якщо копіювання не спрацює, пересилаємо
            try:
                await context.bot.forward_message(
                    chat_id=ADMIN_CHAT_ID,
                    from_chat_id=update.effective_chat.id,
                    message_id=replied_msg.message_id
                )
                logger.info(f"✅ Повідомлення пересилано ({media_type})")
            except Exception as forward_error:
                logger.warning(f"⚠️ Помилка пересилання: {forward_error}, копіюю вміст...")
                
                # Останній варіант - копіюємо вміст (перевіряємо МЕДІА перед ТЕКСТОМ)
                if replied_msg.sticker:
                    logger.info("📌 Копіюю стікер")
                    await context.bot.send_sticker(
                        chat_id=ADMIN_CHAT_ID,
                        sticker=replied_msg.sticker.file_id
                    )
                elif replied_msg.photo:
                    logger.info("🖼️ Копіюю фото")
                    await context.bot.send_photo(
                        chat_id=ADMIN_CHAT_ID,
                        photo=replied_msg.photo[-1].file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.video:
                    logger.info("🎬 Копіюю відео")
                    await context.bot.send_video(
                        chat_id=ADMIN_CHAT_ID,
                        video=replied_msg.video.file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.animation:
                    logger.info("🎞️ Копіюю гіфку")
                    await context.bot.send_animation(
                        chat_id=ADMIN_CHAT_ID,
                        animation=replied_msg.animation.file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.document:
                    logger.info("📎 Копіюю документ")
                    await context.bot.send_document(
                        chat_id=ADMIN_CHAT_ID,
                        document=replied_msg.document.file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.audio:
                    logger.info("🎵 Копіюю аудіо")
                    await context.bot.send_audio(
                        chat_id=ADMIN_CHAT_ID,
                        audio=replied_msg.audio.file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.text:
                    logger.info("📝 Копіюю текст")
                    await context.bot.send_message(
                        chat_id=ADMIN_CHAT_ID,
                        text=replied_msg.text,
                        parse_mode=None
                    )
                else:
                    logger.warning("❓ Невідомий тип повідомлення")
                    await context.bot.send_message(
                        chat_id=ADMIN_CHAT_ID,
                        text="[Повідомлення без тексту]"
                    )
        
        # Тихе збереження - без повідомлення користувачеві
        try:
            await update.message.delete()
        except:
            pass
        
    except Exception as e:
        logger.error(f"Помилка збереження: {e}")
        await reply_and_delete(update, f"❌ Помилка при збереженні: {e}")

async def online_list_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    online_modes = db.get_all_online_modes()
    
    if not online_modes:
        await reply_and_delete(update, "📵 Немає адмінів в онлайн-режимі")
        return
    
    message = "📱 **Адміни в онлайн-режимі:**\n\n"
    
    for mode_data in online_modes:
        name = mode_data.get("full_name", "Невідомий")
        username = f"(@{mode_data.get('username')})" if mode_data.get("username") else ""
        mode = "sayon (з підписом)" if mode_data["mode"] == "sayon" else "sayson (анонімно)"
        message += f"• {name} {username}\n  Режим: {mode}\n\n"
    
    await reply_and_delete(update, message)

async def sayb_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_manage_gnomes(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!")
        return
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть ID користувача!")
        return
    
    try:
        target_id = int(context.args[0])
        
        if is_owner(target_id) and not is_owner(user_id):
            await reply_and_delete(update, "❌ Не можна блокувати власника!")
            return
        
        if is_head_admin(target_id) and not is_owner(user_id):
            await reply_and_delete(update, "❌ Тільки власник може блокувати головних адмінів!")
            return
        
        db.block_say_command(target_id, user_id, 
                             update.effective_user.full_name or "", update.effective_user.username or "")
        await reply_and_delete(update, f"✅ Користувач {target_id} заблокований від використання /say та /says")
        db.log_action("sayb", user_id, target_id)
        
    except ValueError:
        await reply_and_delete(update, "❌ Невірний ID!")

async def sayu_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_manage_gnomes(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!")
        return
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть ID користувача!")
        return
    
    try:
        target_id = int(context.args[0])
        db.unblock_say_command(target_id)
        await reply_and_delete(update, f"✅ Користувач {target_id} розблокований для використання /say та /says")
        db.log_action("sayu", user_id, target_id)
        
    except ValueError:
        await reply_and_delete(update, "❌ Невірний ID!")


async def alarm_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    user_name = update.effective_user.full_name or "Невідомий"
    username = update.effective_user.username or ""
    
    alarm_text = " ".join(context.args) if context.args else "Виклик адміністрації"
    
    message_link = ""
    if update.message.reply_to_message:
        chat_id = str(USER_CHAT_ID).replace("-100", "")
        message_link = f"\n👀 Дивитись повідомлення: http://t.me/c/{chat_id}/{update.message.reply_to_message.message_id}"
    
    alarm_message = f"""🚨 #ALARM
Користувач: {user_name} (@{username}) [{user_id}]
Текст: {alarm_text}{message_link}
#id{user_id}"""
    
    try:
        sent_msg = await context.bot.send_message(
            chat_id=ADMIN_CHAT_ID,
            text=alarm_message,
            parse_mode=None
        )
        
        try:
            await context.bot.pin_chat_message(ADMIN_CHAT_ID, sent_msg.message_id)
        except:
            pass
        
        await reply_and_delete(update, "✅ Передано на перегляд адміністрації, очікуйте.")
        await log_to_channel(context, alarm_message)
        
    except Exception as e:
        logger.error(f"Помилка alarm: {e}")

async def broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!")
        return
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть текст для розсилки!")
        return
    
    message_text = " ".join(context.args)
    clean_message = safe_send_message(message_text)
    
    await reply_and_delete(update, f"📢 Розпочато розсилку повідомлення всім користувачам...")
    
    all_users = db.get_all_users()
    sent_count = 0
    failed_count = 0
    
    logger.info(f"🔊 Розсилка розпочата: {len(all_users)} користувачів")
    
    for target_user_id in all_users:
        try:
            await context.bot.send_message(
                chat_id=target_user_id,
                text=clean_message,
                parse_mode=None
            )
            sent_count += 1
        except Exception as e:
            failed_count += 1
            logger.warning(f"⚠️ Не вдалось отправити користувачу {target_user_id}: {e}")
    
    admin_name = safe_send_message(update.effective_user.full_name or "Невідомий")
    admin_username = f"@{update.effective_user.username}" if update.effective_user.username else ""
    
    result_message = f"""✅ Розсилка завершена!
📤 Отправлено: {sent_count}
❌ Помилок: {failed_count}
👤 Адмін: {admin_name} {admin_username}
📝 Текст: {clean_message}"""
    
    await reply_and_delete(update, result_message)
    
    logger.info(f"✅ Розсилка завершена: {sent_count} успішно, {failed_count} помилок")

async def hto_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Розширена інформація про користувача з профіль-системою"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    target_user_id = user_id
    target_user_name = update.effective_user.full_name or "Невідомий"
    target_username = update.effective_user.username or ""
    
    # Перевіряємо чи це адмін (гном, головний адмін або власник)
    is_admin = is_gnome(user_id) or is_head_admin(user_id) or is_owner(user_id)
    
    # Якщо є аргумент (@username або ID) - адміни можуть переглядати чужих
    if context.args:
        if not is_admin:
            await reply_and_delete(update, "❌ Тільки адміни можуть переглядати інших користувачів!", delay=60)
            return
        
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
        if target_user:
            target_user_id = target_user["user_id"]
            target_user_name = target_user["full_name"]
            target_username = target_user["username"]
        else:
            await reply_and_delete(update, "❌ Користувача не знайдено!", delay=60)
            return
    # Без аргументів і без reply - показуємо інформацію про себе
    elif update.message.reply_to_message and update.message.reply_to_message.from_user:
        # Якщо є reply - адміни можуть переглядати чужих
        if is_admin or user_id == update.message.reply_to_message.from_user.id:
            target_user_id = update.message.reply_to_message.from_user.id
            target_user_name = update.message.reply_to_message.from_user.full_name or "Невідомий"
            target_username = update.message.reply_to_message.from_user.username or ""
        else:
            await reply_and_delete(update, "❌ Ви можете переглядати тільки свій профіль!", delay=60)
            return
    
    user_data = db.get_user(target_user_id)
    custom_name = db.get_custom_name(target_user_id)
    profile_desc = db.get_profile_description(target_user_id)
    custom_position = db.get_custom_position(target_user_id)
    
    # Визначаємо посаду - перевіряємо через функції
    if is_owner(target_user_id):
        position_display = "👑 Власник"
    elif is_head_admin(target_user_id):
        position_display = "🔒 Головний Адмін"
    elif is_gnome(target_user_id):
        position_display = "🧙 Гном"
    else:
        position_display = "👤 Користувач"
    
    # Якщо є кастомна посада - додаємо
    if custom_position:
        position_display += f" ({custom_position})"
    
    info_message = f"""👤 ПРОФІЛЬ КОРИСТУВАЧА

"""
    
    # Кастомне імʼя (якщо є)
    if custom_name:
        info_message += f"📝 Імʼя: {custom_name}\n"
    else:
        info_message += f"📝 Імʼя: {target_user_name}\n"
    
    # Опис профілю (якщо є)
    if profile_desc:
        info_message += f"📄 Про себе: {profile_desc}\n"
    
    info_message += f"""
@{target_username if target_username else 'не вказано'}
ID: {target_user_id}
{position_display}
"""
    
    if user_data and user_data.get("joined_at"):
        # Форматуємо дату: день.місяць.рік - години:хвилини
        try:
            from datetime import datetime
            joined_dt = datetime.fromisoformat(user_data['joined_at'])
            formatted_date = joined_dt.strftime("%d.%m.%Y - %H:%M")
            info_message += f"📅 Дата вступу: {formatted_date}\n"
        except:
            info_message += f"📅 Дата вступу: {user_data['joined_at']}\n"
    
    # Отримуємо профіль-фото якщо є
    profile_pic = db.get_profile_picture(target_user_id)
    if profile_pic:
        try:
            # Якщо є фото/гіфка - надсилаємо її з описом
            if profile_pic["media_type"] == "photo":
                sent_msg = await context.bot.send_photo(
                    chat_id=update.message.chat_id,
                    photo=profile_pic["file_id"],
                    caption=info_message,
                    parse_mode="HTML"
                )
                # Видаляємо через 60 секунд (1 хвилина)
                asyncio.create_task(delete_message_after_delay(sent_msg, 60))
            elif profile_pic["media_type"] == "gif":
                sent_msg = await context.bot.send_animation(
                    chat_id=update.message.chat_id,
                    animation=profile_pic["file_id"],
                    caption=info_message,
                    parse_mode="HTML"
                )
                # Видаляємо через 60 секунд (1 хвилина)
                asyncio.create_task(delete_message_after_delay(sent_msg, 60))
        except Exception as e:
            logger.warning(f"⚠️ Не вдалось надіслати профіль-фото з описом: {e}")
            # Якщо помилка - просто надіслемо текст
            await reply_and_delete(update, info_message, delay=60)
    else:
        # Якщо немає фото - просто надіслемо текст
        await reply_and_delete(update, info_message, delay=60)

async def note_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Зберегти нотатку - доступно для всіх користувачів"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть текст нотатки!\nПриклад: /note важливе завдання на завтра")
        return
    
    note_text = " ".join(context.args)
    db.add_note(user_id, note_text, 
                created_by_id=user_id,
                username=update.effective_user.username or "", 
                full_name=update.effective_user.full_name or "")
    
    try:
        if NOTES_CHANNEL_ID:
            user_name = update.effective_user.full_name or "Невідомий"
            username = f"@{update.effective_user.username}" if update.effective_user.username else ""
            
            note_message = f"""📝 Нотатка від {user_name} {username} [{user_id}]

{note_text}

#id{user_id}"""
            
            await context.bot.send_message(
                chat_id=NOTES_CHANNEL_ID,
                text=note_message,
                parse_mode=None
            )
        
        await reply_and_delete(update, "✅ Нотатку збережено!")
        
    except Exception as e:
        logger.error(f"Помилка збереження нотатки: {e}")
        await reply_and_delete(update, f"❌ Помилка: {e}")

async def notes_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Показати нотатки - кожен користувач видит тільки свої (вінні власник може видіти чужі)"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    target_id = user_id
    
    # Тільки власник може переглядати нотатки інших користувачів
    if context.args and is_owner(user_id):
        try:
            target_id = int(context.args[0])
        except:
            identifier = context.args[0]
            target_user = await get_user_info(update, context, identifier)
            if target_user:
                target_id = target_user["user_id"]
    
    notes = db.get_notes(target_id)
    
    if not notes:
        await reply_and_delete(update, "📝 Нотаток не знайдено")
        return
    
    # Отримуємо ім'я користувача для заголовка
    user_info = db.get_user(target_id)
    user_name = user_info.get("full_name", "Невідомий") if user_info else "Невідомий"
    
    message = f"📝 Нотатки користувача {user_name} [{target_id}]:\n\n"
    
    for idx, note in enumerate(notes, 1):
        formatted_time = format_kyiv_time(note['created_at'])
        # Отримуємо кастомне імʼя якщо є, інакше використовуємо збережене
        creator_id = note.get('created_by_id')
        if creator_id:
            creator_name = get_display_name(creator_id, note.get('created_by_name', 'Невідомий'))
        else:
            creator_name = note.get('created_by_name', 'Невідомий') or 'Невідомий'
        creator_username = f"@{note.get('created_by_username')}" if note.get('created_by_username') else ""
        message += f"{idx}. {note['text']}\n   ({formatted_time}) • {creator_name} {creator_username}\n\n"
    
    await reply_and_delete(update, message)

async def delnote_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Видалити нотатку за номером - доступно для всіх користувачів (тільки свої)"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть номер нотатки для видалення!\nПриклад: /delnote 1")
        return
    
    try:
        note_number = int(context.args[0])
    except ValueError:
        await reply_and_delete(update, "❌ Вкажіть число! Приклад: /delnote 1")
        return
    
    # Отримуємо всі нотатки користувача
    notes = db.get_notes(user_id)
    
    if not notes:
        await reply_and_delete(update, "📝 У вас немає нотаток!")
        return
    
    if note_number < 1 or note_number > len(notes):
        await reply_and_delete(update, f"❌ Нотатка номер {note_number} не знайдена! У вас {len(notes)} нотаток.")
        return
    
    # Видаляємо нотатку (нотатки у db.get_notes() впорядковані від нових до старих)
    note_to_delete = notes[note_number - 1]
    note_id = note_to_delete['id']
    note_text = note_to_delete['text']
    
    if db.delete_note(note_id):
        await reply_and_delete(update, f"✅ Нотатка видалена!\n📝 Текст: {note_text[:50]}...")
        logger.info(f"🗑️ Нотатка #{note_id} видалена користувачем {user_id}")
    else:
        await reply_and_delete(update, "❌ Помилка при видаленні нотатки!")

async def deltimer_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Встановити таймер автоматичного видалення відповідей (1-60 секунд)"""
    global MESSAGE_DELETE_TIMER
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Ця команда доступна тільки для власника!")
        return
    
    if not context.args:
        await reply_and_delete(update, f"⏱️ Поточний таймер видалення: {MESSAGE_DELETE_TIMER} секунд\n\nЯк змінити: /deltimer [1-60]\nПриклад: /deltimer 10", delay=60)
        return
    
    try:
        delay = int(context.args[0])
        logger.debug(f"🔍 /deltimer: користувач спробував встановити таймер на {delay} сек")
        
        if delay < 1 or delay > 60:
            await reply_and_delete(update, "❌ Таймер має бути від 1 до 60 секунд!\nПриклад: /deltimer 5", delay=60)
            logger.debug(f"🔍 /deltimer: значення {delay} поза діапазоном 1-60")
            return
        
        MESSAGE_DELETE_TIMER = delay
        save_config()
        logger.info(f"✅ /deltimer: встановлено таймер на {delay} сек")
        
        await reply_and_delete(update, f"✅ Таймер встановлено на {delay} сек!\n⏱️ Усі повідомлення бота видаляються через {delay} сек.", delay=60)
        logger.info(f"⏱️ Власник {user_id} встановив таймер видалення на {delay} секунд")
        
        if LOG_CHANNEL_ID:
            try:
                await context.bot.send_message(
                    chat_id=LOG_CHANNEL_ID,
                    text=f"⏱️ Таймер видалення змінено на {delay} секунд\nВласник: {update.effective_user.full_name}"
                )
            except:
                pass
    except ValueError:
        await reply_and_delete(update, "❌ Вкажіть число від 1 до 60!\nПриклад: /deltimer 5", delay=60)
        logger.debug(f"🔍 /deltimer: помилка при розборі значення '{context.args[0]}'")

async def restart_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global RESTART_BOT
    save_user_from_update(update)
    """Перезапустити бота (тільки для власника)"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Ця команда доступна тільки для власника!")
        return
    
    await reply_and_delete(update, "✅ Бот успішно перезавантажено! ⚡", delay=3)
    logger.info(f"🔄 Бот перезавантажено власником {user_id}")
    
    # Встановлюємо флаг перезапуску
    RESTART_BOT = True
    # Даємо час на відправку повідомлення
    await asyncio.sleep(0.5)
    # Зупиняємо додаток
    await context.application.stop()

async def myname_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Встановити кастомне імʼя (видиме скрізь в команді)"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    if not context.args:
        current_name = db.get_custom_name(user_id)
        if current_name:
            await reply_and_delete(update, f"📝 Ваше кастомне імʼя: {current_name}\n\nЯк використовувати: /myname [нове імʼя]\nЩоб видалити: /myname - або /myname clear", delay=60)
        else:
            await reply_and_delete(update, "❌ Вкажіть імʼя!\nПриклад: /myname Мій Нік\nЩоб видалити: /myname - або /myname clear", delay=60)
        return
    
    custom_name = ' '.join(context.args)
    
    # Видалення кастомного імʼя
    if custom_name in ['-', 'clear']:
        old_name = db.get_custom_name(user_id)
        if db.delete_custom_name(user_id):
            old_name_text = f" ({old_name})" if old_name else ""
            await reply_and_delete(update, f"✅ Кастомне імʼя{old_name_text} видалено! Тепер видиме стандартне імʼя.", delay=60)
            logger.info(f"🗑️ Видалено кастомне імʼя '{old_name}' користувачем {user_id}")
        else:
            await reply_and_delete(update, "❌ Помилка при видаленні кастомного імʼя!", delay=60)
        return
    
    # Встановлення нового імʼя
    if len(custom_name) > 100:
        await reply_and_delete(update, "❌ Імʼя занадто довге (максимум 100 символів)!", delay=60)
        return
    
    if db.set_custom_name(user_id, custom_name):
        await reply_and_delete(update, f"✅ Кастомне імʼя встановлено!\n📝 Ваше нове імʼя: {custom_name}\n\nТепер воно буде видиме скрізь!", delay=60)
        logger.info(f"✏️ Користувач {user_id} встановив кастомне імʼя: {custom_name}")
    else:
        await reply_and_delete(update, "❌ Помилка при встановленні кастомного імʼя!", delay=60)

async def mym_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Встановити профіль-гіфку або фото, або видалити (-) """
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    # Видалення фото/гіфки
    if context.args and context.args[0] == '-':
        pic = db.get_profile_picture(user_id)
        old_pic_text = f" ({pic['media_type']})" if pic else ""
        if db.delete_profile_picture(user_id):
            await reply_and_delete(update, f"✅ Профіль-фото{old_pic_text} видалено! Тепер видиме стандартне.", delay=60)
            logger.info(f"🗑️ Видалено профіль-фото користувачем {user_id}")
        else:
            await reply_and_delete(update, "❌ Помилка при видаленні фото!", delay=60)
        return
    
    # Перевіряємо чи це reply на медіа
    if not update.message.reply_to_message:
        await reply_and_delete(update, "❌ Відповідьте на гіфку або фото!\nЩоб видалити: /mym -", delay=60)
        return
    
    reply = update.message.reply_to_message
    
    if reply.animation:
        # Це гіфка
        file_id = reply.animation.file_id
        media_type = "gif"
        emoji = "🎬"
    elif reply.photo:
        # Це фото
        file_id = reply.photo[-1].file_id
        media_type = "photo"
        emoji = "🖼️"
    else:
        await reply_and_delete(update, "❌ Це не гіфка і не фото!", delay=60)
        return
    
    if db.set_profile_picture(user_id, media_type, file_id):
        await reply_and_delete(update, f"✅ Профіль-{emoji} встановлено!", delay=60)
        logger.info(f"🖼️ Користувач {user_id} встановив профіль-{media_type}")
        
        # Логування в канал
        if LOG_CHANNEL_ID:
            try:
                await context.bot.send_message(
                    chat_id=LOG_CHANNEL_ID,
                    text=f"🖼️ Користувач {update.effective_user.full_name} [{user_id}] встановив профіль-{media_type}"
                )
            except:
                pass
    else:
        await reply_and_delete(update, "❌ Помилка при встановленні фото!", delay=60)

async def mymt_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Встановити опис профілю або видалити (-)"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not context.args:
        current_desc = db.get_profile_description(user_id)
        if current_desc:
            await reply_and_delete(update, f"📄 Ваш опис: {current_desc}\n\nЯк використовувати: /mymt [новий опис]\nЩоб видалити: /mymt - або /mymt clear", delay=60)
        else:
            await reply_and_delete(update, "❌ Вкажіть опис!\nПриклад: /mymt Я люблю програмування\nЩоб видалити: /mymt - або /mymt clear", delay=60)
        return
    
    description = " ".join(context.args)
    
    # Видалення опису
    if description in ['-', 'clear']:
        old_desc = db.get_profile_description(user_id)
        if db.delete_profile_description(user_id):
            old_desc_text = f" ({old_desc})" if old_desc else ""
            await reply_and_delete(update, f"✅ Опис профілю{old_desc_text} видалено! Тепер видиме стандартне.", delay=60)
            logger.info(f"🗑️ Видалено опис профілю '{old_desc}' користувачем {user_id}")
        else:
            await reply_and_delete(update, "❌ Помилка при видаленні опису!", delay=60)
        return
    
    # Встановлення нового опису
    if len(description) > 300:
        await reply_and_delete(update, "❌ Опис занадто довгий (максимум 300 символів)!", delay=60)
        return
    
    if db.set_profile_description(user_id, description):
        await reply_and_delete(update, f"✅ Опис профілю встановлено!\n📄 {description}", delay=60)
        logger.info(f"📝 Користувач {user_id} встановив опис: {description}")
        
        # Логування в канал
        if LOG_CHANNEL_ID:
            try:
                await context.bot.send_message(
                    chat_id=LOG_CHANNEL_ID,
                    text=f"📝 Користувач {update.effective_user.full_name} [{user_id}] встановив опис профілю"
                )
            except:
                pass
    else:
        await reply_and_delete(update, "❌ Помилка при встановленні опису!", delay=60)

async def htop_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Призначити кастомну посаду користувачу через reply або @username/ID"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Ця команда доступна тільки для власника!")
        return
    
    target_user_id = None
    target_user_name = None
    position = None
    
    # Способ 1: Reply на повідомлення
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user_id = update.message.reply_to_message.from_user.id
        target_user_name = update.message.reply_to_message.from_user.full_name or "Невідомий"
        if context.args:
            position = " ".join(context.args)
    # Способ 2: @username або ID як перший аргумент
    elif context.args and len(context.args) >= 1:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
        if target_user:
            target_user_id = target_user["user_id"]
            target_user_name = target_user["full_name"]
            # Посада - усі аргументи крім першого
            if len(context.args) > 1:
                position = " ".join(context.args[1:])
        else:
            await reply_and_delete(update, "❌ Користувача не знайдено!", delay=60)
            return
    else:
        await reply_and_delete(update, "❌ Використовуйте:\n/htop [посада] (reply на повідомлення)\nабо\n/htop @username [посада]\nабо\n/htop ID [посада]", delay=60)
        return
    
    if not target_user_id or not target_user_name:
        await reply_and_delete(update, """❌ Користувача не знайдено!

Можливі причини:
• Користувач ніколи не писав в цей бот/групу
• Невірно введене ім'я (@username)
• Акаунт приватний або видалений

Спробуйте:
• Впевніться, що користувач є членом групи
• Попросіть його написати хоча б 1 повідомлення
• Используйте ID замість @username (якщо знаєте ID)
• Reply на його повідомлення і /htop [посада]""", delay=60)
        return
    
    # Якщо немає позиції - показуємо поточну або просимо вказати
    if not position:
        current_pos = db.get_custom_position(target_user_id)
        if current_pos:
            await reply_and_delete(update, f"✅ Поточна посада {target_user_name}: {current_pos}\n\nЯк встановити нову:\n/htop @{target_user_name} [посада]\nЩоб видалити: /htop {target_user_id} -", delay=60)
        else:
            await reply_and_delete(update, f"❌ Вкажіть посаду для {target_user_name}!\nПриклад: /htop @{target_user_name} Старший розробник\nЩоб видалити: /htop {target_user_id} -", delay=60)
        return
    
    # Видалення посади
    if position in ['-', 'clear']:
        current_pos = db.get_custom_position(target_user_id)
        if db.delete_custom_position(target_user_id):
            old_pos_text = f" ({current_pos})" if current_pos else ""
            await reply_and_delete(update, f"✅ Посаду {target_user_name}{old_pos_text} видалено! Тепер видиме стандартна посада.", delay=60)
            logger.info(f"🗑️ Власник видалив посаду користувача {target_user_id}: {current_pos}")
        else:
            await reply_and_delete(update, "❌ Помилка при видаленні посади!", delay=60)
        return
    
    # Встановлення нової посади
    if len(position) > 50:
        await reply_and_delete(update, "❌ Посада занадто довга (максимум 50 символів)!", delay=60)
        return
    
    if db.set_custom_position(target_user_id, position):
        await reply_and_delete(update, f"✅ Посаду встановлено!\n👤 {target_user_name} → {position}", delay=60)
        logger.info(f"👑 Власник встановив посаду {target_user_id}: {position}")
        
        # Логування в канал
        if LOG_CHANNEL_ID:
            try:
                await context.bot.send_message(
                    chat_id=LOG_CHANNEL_ID,
                    text=f"👑 Власник встановив посаду {target_user_name} [{target_user_id}]: {position}"
                )
            except:
                pass
    else:
        await reply_and_delete(update, "❌ Помилка при встановленні посади!", delay=60)

def parse_time_to_seconds(time_str: str) -> int:
    match = re.match(r'(\d+)([dmh])', time_str)
    if not match:
        return 0
    
    value, unit = match.groups()
    value = int(value)
    
    if unit == 'm':
        return value * 60
    elif unit == 'h':
        return value * 3600
    elif unit == 'd':
        return value * 86400
    
    return 0

async def reminder_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    if not context.args or len(context.args) < 2:
        await reply_and_delete(update, "❌ Використання: /reminder [час: 1m/1h/1d] [текст]\nПриклад: /reminder 1h важливо запам'ятати")
        return
    
    time_str = context.args[0]
    reminder_text = " ".join(context.args[1:])
    
    seconds = parse_time_to_seconds(time_str)
    
    if seconds == 0:
        await reply_and_delete(update, "❌ Невірний формат часу! Використовуйте: 1m, 1h, 1d")
        return
    
    remind_at = (datetime.now() + timedelta(seconds=seconds)).isoformat()
    
    db.add_reminder(user_id, None, reminder_text, remind_at, update.effective_chat.id if update.effective_chat else None)
    
    await reply_and_delete(update, f"⏰ Нагадування встановлено на {time_str}!")

async def reminde_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!")
        return
    
    if not context.args or len(context.args) < 3:
        await reply_and_delete(update, "❌ Використання: /reminde @username [час: 1m/1h/1d] [текст]\nПриклад: /reminde @john 2h подзвонити")
        return
    
    identifier = context.args[0]
    time_str = context.args[1]
    reminder_text = " ".join(context.args[2:])
    
    target_user = await get_user_info(update, context, identifier)
    
    if not target_user:
        await reply_and_delete(update, "❌ Користувача не знайдено!")
        return
    
    seconds = parse_time_to_seconds(time_str)
    
    if seconds == 0:
        await reply_and_delete(update, "❌ Невірний формат часу! Використовуйте: 1m, 1h, 1d")
        return
    
    remind_at = (datetime.now() + timedelta(seconds=seconds)).isoformat()
    
    db.add_reminder(user_id, target_user["user_id"], reminder_text, remind_at, update.effective_chat.id if update.effective_chat else None)
    
    await reply_and_delete(update, f"⏰ Нагадування для {target_user['full_name']} встановлено на {time_str}!")

async def birthdays_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!")
        return
    
    birthdays = db.get_all_birthdays()
    
    if not birthdays:
        await reply_and_delete(update, "🎂 Днів народження не знайдено")
        return
    
    today = datetime.now()
    birthday_list = []
    
    for bd in birthdays:
        try:
            birth_date = datetime.strptime(bd["birth_date"], "%d.%m.%Y")
            next_birthday = birth_date.replace(year=today.year)
            
            if next_birthday < today:
                next_birthday = next_birthday.replace(year=today.year + 1)
            
            days_until = (next_birthday - today).days
            
            username_str = f"({bd['username']})" if bd['username'] else ""
            birthday_list.append({
                "name": f"{bd['full_name']} {username_str}",
                "date": bd["birth_date"],
                "days": days_until
            })
        except:
            pass
    
    birthday_list.sort(key=lambda x: x["days"])
    
    message = "🎂 Дні народження:\n\n"
    
    for idx, bd in enumerate(birthday_list, 1):
        days = bd['days']
        if days % 10 == 1 and days % 100 != 11:
            day_word = "день"
        elif days % 10 in [2, 3, 4] and days % 100 not in [12, 13, 14]:
            day_word = "дні"
        else:
            day_word = "днів"
        message += f"{idx}. {bd['name']} {bd['date']} [{days} {day_word}]\n"
    
    await reply_and_delete(update, message)

async def addb_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!")
        return
    
    target_user = None
    birth_date = None
    
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        if not context.args or len(context.args) < 1:
            await reply_and_delete(update, "❌ Вкажіть дату народження у форматі ДД.ММ.РРРР\nПриклад: /addb 25.12.1990")
            return
        
        target_user = {
            "user_id": update.message.reply_to_message.from_user.id,
            "username": update.message.reply_to_message.from_user.username or "",
            "full_name": update.message.reply_to_message.from_user.full_name or ""
        }
        birth_date = context.args[0]
    
    elif context.args and len(context.args) >= 2:
        identifier = context.args[0]
        birth_date = context.args[1]
        target_user = await get_user_info(update, context, identifier)
        
        if not target_user and identifier.startswith('@'):
            target_user = {
                "user_id": 0,
                "username": identifier.lstrip('@'),
                "full_name": identifier.lstrip('@')
            }
    
    if not target_user or not birth_date:
        await reply_and_delete(update, "❌ Використання:\n1️⃣ /addb @username ДД.ММ.РРРР\n2️⃣ Відповісти на повідомлення з /addb ДД.ММ.РРРР\n\nПриклад: /addb @john 01.05.1990")
        return
    
    try:
        birth_obj = datetime.strptime(birth_date, "%d.%m.%Y")
        if birth_obj > datetime.now():
            await reply_and_delete(update, "❌ День народження не може бути в майбутньому!")
            return
    except ValueError as e:
        await reply_and_delete(update, "❌ Невірна дата! Перевірте:\n• День: 01-31\n• Місяць: 01-12\n• Рік: РРРР\n\nПриклад: /addb @john 13.06.1990")
        return
    
    db.add_birthday(target_user["user_id"], birth_date, user_id, target_user["username"], target_user["full_name"])
    
    await reply_and_delete(update, f"✅ День народження {target_user['full_name']} ({birth_date}) збережено!")

async def setbgif_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!")
        return
    
    if not update.message.reply_to_message or not update.message.reply_to_message.animation:
        await reply_and_delete(update, "❌ Відповідьте на повідомлення з GIF!")
        return
    
    gif_file_id = update.message.reply_to_message.animation.file_id
    db.set_birthday_gif(gif_file_id)
    
    if update.message.reply_to_message.caption:
        db.set_birthday_text(update.message.reply_to_message.caption)
    
    await reply_and_delete(update, "✅ GIF для привітань встановлено!")

async def setbtext_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_ban_mute(user_id):
        await reply_and_delete(update, "❌ У вас немає прав для цієї команди!")
        return
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть текст привітання!")
        return
    
    greeting_text = " ".join(context.args)
    db.set_birthday_text(greeting_text)
    
    await reply_and_delete(update, "✅ Текст привітань встановлено!")

async def previewb_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Показати попередній перегляд привітань - текст і GIF (як буде виглядати при привітанні)"""
    if not update.effective_user or not update.message or not update.effective_chat:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Ця команда доступна тільки для власника!")
        return
    
    settings = db.get_birthday_settings()
    gif_file_id = settings.get("gif_file_id")
    greeting_text = settings.get("greeting_text", "З Днем Народження!")
    
    # Формуємо тег з @username або ім'ям
    username = update.effective_user.username
    tag = f"@{username}" if username else update.effective_user.first_name or "Користувачу"
    congratulation_text = f"Давайте привітаємо {tag}"
    
    if gif_file_id:
        try:
            sent_msg = await context.bot.send_animation(
                chat_id=update.effective_chat.id,
                animation=gif_file_id,
                caption=f"{greeting_text}\n\n{congratulation_text}",
                parse_mode=None
            )
            # Закріплюємо повідомлення
            await context.bot.pin_chat_message(
                chat_id=update.effective_chat.id,
                message_id=sent_msg.message_id
            )
            logger.info(f"🎉 Попередження закріплено для {tag}")
        except Exception as e:
            logger.error(f"Помилка при відправці попередження GIF: {e}")
            await reply_and_delete(update, f"{greeting_text}\n\n{congratulation_text}")
    else:
        try:
            sent_msg = await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=f"{greeting_text}\n\n{congratulation_text}",
                parse_mode=None
            )
            # Закріплюємо повідомлення
            await context.bot.pin_chat_message(
                chat_id=update.effective_chat.id,
                message_id=sent_msg.message_id
            )
            logger.info(f"🎉 Попередження закріплено для {tag}")
        except Exception as e:
            logger.error(f"Помилка при закріпленні попередження: {e}")
            await reply_and_delete(update, f"{greeting_text}\n\n{congratulation_text}")

async def adminchat_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    global ADMIN_CHAT_ID
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Тільки власник може змінювати налаштування!")
        return
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть ID адмін-чату!")
        return
    
    try:
        ADMIN_CHAT_ID = int(context.args[0])
        save_config()
        await reply_and_delete(update, f"✅ Адмін-чат змінено на {ADMIN_CHAT_ID}")
    except:
        await reply_and_delete(update, "❌ Невірний ID!")

async def userchat_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    global USER_CHAT_ID
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Тільки власник може змінювати налаштування!")
        return
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть ID чату користувачів!")
        return
    
    try:
        USER_CHAT_ID = int(context.args[0])
        save_config()
        await reply_and_delete(update, f"✅ Чат користувачів змінено на {USER_CHAT_ID}")
    except:
        await reply_and_delete(update, "❌ Невірний ID!")

async def logchannel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    global LOG_CHANNEL_ID
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Тільки власник може змінювати налаштування!")
        return
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть ID каналу логування!")
        return
    
    try:
        LOG_CHANNEL_ID = int(context.args[0])
        save_config()
        await reply_and_delete(update, f"✅ Канал логування змінено на {LOG_CHANNEL_ID}")
    except:
        await reply_and_delete(update, "❌ Невірний ID!")

async def testchannel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    global TEST_CHANNEL_ID
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Тільки власник може змінювати налаштування!")
        return
    
    if not context.args:
        await reply_and_delete(update, "❌ Вкажіть ID тестового каналу!")
        return
    
    try:
        TEST_CHANNEL_ID = int(context.args[0])
        save_config()
        await reply_and_delete(update, f"✅ Тестовий канал змінено на {TEST_CHANNEL_ID}")
    except:
        await reply_and_delete(update, "❌ Невірний ID!")

async def santas_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        return
    
    if not TEST_CHANNEL_ID:
        return
    
    if not update.message.reply_to_message:
        return
    
    try:
        replied_msg = update.message.reply_to_message
        
        # Спочатку спробуємо скопіювати (працює з bot messages і захищеним контентом)
        try:
            await context.bot.copy_message(
                chat_id=TEST_CHANNEL_ID,
                from_chat_id=update.effective_chat.id if update.effective_chat else USER_CHAT_ID,
                message_id=replied_msg.message_id
            )
            logger.info(f"🎅 /santas: Повідомлення скопійовано")
        except Exception as copy_error:
            logger.warning(f"⚠️ /santas: Помилка копіювання: {copy_error}, спробую альтернативний метод...")
            
            # Визначаємо тип медіа для логування
            media_type = "невідомо"
            if replied_msg.sticker:
                media_type = "стікер 📌"
            elif replied_msg.photo:
                media_type = "фото 🖼️"
            elif replied_msg.video:
                media_type = "відео 🎬"
            elif replied_msg.animation:
                media_type = "гіфка 🎞️"
            elif replied_msg.document:
                media_type = "документ 📎"
            elif replied_msg.audio:
                media_type = "аудіо 🎵"
            elif replied_msg.text:
                media_type = "текст 📝"
            
            logger.info(f"📤 /santas: Тип контенту: {media_type}")
            
            # Якщо копіювання не спрацює, пересилаємо
            try:
                await context.bot.forward_message(
                    chat_id=TEST_CHANNEL_ID,
                    from_chat_id=update.effective_chat.id if update.effective_chat else USER_CHAT_ID,
                    message_id=replied_msg.message_id
                )
                logger.info(f"✅ /santas: Повідомлення пересилано ({media_type})")
            except Exception as forward_error:
                logger.warning(f"⚠️ /santas: Помилка пересилання: {forward_error}, копіюю вміст...")
                
                # Останній варіант - копіюємо вміст (перевіряємо МЕДІА перед ТЕКСТОМ)
                if replied_msg.sticker:
                    logger.info("📌 /santas: Копіюю стікер")
                    await context.bot.send_sticker(
                        chat_id=TEST_CHANNEL_ID,
                        sticker=replied_msg.sticker.file_id
                    )
                elif replied_msg.photo:
                    logger.info("🖼️ /santas: Копіюю фото")
                    await context.bot.send_photo(
                        chat_id=TEST_CHANNEL_ID,
                        photo=replied_msg.photo[-1].file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.video:
                    logger.info("🎬 /santas: Копіюю відео")
                    await context.bot.send_video(
                        chat_id=TEST_CHANNEL_ID,
                        video=replied_msg.video.file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.animation:
                    logger.info("🎞️ /santas: Копіюю гіфку")
                    await context.bot.send_animation(
                        chat_id=TEST_CHANNEL_ID,
                        animation=replied_msg.animation.file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.document:
                    logger.info("📎 /santas: Копіюю документ")
                    await context.bot.send_document(
                        chat_id=TEST_CHANNEL_ID,
                        document=replied_msg.document.file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.audio:
                    logger.info("🎵 /santas: Копіюю аудіо")
                    await context.bot.send_audio(
                        chat_id=TEST_CHANNEL_ID,
                        audio=replied_msg.audio.file_id,
                        caption=replied_msg.caption or ""
                    )
                elif replied_msg.text:
                    logger.info("📝 /santas: Копіюю текст")
                    await context.bot.send_message(
                        chat_id=TEST_CHANNEL_ID,
                        text=replied_msg.text,
                        parse_mode=None
                    )
                else:
                    logger.warning("❓ /santas: Невідомий тип повідомлення")
                    await context.bot.send_message(
                        chat_id=TEST_CHANNEL_ID,
                        text="[Повідомлення без тексту]"
                    )
        
        # Тихе збереження - без повідомлення користувачеві
        try:
            await update.message.delete()
        except:
            pass
        
    except Exception as e:
        logger.error(f"Помилка /santas: {e}")

async def send_birthday_greetings(context: ContextTypes.DEFAULT_TYPE):
    """Відправляє привітання на дні народження о 08:00 Київського часу"""
    try:
        tz_kyiv = pytz.timezone('Europe/Kyiv')
        today = datetime.now(tz_kyiv).strftime("%d.%m")
        
        todays_birthdays = db.get_todays_birthdays()
        
        if not todays_birthdays:
            logger.info("🎂 Сьогодні немає днів народження")
            return
        
        settings = db.get_birthday_settings()
        gif_file_id = settings.get("gif_file_id")
        greeting_text = settings.get("greeting_text", "З Днем Народження!")
        
        for birthday_person in todays_birthdays:
            username = birthday_person.get("username")
            full_name = birthday_person.get("full_name", "Користувачу")
            
            # Формуємо тег з @username або ім'ям
            tag = f"@{username}" if username else full_name
            congratulation_text = f"Давайте привітаємо {tag}"
            message = f"{greeting_text}\n\n{congratulation_text}"
            
            try:
                if gif_file_id:
                    sent_msg = await context.bot.send_animation(
                        chat_id=USER_CHAT_ID,
                        animation=gif_file_id,
                        caption=message,
                        parse_mode=None
                    )
                    logger.info(f"🎉 Привітання з GIF надіслано {tag}")
                else:
                    sent_msg = await context.bot.send_message(
                        chat_id=USER_CHAT_ID,
                        text=message,
                        parse_mode=None
                    )
                    logger.info(f"🎉 Привітання надіслано {tag}")
                
                # Закріплюємо привітання
                try:
                    await context.bot.pin_chat_message(
                        chat_id=USER_CHAT_ID,
                        message_id=sent_msg.message_id
                    )
                    logger.info(f"📌 Привітання закріплено для {tag}")
                except Exception as e:
                    logger.warning(f"⚠️ Не вдалося закріпити привітання для {tag}: {e}")
            except Exception as e:
                logger.error(f"Помилка при відправці привітання {tag}: {e}")
    
    except Exception as e:
        logger.error(f"🎂 Помилка у send_birthday_greetings: {e}")

# ============ КОМАНДИ ДЛЯ ВИДАЛЕННЯ ПРОФІЛЮ ============

async def del_myname_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Видалити кастомне імʼя (-myname)"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    old_name = db.get_custom_name(user_id)
    if not old_name:
        await reply_and_delete(update, "❌ У вас немає кастомного імʼя для видалення!")
        return
    
    if db.delete_custom_name(user_id):
        await reply_and_delete(update, f"✅ Кастомне імʼя видалено! ❌ ({old_name})\n→ Повернулось стандартне імʼя")
        logger.info(f"🗑️ Видалено кастомне імʼя '{old_name}' користувачем {user_id}")
    else:
        await reply_and_delete(update, "❌ Помилка при видаленні кастомного імʼя!")

async def del_mym_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Видалити профіль-фото (-mym)"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    pic = db.get_profile_picture(user_id)
    if not pic:
        await reply_and_delete(update, "❌ У вас немає профіль-фото для видалення!")
        return
    
    pic_type = pic.get('media_type', 'невідомо')
    emoji = "🎬" if pic_type == "gif" else "🖼️"
    
    if db.delete_profile_picture(user_id):
        await reply_and_delete(update, f"✅ Профіль-фото видалено! ❌ ({pic_type})\n→ Повернулось стандартне {emoji}")
        logger.info(f"🗑️ Видалено профіль-{pic_type} користувачем {user_id}")
    else:
        await reply_and_delete(update, "❌ Помилка при видаленні фото!")

async def del_mymt_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Видалити опис профілю (-mymt)"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not can_use_bot(user_id):
        await reply_and_delete(update, "❌ У вас немає доступу до цієї команди!")
        return
    
    old_desc = db.get_profile_description(user_id)
    if not old_desc:
        await reply_and_delete(update, "❌ У вас немає опису для видалення!")
        return
    
    if db.delete_profile_description(user_id):
        desc_preview = old_desc[:50] + "..." if len(old_desc) > 50 else old_desc
        await reply_and_delete(update, f"✅ Опис видалено! ❌ ({desc_preview})\n→ Повернулось стандартне")
        logger.info(f"🗑️ Видалено опис профілю користувачем {user_id}")
    else:
        await reply_and_delete(update, "❌ Помилка при видаленні опису!")

async def del_htop_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    save_user_from_update(update)
    """Видалити кастомну посаду користувача (-htop)"""
    if not update.effective_user or not update.message:
        return
    
    user_id = update.effective_user.id
    
    if not is_owner(user_id):
        await reply_and_delete(update, "❌ Ця команда доступна тільки для власника!")
        return
    
    target_user_id = None
    target_user_name = None
    
    # Способ 1: Reply на повідомлення
    if update.message.reply_to_message and update.message.reply_to_message.from_user:
        target_user_id = update.message.reply_to_message.from_user.id
        target_user_name = update.message.reply_to_message.from_user.full_name or "Невідомий"
    # Способ 2: @username або ID як аргумент
    elif context.args and len(context.args) >= 1:
        identifier = context.args[0]
        target_user = await get_user_info(update, context, identifier)
        if target_user:
            target_user_id = target_user["user_id"]
            target_user_name = target_user["full_name"]
        else:
            await reply_and_delete(update, "❌ Користувача не знайдено!")
            return
    else:
        await reply_and_delete(update, "❌ Використовуйте:\n-htop (reply на повідомлення)\nабо\n-htop @username\nабо\n-htop ID")
        return
    
    if not target_user_id or not target_user_name:
        await reply_and_delete(update, "❌ Користувача не знайдено!")
        return
    
    current_pos = db.get_custom_position(target_user_id)
    if not current_pos:
        await reply_and_delete(update, f"❌ У користувача {target_user_name} немає кастомної посади для видалення!")
        return
    
    if db.delete_custom_position(target_user_id):
        await reply_and_delete(update, f"✅ Посаду видалено! ❌ ({current_pos})\n👤 {target_user_name} → стандартна посада")
        logger.info(f"🗑️ Видалено посаду '{current_pos}' у користувача {target_user_id}")
    else:
        await reply_and_delete(update, "❌ Помилка при видаленні посади!")

def setup_handlers(application):
    """Налаштовує всі хендлери (винесено з main для швидшого завантаження)"""
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("helpg", help_g_command))
    application.add_handler(CommandHandler("helpm", help_m_command))
    application.add_handler(CommandHandler("allcmd", allcmd_command))
    
    application.add_handler(CommandHandler("add_gnome", add_gnome_command))
    application.add_handler(CommandHandler("remove_gnome", remove_gnome_command))
    application.add_handler(CommandHandler("add_main_admin", add_main_admin_command))
    application.add_handler(CommandHandler("remove_main_admin", remove_main_admin_command))
    
    application.add_handler(CommandHandler("ban_s", ban_s_command))
    application.add_handler(CommandHandler("ban_t", ban_t_command))
    application.add_handler(CommandHandler("unban_s", unban_s_command))
    application.add_handler(CommandHandler("unban_t", unban_t_command))
    application.add_handler(CommandHandler("mute_s", mute_s_command))
    application.add_handler(CommandHandler("mute_t", mute_t_command))
    application.add_handler(CommandHandler("unmute_s", unmute_s_command))
    application.add_handler(CommandHandler("unmute_t", unmute_t_command))
    application.add_handler(CommandHandler("kick", kick_command))
    application.add_handler(CommandHandler("nah", nah_command))
    
    application.add_handler(CommandHandler("say", say_command))
    application.add_handler(CommandHandler("says", says_command))
    application.add_handler(CommandHandler("sayon", sayon_command))
    application.add_handler(CommandHandler("sayson", sayson_command))
    application.add_handler(CommandHandler("sayoff", sayoff_command))
    application.add_handler(CommandHandler("sayoffall", sayoffall_command))
    application.add_handler(CommandHandler("saypin", saypin_command))
    application.add_handler(CommandHandler("save_s", save_s_command))
    application.add_handler(CommandHandler("online_list", online_list_command))
    application.add_handler(CommandHandler("sayb", sayb_command))
    application.add_handler(CommandHandler("sayu", sayu_command))
    
    application.add_handler(CommandHandler("alarm", alarm_command))
    application.add_handler(CommandHandler("broadcast", broadcast_command))
    application.add_handler(CommandHandler("hto", hto_command))
    
    application.add_handler(CommandHandler("note", note_command))
    application.add_handler(CommandHandler("notes", notes_command))
    application.add_handler(CommandHandler("delnote", delnote_command))
    application.add_handler(CommandHandler("reminder", reminder_command))
    application.add_handler(CommandHandler("reminde", reminde_command))
    
    application.add_handler(CommandHandler("birthdays", birthdays_command))
    application.add_handler(CommandHandler("addb", addb_command))
    application.add_handler(CommandHandler("setbgif", setbgif_command))
    application.add_handler(CommandHandler("setbtext", setbtext_command))
    application.add_handler(CommandHandler("previewb", previewb_command))
    
    application.add_handler(CommandHandler("adminchat", adminchat_command))
    application.add_handler(CommandHandler("userchat", userchat_command))
    application.add_handler(CommandHandler("logchannel", logchannel_command))
    application.add_handler(CommandHandler("testchannel", testchannel_command))
    application.add_handler(CommandHandler("santas", santas_command))
    application.add_handler(CommandHandler("deltimer", deltimer_command))
    application.add_handler(CommandHandler("restart", restart_command))
    application.add_handler(CommandHandler("myname", myname_command))
    application.add_handler(CommandHandler("mym", mym_command))
    application.add_handler(CommandHandler("mymt", mymt_command))
    application.add_handler(CommandHandler("htop", htop_command))
    
    # Команди для видалення профілю
    application.add_handler(CommandHandler("del_myname", del_myname_command))
    application.add_handler(CommandHandler("del_mym", del_mym_command))
    application.add_handler(CommandHandler("del_mymt", del_mymt_command))
    application.add_handler(CommandHandler("del_htop", del_htop_command))
    
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_all_messages))

def main():
    if not BOT_TOKEN:
        logger.error("Не вказано BOT_TOKEN!")
        return
    
    restart_count = 0
    
    while True:
        try:
            # Очищуємо активні режими асинхронно (не блокуємо запуск)
            try:
                db.clear_all_online_modes()
            except:
                pass  # Ігноруємо помилки при очищенні
            
            application = Application.builder().token(BOT_TOKEN).build()
            
            # Налаштування job_queue для автоматичних днів народження (асинхронно)
            if application.job_queue:
                birthday_time = time(hour=8, minute=0, tzinfo=KYIV_TZ)
                application.job_queue.run_daily(
                    send_birthday_greetings,
                    time=birthday_time,
                    days=(0, 1, 2, 3, 4, 5, 6)  # Кожен день
                )
            
            # Налаштовуємо всі хендлери
            setup_handlers(application)
            
            logger.info("🤖 Бот запущено!")
            restart_count = 0
            
            application.run_polling(allowed_updates=Update.ALL_TYPES)
            
            # Якщо RESTART_BOT = True, вихідимо з exception обробки і перезапускаємо
            if RESTART_BOT:
                logger.info("🔄 Перезапуск бота за запитом...")
                continue
            
        except Exception as e:
            restart_count += 1
            logger.error(f"🔴 ПОМИЛКА БОТА: {e}")
            logger.error(f"🔄 Перезапуск #{restart_count} через 5 секунд...")
            time_module.sleep(5)
            
        except KeyboardInterrupt:
            logger.info("🛑 Бот зупинено користувачем")
            break

if __name__ == '__main__':
    main()
